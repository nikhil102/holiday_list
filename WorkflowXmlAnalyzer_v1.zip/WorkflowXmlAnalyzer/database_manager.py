"""
Database Manager for Informatica Workflow Analyzer
Handles MS SQL Server connections and data operations
"""

import pyodbc
import pandas as pd
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import json

from config import DATABASE_CONFIG, TABLE_NAMES

class DatabaseManager:
    """Manages database connections and operations"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.connection_string = self._build_connection_string()
        
    def _build_connection_string(self) -> str:
        """Build ODBC connection string"""
        config = DATABASE_CONFIG
        return (
            f"DRIVER={config['driver']};"
            f"SERVER={config['server']};"
            f"DATABASE={config['database']};"
            f"UID={config['username']};"
            f"PWD={config['password']};"
            f"TrustServerCertificate=yes;"
            f"Encrypt=no;"
            f"Connection Timeout={config['connection_timeout']};"
        )
    
    def get_connection(self):
        """Get database connection"""
        try:
            conn = pyodbc.connect(self.connection_string)
            return conn
        except Exception as e:
            self.logger.error(f"Database connection failed: {str(e)}")
            raise
    
    def test_connection(self) -> bool:
        """Test database connection"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT 1")
                result = cursor.fetchone()
                self.logger.info("Database connection test successful")
                return result[0] == 1
        except Exception as e:
            self.logger.error(f"Database connection test failed: {str(e)}")
            raise
    
    def execute_script_file(self, script_path: str) -> bool:
        """Execute SQL script file"""
        try:
            with open(script_path, 'r') as file:
                script = file.read()
            
            with self.get_connection() as conn:
                cursor = conn.cursor()
                # Split script by GO statements and execute each batch
                batches = script.split('GO')
                for batch in batches:
                    batch = batch.strip()
                    if batch:
                        cursor.execute(batch)
                conn.commit()
            
            self.logger.info(f"Successfully executed script: {script_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to execute script {script_path}: {str(e)}")
            raise
    
    def create_tables(self) -> bool:
        """Create database tables if they don't exist"""
        try:
            script_path = "sql_scripts/create_tables.sql"
            return self.execute_script_file(script_path)
        except Exception as e:
            self.logger.error(f"Failed to create tables: {str(e)}")
            raise
    
    def insert_workflow_data(self, workflow_data: Dict[str, Any]) -> int:
        """Insert workflow data and return workflow_id"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Insert workflow
                workflow_sql = f"""
                INSERT INTO {TABLE_NAMES['workflows']} 
                (workflow_name, workflow_path, creation_date, repository_name, 
                 folder_name, description, parsed_date, file_size)
                OUTPUT INSERTED.workflow_id
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """
                
                cursor.execute(workflow_sql, (
                    workflow_data.get('workflow_name', ''),
                    workflow_data.get('workflow_path', ''),
                    workflow_data.get('creation_date'),
                    workflow_data.get('repository_name', ''),
                    workflow_data.get('folder_name', ''),
                    workflow_data.get('description', ''),
                    datetime.now(),
                    workflow_data.get('file_size', 0)
                ))
                
                workflow_id = cursor.fetchone()[0]
                conn.commit()
                
                self.logger.info(f"Inserted workflow with ID: {workflow_id}")
                return workflow_id
                
        except Exception as e:
            self.logger.error(f"Failed to insert workflow data: {str(e)}")
            raise
    
    def insert_source_data(self, workflow_id: int, sources: List[Dict[str, Any]]) -> bool:
        """Insert source data for a workflow"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                source_sql = f"""
                INSERT INTO {TABLE_NAMES['sources']}
                (workflow_id, source_name, database_type, db_name, description, 
                 owner_name, version_number, field_count)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """
                
                for source in sources:
                    cursor.execute(source_sql, (
                        workflow_id,
                        source.get('name', ''),
                        source.get('database_type', ''),
                        source.get('db_name', ''),
                        source.get('description', ''),
                        source.get('owner_name', ''),
                        source.get('version_number', 1),
                        len(source.get('fields', []))
                    ))
                
                conn.commit()
                self.logger.info(f"Inserted {len(sources)} sources for workflow {workflow_id}")
                return True
                
        except Exception as e:
            self.logger.error(f"Failed to insert source data: {str(e)}")
            raise
    
    def insert_field_data(self, workflow_id: int, source_name: str, fields: List[Dict[str, Any]]) -> bool:
        """Insert field data for a source"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                field_sql = f"""
                INSERT INTO {TABLE_NAMES['fields']}
                (workflow_id, source_name, field_name, data_type, length, 
                 precision_val, scale_val, nullable, key_type, description)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """
                
                for field in fields:
                    cursor.execute(field_sql, (
                        workflow_id,
                        source_name,
                        field.get('name', ''),
                        field.get('datatype', ''),
                        field.get('length', 0),
                        field.get('precision', 0),
                        field.get('scale', 0),
                        field.get('nullable', 'NULL'),
                        field.get('keytype', 'NOT A KEY'),
                        field.get('description', '')
                    ))
                
                conn.commit()
                self.logger.info(f"Inserted {len(fields)} fields for source {source_name}")
                return True
                
        except Exception as e:
            self.logger.error(f"Failed to insert field data: {str(e)}")
            raise
    
    def get_workflow_summary(self) -> pd.DataFrame:
        """Get workflow summary statistics"""
        try:
            with self.get_connection() as conn:
                sql = f"""
                SELECT 
                    w.workflow_name,
                    w.folder_name,
                    w.repository_name,
                    w.parsed_date,
                    COUNT(DISTINCT s.source_id) as source_count,
                    COUNT(DISTINCT f.field_id) as field_count,
                    w.file_size
                FROM {TABLE_NAMES['workflows']} w
                LEFT JOIN {TABLE_NAMES['sources']} s ON w.workflow_id = s.workflow_id
                LEFT JOIN {TABLE_NAMES['fields']} f ON w.workflow_id = f.workflow_id
                GROUP BY w.workflow_id, w.workflow_name, w.folder_name, 
                         w.repository_name, w.parsed_date, w.file_size
                ORDER BY w.parsed_date DESC
                """
                
                df = pd.read_sql(sql, conn)
                return df
                
        except Exception as e:
            self.logger.error(f"Failed to get workflow summary: {str(e)}")
            raise
    
    def get_workflow_details(self, workflow_id: int) -> Dict[str, Any]:
        """Get detailed workflow information"""
        try:
            with self.get_connection() as conn:
                # Get workflow info
                workflow_sql = f"SELECT * FROM {TABLE_NAMES['workflows']} WHERE workflow_id = ?"
                workflow_df = pd.read_sql(workflow_sql, conn, params=[workflow_id])
                
                # Get sources
                sources_sql = f"SELECT * FROM {TABLE_NAMES['sources']} WHERE workflow_id = ?"
                sources_df = pd.read_sql(sources_sql, conn, params=[workflow_id])
                
                # Get fields
                fields_sql = f"SELECT * FROM {TABLE_NAMES['fields']} WHERE workflow_id = ?"
                fields_df = pd.read_sql(fields_sql, conn, params=[workflow_id])
                
                return {
                    'workflow': workflow_df.to_dict('records')[0] if not workflow_df.empty else {},
                    'sources': sources_df.to_dict('records'),
                    'fields': fields_df.to_dict('records')
                }
                
        except Exception as e:
            self.logger.error(f"Failed to get workflow details: {str(e)}")
            raise
    
    def search_workflows(self, search_term: str) -> pd.DataFrame:
        """Search workflows by name or description"""
        try:
            with self.get_connection() as conn:
                sql = f"""
                SELECT 
                    w.workflow_id,
                    w.workflow_name,
                    w.folder_name,
                    w.repository_name,
                    w.description,
                    w.parsed_date,
                    COUNT(DISTINCT s.source_id) as source_count
                FROM {TABLE_NAMES['workflows']} w
                LEFT JOIN {TABLE_NAMES['sources']} s ON w.workflow_id = s.workflow_id
                WHERE w.workflow_name LIKE ? OR w.description LIKE ?
                GROUP BY w.workflow_id, w.workflow_name, w.folder_name, 
                         w.repository_name, w.description, w.parsed_date
                ORDER BY w.workflow_name
                """
                
                search_pattern = f"%{search_term}%"
                df = pd.read_sql(sql, conn, params=[search_pattern, search_pattern])
                return df
                
        except Exception as e:
            self.logger.error(f"Failed to search workflows: {str(e)}")
            raise
    
    def export_workflow_data(self, workflow_ids: List[int] = None) -> pd.DataFrame:
        """Export workflow data for analysis"""
        try:
            with self.get_connection() as conn:
                where_clause = ""
                params = []
                
                if workflow_ids:
                    placeholders = ",".join(["?" for _ in workflow_ids])
                    where_clause = f"WHERE w.workflow_id IN ({placeholders})"
                    params = workflow_ids
                
                sql = f"""
                SELECT 
                    w.workflow_name,
                    w.workflow_path,
                    w.folder_name,
                    w.repository_name,
                    w.creation_date,
                    w.parsed_date,
                    s.source_name,
                    s.database_type,
                    s.db_name,
                    f.field_name,
                    f.data_type,
                    f.length,
                    f.nullable,
                    f.key_type
                FROM {TABLE_NAMES['workflows']} w
                LEFT JOIN {TABLE_NAMES['sources']} s ON w.workflow_id = s.workflow_id
                LEFT JOIN {TABLE_NAMES['fields']} f ON s.workflow_id = f.workflow_id 
                    AND s.source_name = f.source_name
                {where_clause}
                ORDER BY w.workflow_name, s.source_name, f.field_name
                """
                
                df = pd.read_sql(sql, conn, params=params)
                return df
                
        except Exception as e:
            self.logger.error(f"Failed to export workflow data: {str(e)}")
            raise
