# Quick Start Guide - Informatica Workflow Analyzer

## Installation Summary

### 1. Prerequisites Check
```cmd
# Check Python installation
python --version

# Check SQL Server connectivity
sqlcmd -S w908925\CGSQL -U spark_user -P spark@25091990 -d msscdm_dev4 -Q "SELECT 1"
```

### 2. Install Dependencies
```cmd
pip install pyodbc pandas openpyxl
```

### 3. Run Application
```cmd
python informatica_analyzer.py
```

## First Time Setup

1. **Extract Package**: Unzip to `C:\InformaticaAnalyzer\`
2. **Open Command Prompt**: Navigate to application folder
3. **Install**: Run `pip install -r requirements.txt`
4. **Start**: Double-click `start_analyzer.bat` or run `python informatica_analyzer.py`

## Using the Application

### Process XML Files
1. File Processing tab → Select Files → Process Files
2. Wait for completion message
3. View results in Workflow Analysis tab

### Export Data
1. Export tab → Choose format → Export Data
2. Select save location

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Database connection failed | Check VPN, verify credentials |
| Python not found | Install Python, add to PATH |
| Module not found | Run `pip install -r requirements.txt` |
| XML parsing error | Verify file is valid Informatica XML |

## Support Files Included

- `informatica_analyzer.py` - Main application
- `requirements.txt` - Dependencies
- `database_setup.sql` - Database tables
- `start_analyzer.bat` - Quick launcher
- `sample_xml_files/` - Test files

## Company Configuration

Pre-configured for:
- Server: w908925\CGSQL  
- Database: msscdm_dev4
- User: spark_user

Ready to analyze your Informatica workflow XML files!