#!/usr/bin/env python3
"""
Create Fixed Deployment Package for Informatica Workflow Analyzer
Includes corrected GUI application and comprehensive setup
"""

import os
import shutil
from datetime import datetime

def create_fixed_deployment():
    """Create fixed deployment package"""
    
    package_name = "informatica_analyzer_fixed_deployment"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    package_dir = f"{package_name}_{timestamp}"
    
    print(f"Creating fixed deployment package: {package_dir}")
    
    # Create package directory
    if os.path.exists(package_dir):
        shutil.rmtree(package_dir)
    os.makedirs(package_dir)
    
    # Copy fixed application file
    shutil.copy2("informatica_analyzer_fixed.py", 
                os.path.join(package_dir, "informatica_analyzer.py"))
    
    # Copy sample XML files
    sample_dir = os.path.join(package_dir, "sample_xml_files")
    os.makedirs(sample_dir)
    
    attached_files = [
        "attached_assets/wf_landing_sfdc_to_cdm_contact_party.xml",
        "attached_assets/wf_landing_sfdc_to_cdm_organization_party.xml", 
        "attached_assets/wf_landing_sfdc_to_cdm_office_party.xml"
    ]
    
    for file_path in attached_files:
        if os.path.exists(file_path):
            shutil.copy2(file_path, sample_dir)
    
    # Create updated requirements file
    requirements = """pyodbc==5.0.1
pandas==2.1.4
openpyxl==3.1.2"""
    
    with open(os.path.join(package_dir, "requirements.txt"), 'w') as f:
        f.write(requirements)
    
    # Create comprehensive setup script
    setup_script = """@echo off
title Informatica Workflow Analyzer Setup
echo =========================================
echo Informatica Workflow Analyzer Setup
echo =========================================
echo.

echo [1/5] Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not in PATH
    echo.
    echo Please install Python 3.7+ from https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during installation
    echo.
    pause
    exit /b 1
)
echo Python found successfully

echo.
echo [2/5] Checking pip installation...
pip --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: pip is not available
    echo Please reinstall Python with pip included
    echo.
    pause
    exit /b 1
)
echo pip found successfully

echo.
echo [3/5] Installing required packages...
echo This may take a few minutes...
pip install -r requirements.txt
if errorlevel 1 (
    echo ERROR: Failed to install packages
    echo Please check your internet connection and try again
    echo.
    pause
    exit /b 1
)
echo Packages installed successfully

echo.
echo [4/5] Testing database connectivity...
echo Checking connection to w908925\CGSQL...
sqlcmd -S "w908925\CGSQL" -U spark_user -P "spark@25091990" -d msscdm_dev4 -Q "SELECT 1" -h -1 >nul 2>&1
if errorlevel 1 (
    echo WARNING: Database connection test failed
    echo This could be due to:
    echo - VPN not connected
    echo - SQL Server not accessible
    echo - Network connectivity issues
    echo.
    echo The application will still start but database features won't work
    echo until connectivity is established.
    echo.
) else (
    echo Database connection successful
)

echo.
echo [5/5] Setup complete!
echo.
echo To run the application:
echo   python informatica_analyzer.py
echo.
echo Or double-click: start_analyzer.bat
echo.
pause
"""
    
    with open(os.path.join(package_dir, "setup.bat"), 'w') as f:
        f.write(setup_script)
    
    # Create improved start script
    start_script = """@echo off
title Informatica Workflow Analyzer
echo Starting Informatica Workflow Analyzer...
echo.

REM Check if Python is available
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found
    echo Please run setup.bat first
    pause
    exit /b 1
)

REM Start the application
python informatica_analyzer.py

REM Keep window open if there's an error
if errorlevel 1 (
    echo.
    echo Application ended with an error
    pause
)
"""
    
    with open(os.path.join(package_dir, "start_analyzer.bat"), 'w') as f:
        f.write(start_script)
    
    # Create troubleshooting guide
    troubleshooting = """TROUBLESHOOTING GUIDE
====================

COMMON ISSUES AND SOLUTIONS

1. PYTHON NOT FOUND
   Problem: "Python is not recognized as internal or external command"
   Solution: 
   - Install Python 3.7+ from python.org
   - During installation, check "Add Python to PATH"
   - Restart command prompt after installation

2. DATABASE CONNECTION FAILED
   Problem: Application shows "Database Connection Failed"
   Solutions:
   - Connect to company VPN
   - Verify SQL Server is accessible: ping w908925.cguser.capgroup.com
   - Check credentials with DBA team
   - Ensure ODBC Driver 17 for SQL Server is installed

3. PERMISSION DENIED ERRORS
   Problem: "Access denied" when installing packages
   Solution:
   - Run command prompt as Administrator
   - Or use: pip install --user -r requirements.txt

4. MODULE NOT FOUND ERRORS
   Problem: "No module named 'pyodbc'" or similar
   Solution:
   - Run: pip install --upgrade -r requirements.txt
   - Verify installation: pip list

5. XML PARSING ERRORS
   Problem: "Invalid XML format" errors
   Solution:
   - Verify files are valid Informatica PowerCenter exports
   - Check file permissions and accessibility
   - Test with provided sample files first

6. APPLICATION CRASHES
   Problem: Application closes unexpectedly
   Solution:
   - Check informatica_analyzer.log for error details
   - Ensure sufficient memory available
   - Process files in smaller batches

7. SLOW PERFORMANCE
   Problem: Application runs slowly with large files
   Solution:
   - Close other applications to free memory
   - Process files in batches of 10-20
   - Consider upgrading system RAM

GETTING HELP
============

1. Check the log file: informatica_analyzer.log
2. Note exact error messages
3. Document system configuration
4. Contact development team with specific details

SYSTEM REQUIREMENTS
===================

Minimum:
- Windows 10/11 64-bit
- Python 3.7+
- 4GB RAM
- Network access to SQL Server

Recommended:
- Windows 10/11 64-bit
- Python 3.9+
- 8GB RAM
- SSD storage
- Stable network connection
"""
    
    with open(os.path.join(package_dir, "TROUBLESHOOTING.txt"), 'w') as f:
        f.write(troubleshooting)
    
    # Create quick reference guide
    quick_ref = """QUICK REFERENCE GUIDE
=====================

INSTALLATION
1. Run setup.bat as Administrator
2. Follow on-screen instructions
3. Test with start_analyzer.bat

USING THE APPLICATION

File Processing Tab:
- Select XML files (single, multiple, or folder)
- Click "Process Files"
- Monitor progress bar

Workflow Analysis Tab:
- View processed workflows
- Use search to filter results
- Double-click for detailed view

Detailed View Tab:
- Shows comprehensive workflow information
- Displays sources, fields, and analysis

Export Tab:
- Choose CSV or Excel format
- Export current data set
- View export log

KEYBOARD SHORTCUTS
- Ctrl+O: Open files (when in File Processing tab)
- F5: Refresh workflow list
- Ctrl+F: Focus search box
- Ctrl+E: Switch to Export tab

DATABASE TABLES
- informatica_workflows: Main workflow metadata
- informatica_sources: Source system information
- informatica_fields: Field-level details

CONFIGURATION
Server: w908925\CGSQL
Database: msscdm_dev4
User: spark_user

FILES INCLUDED
- informatica_analyzer.py: Main application
- requirements.txt: Python dependencies
- setup.bat: Installation script
- start_analyzer.bat: Quick launcher
- sample_xml_files/: Test files
- TROUBLESHOOTING.txt: Detailed help
"""
    
    with open(os.path.join(package_dir, "QUICK_REFERENCE.txt"), 'w') as f:
        f.write(quick_ref)
    
    # Create database setup script
    db_script = """-- Informatica Workflow Analyzer Database Setup
-- Run this in SQL Server Management Studio if tables don't exist

USE msscdm_dev4;
GO

-- Create main workflows table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_workflows' AND xtype='U')
BEGIN
    CREATE TABLE informatica_workflows (
        workflow_id INT IDENTITY(1,1) PRIMARY KEY,
        workflow_name NVARCHAR(255) NOT NULL,
        workflow_path NVARCHAR(1000) NOT NULL,
        creation_date DATETIME2,
        repository_name NVARCHAR(255),
        folder_name NVARCHAR(255),
        description NVARCHAR(1000),
        parsed_date DATETIME2 NOT NULL DEFAULT GETDATE(),
        file_size BIGINT,
        created_date DATETIME2 DEFAULT GETDATE()
    );
    PRINT 'Created informatica_workflows table';
END
ELSE
    PRINT 'informatica_workflows table already exists';

-- Create sources table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_sources' AND xtype='U')
BEGIN
    CREATE TABLE informatica_sources (
        source_id INT IDENTITY(1,1) PRIMARY KEY,
        workflow_id INT NOT NULL,
        source_name NVARCHAR(255) NOT NULL,
        database_type NVARCHAR(100),
        db_name NVARCHAR(255),
        description NVARCHAR(1000),
        owner_name NVARCHAR(100),
        field_count INT DEFAULT 0,
        created_date DATETIME2 DEFAULT GETDATE()
    );
    PRINT 'Created informatica_sources table';
END
ELSE
    PRINT 'informatica_sources table already exists';

-- Create fields table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_fields' AND xtype='U')
BEGIN
    CREATE TABLE informatica_fields (
        field_id INT IDENTITY(1,1) PRIMARY KEY,
        workflow_id INT NOT NULL,
        source_name NVARCHAR(255),
        field_name NVARCHAR(255) NOT NULL,
        data_type NVARCHAR(100),
        length INT DEFAULT 0,
        precision_val INT DEFAULT 0,
        scale_val INT DEFAULT 0,
        nullable NVARCHAR(10),
        key_type NVARCHAR(50),
        field_number INT,
        created_date DATETIME2 DEFAULT GETDATE()
    );
    PRINT 'Created informatica_fields table';
END
ELSE
    PRINT 'informatica_fields table already exists';

-- Create indexes for performance
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_workflows_name')
    CREATE INDEX IX_workflows_name ON informatica_workflows(workflow_name);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_sources_workflow')
    CREATE INDEX IX_sources_workflow ON informatica_sources(workflow_id);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_fields_workflow')
    CREATE INDEX IX_fields_workflow ON informatica_fields(workflow_id);

PRINT 'Database setup completed successfully!';
PRINT 'Tables created: informatica_workflows, informatica_sources, informatica_fields';

-- Display table information
SELECT 
    TABLE_NAME,
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = t.TABLE_NAME) as COLUMN_COUNT
FROM INFORMATION_SCHEMA.TABLES t
WHERE TABLE_NAME LIKE 'informatica_%'
ORDER BY TABLE_NAME;
"""
    
    with open(os.path.join(package_dir, "database_setup.sql"), 'w') as f:
        f.write(db_script)
    
    print(f"\nFixed deployment package created successfully in: {package_dir}")
    print("\nPackage contents:")
    for root, dirs, files in os.walk(package_dir):
        level = root.replace(package_dir, '').count(os.sep)
        indent = ' ' * 2 * level
        print(f"{indent}{os.path.basename(root)}/")
        subindent = ' ' * 2 * (level + 1)
        for file in files:
            print(f"{subindent}{file}")
    
    print(f"\nTo install on company laptop:")
    print(f"1. Copy {package_dir} folder to C:\\InformaticaAnalyzer\\")
    print(f"2. Right-click setup.bat and 'Run as Administrator'")
    print(f"3. Follow setup instructions")
    print(f"4. Use start_analyzer.bat to launch application")
    
    return package_dir

if __name__ == "__main__":
    create_fixed_deployment()