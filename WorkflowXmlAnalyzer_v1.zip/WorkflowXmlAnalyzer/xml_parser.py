"""
XML Parser for Informatica Workflow Files
Extracts metadata from PowerCenter XML workflow definitions
"""

import xml.etree.ElementTree as ET
import logging
import os
from typing import Dict, List, Any, Optional
from datetime import datetime
import re

class InformaticaXMLParser:
    """Parser for Informatica PowerCenter XML workflow files"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
    def parse_workflow_file(self, file_path: str) -> Dict[str, Any]:
        """Parse a single workflow XML file"""
        try:
            self.logger.info(f"Parsing workflow file: {file_path}")
            
            # Validate file
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"File not found: {file_path}")
            
            if not file_path.lower().endswith('.xml'):
                raise ValueError(f"Invalid file type. Expected .xml file: {file_path}")
            
            # Get file size
            file_size = os.path.getsize(file_path)
            
            # Parse XML
            tree = ET.parse(file_path)
            root = tree.getroot()
            
            # Extract basic workflow information
            workflow_data = self._extract_workflow_metadata(root, file_path, file_size)
            
            # Extract sources
            workflow_data['sources'] = self._extract_sources(root)
            
            # Extract transformations
            workflow_data['transformations'] = self._extract_transformations(root)
            
            # Extract targets
            workflow_data['targets'] = self._extract_targets(root)
            
            # Extract mappings
            workflow_data['mappings'] = self._extract_mappings(root)
            
            self.logger.info(f"Successfully parsed workflow: {workflow_data.get('workflow_name', 'Unknown')}")
            return workflow_data
            
        except ET.ParseError as e:
            self.logger.error(f"XML parsing error in file {file_path}: {str(e)}")
            raise ValueError(f"Invalid XML format in file {file_path}: {str(e)}")
        except Exception as e:
            self.logger.error(f"Error parsing workflow file {file_path}: {str(e)}")
            raise
    
    def _extract_workflow_metadata(self, root: ET.Element, file_path: str, file_size: int) -> Dict[str, Any]:
        """Extract basic workflow metadata from XML root"""
        try:
            # PowerCenter XML structure: POWERMART > REPOSITORY > FOLDER
            powermart = root if root.tag == 'POWERMART' else root.find('.//POWERMART')
            if powermart is None:
                raise ValueError("Invalid Informatica XML: POWERMART element not found")
            
            repository = powermart.find('REPOSITORY')
            if repository is None:
                raise ValueError("Invalid Informatica XML: REPOSITORY element not found")
            
            folder = repository.find('FOLDER')
            if folder is None:
                raise ValueError("Invalid Informatica XML: FOLDER element not found")
            
            # Extract workflow name from file path if not found in XML
            workflow_name = os.path.splitext(os.path.basename(file_path))[0]
            
            # Try to find actual workflow element
            workflow_elem = folder.find('.//WORKFLOW')
            if workflow_elem is not None:
                workflow_name = workflow_elem.get('NAME', workflow_name)
            
            metadata = {
                'workflow_name': workflow_name,
                'workflow_path': file_path,
                'file_size': file_size,
                'creation_date': self._parse_date(powermart.get('CREATION_DATE')),
                'repository_name': repository.get('NAME', ''),
                'repository_version': repository.get('VERSION', ''),
                'folder_name': folder.get('NAME', ''),
                'folder_description': folder.get('DESCRIPTION', ''),
                'folder_owner': folder.get('OWNER', ''),
                'folder_permissions': folder.get('PERMISSIONS', ''),
                'parsed_timestamp': datetime.now()
            }
            
            return metadata
            
        except Exception as e:
            self.logger.error(f"Error extracting workflow metadata: {str(e)}")
            raise
    
    def _extract_sources(self, root: ET.Element) -> List[Dict[str, Any]]:
        """Extract source system information"""
        sources = []
        
        try:
            # Find all SOURCE elements
            source_elements = root.findall('.//SOURCE')
            
            for source_elem in source_elements:
                source_data = {
                    'name': source_elem.get('NAME', ''),
                    'business_name': source_elem.get('BUSINESSNAME', ''),
                    'database_type': source_elem.get('DATABASETYPE', ''),
                    'db_name': source_elem.get('DBDNAME', ''),
                    'description': source_elem.get('DESCRIPTION', ''),
                    'owner_name': source_elem.get('OWNERNAME', ''),
                    'version_number': int(source_elem.get('VERSIONNUMBER', '1')),
                    'object_version': source_elem.get('OBJECTVERSION', ''),
                    'fields': []
                }
                
                # Extract source fields
                source_fields = self._extract_source_fields(source_elem)
                source_data['fields'] = source_fields
                
                sources.append(source_data)
            
            self.logger.info(f"Extracted {len(sources)} sources")
            return sources
            
        except Exception as e:
            self.logger.error(f"Error extracting sources: {str(e)}")
            return []
    
    def _extract_source_fields(self, source_elem: ET.Element) -> List[Dict[str, Any]]:
        """Extract field information from a source"""
        fields = []
        
        try:
            field_elements = source_elem.findall('SOURCEFIELD')
            
            for field_elem in field_elements:
                field_data = {
                    'name': field_elem.get('NAME', ''),
                    'business_name': field_elem.get('BUSINESSNAME', ''),
                    'datatype': field_elem.get('DATATYPE', ''),
                    'description': field_elem.get('DESCRIPTION', ''),
                    'field_number': int(field_elem.get('FIELDNUMBER', '0')),
                    'field_type': field_elem.get('FIELDTYPE', ''),
                    'length': int(field_elem.get('PHYSICALLENGTH', '0')),
                    'precision': int(field_elem.get('PRECISION', '0')),
                    'scale': int(field_elem.get('SCALE', '0')),
                    'nullable': field_elem.get('NULLABLE', ''),
                    'keytype': field_elem.get('KEYTYPE', ''),
                    'hidden': field_elem.get('HIDDEN', 'NO'),
                    'offset': int(field_elem.get('PHYSICALOFFSET', '0'))
                }
                fields.append(field_data)
            
            return sorted(fields, key=lambda x: x['field_number'])
            
        except Exception as e:
            self.logger.error(f"Error extracting source fields: {str(e)}")
            return []
    
    def _extract_transformations(self, root: ET.Element) -> List[Dict[str, Any]]:
        """Extract transformation information"""
        transformations = []
        
        try:
            # Find all TRANSFORMATION elements
            transformation_elements = root.findall('.//TRANSFORMATION')
            
            for trans_elem in transformation_elements:
                trans_data = {
                    'name': trans_elem.get('NAME', ''),
                    'type': trans_elem.get('TYPE', ''),
                    'subtype': trans_elem.get('SUBTYPE', ''),
                    'description': trans_elem.get('DESCRIPTION', ''),
                    'version_number': int(trans_elem.get('VERSIONNUMBER', '1')),
                    'object_version': trans_elem.get('OBJECTVERSION', ''),
                    'reusable': trans_elem.get('REUSABLE', 'NO'),
                    'input_fields': [],
                    'output_fields': [],
                    'properties': []
                }
                
                # Extract transformation fields and properties
                trans_data.update(self._extract_transformation_details(trans_elem))
                transformations.append(trans_data)
            
            self.logger.info(f"Extracted {len(transformations)} transformations")
            return transformations
            
        except Exception as e:
            self.logger.error(f"Error extracting transformations: {str(e)}")
            return []
    
    def _extract_transformation_details(self, trans_elem: ET.Element) -> Dict[str, Any]:
        """Extract detailed transformation information"""
        details = {
            'input_fields': [],
            'output_fields': [],
            'properties': []
        }
        
        try:
            # Extract transformation fields
            for field_elem in trans_elem.findall('.//TRANSFORMFIELD'):
                field_data = {
                    'name': field_elem.get('NAME', ''),
                    'datatype': field_elem.get('DATATYPE', ''),
                    'precision': int(field_elem.get('PRECISION', '0')),
                    'scale': int(field_elem.get('SCALE', '0')),
                    'nullable': field_elem.get('NULLABLE', ''),
                    'field_type': field_elem.get('FIELDTYPE', ''),
                    'group_name': field_elem.get('GROUPNAME', ''),
                    'expression': field_elem.get('EXPRESSION', ''),
                    'default_value': field_elem.get('DEFAULTVALUE', '')
                }
                
                # Categorize as input or output based on field type
                if field_data['field_type'] in ['INPUT', 'INPUT/OUTPUT']:
                    details['input_fields'].append(field_data)
                if field_data['field_type'] in ['OUTPUT', 'INPUT/OUTPUT']:
                    details['output_fields'].append(field_data)
            
            # Extract transformation properties
            for prop_elem in trans_elem.findall('.//TRANSFORMATIONPROPERTY'):
                prop_data = {
                    'name': prop_elem.get('NAME', ''),
                    'value': prop_elem.get('VALUE', ''),
                    'type': prop_elem.get('TYPE', '')
                }
                details['properties'].append(prop_data)
            
            return details
            
        except Exception as e:
            self.logger.error(f"Error extracting transformation details: {str(e)}")
            return details
    
    def _extract_targets(self, root: ET.Element) -> List[Dict[str, Any]]:
        """Extract target information"""
        targets = []
        
        try:
            # Find all TARGET elements
            target_elements = root.findall('.//TARGET')
            
            for target_elem in target_elements:
                target_data = {
                    'name': target_elem.get('NAME', ''),
                    'business_name': target_elem.get('BUSINESSNAME', ''),
                    'database_type': target_elem.get('DATABASETYPE', ''),
                    'db_name': target_elem.get('DBDNAME', ''),
                    'description': target_elem.get('DESCRIPTION', ''),
                    'owner_name': target_elem.get('OWNERNAME', ''),
                    'version_number': int(target_elem.get('VERSIONNUMBER', '1')),
                    'object_version': target_elem.get('OBJECTVERSION', ''),
                    'load_type': target_elem.get('LOADTYPE', ''),
                    'constraint_based_load_ordering': target_elem.get('CONSTRAINTBASEDLOADORDERING', ''),
                    'fields': []
                }
                
                # Extract target fields
                target_fields = self._extract_target_fields(target_elem)
                target_data['fields'] = target_fields
                
                targets.append(target_data)
            
            self.logger.info(f"Extracted {len(targets)} targets")
            return targets
            
        except Exception as e:
            self.logger.error(f"Error extracting targets: {str(e)}")
            return []
    
    def _extract_target_fields(self, target_elem: ET.Element) -> List[Dict[str, Any]]:
        """Extract field information from a target"""
        fields = []
        
        try:
            field_elements = target_elem.findall('TARGETFIELD')
            
            for field_elem in field_elements:
                field_data = {
                    'name': field_elem.get('NAME', ''),
                    'business_name': field_elem.get('BUSINESSNAME', ''),
                    'datatype': field_elem.get('DATATYPE', ''),
                    'description': field_elem.get('DESCRIPTION', ''),
                    'field_number': int(field_elem.get('FIELDNUMBER', '0')),
                    'field_type': field_elem.get('FIELDTYPE', ''),
                    'length': int(field_elem.get('PHYSICALLENGTH', '0')),
                    'precision': int(field_elem.get('PRECISION', '0')),
                    'scale': int(field_elem.get('SCALE', '0')),
                    'nullable': field_elem.get('NULLABLE', ''),
                    'keytype': field_elem.get('KEYTYPE', ''),
                    'key_type': field_elem.get('KEYTYPE', '')
                }
                fields.append(field_data)
            
            return sorted(fields, key=lambda x: x['field_number'])
            
        except Exception as e:
            self.logger.error(f"Error extracting target fields: {str(e)}")
            return []
    
    def _extract_mappings(self, root: ET.Element) -> List[Dict[str, Any]]:
        """Extract mapping information"""
        mappings = []
        
        try:
            # Find all MAPPING elements
            mapping_elements = root.findall('.//MAPPING')
            
            for mapping_elem in mapping_elements:
                mapping_data = {
                    'name': mapping_elem.get('NAME', ''),
                    'description': mapping_elem.get('DESCRIPTION', ''),
                    'version_number': int(mapping_elem.get('VERSIONNUMBER', '1')),
                    'object_version': mapping_elem.get('OBJECTVERSION', ''),
                    'is_valid': mapping_elem.get('ISVALID', 'NO'),
                    'connectors': [],
                    'instances': []
                }
                
                # Extract mapping details
                mapping_data.update(self._extract_mapping_details(mapping_elem))
                mappings.append(mapping_data)
            
            self.logger.info(f"Extracted {len(mappings)} mappings")
            return mappings
            
        except Exception as e:
            self.logger.error(f"Error extracting mappings: {str(e)}")
            return []
    
    def _extract_mapping_details(self, mapping_elem: ET.Element) -> Dict[str, Any]:
        """Extract detailed mapping information"""
        details = {
            'connectors': [],
            'instances': []
        }
        
        try:
            # Extract connectors
            for connector_elem in mapping_elem.findall('.//CONNECTOR'):
                connector_data = {
                    'from_field': connector_elem.get('FROMFIELD', ''),
                    'from_instance': connector_elem.get('FROMINSTANCE', ''),
                    'to_field': connector_elem.get('TOFIELD', ''),
                    'to_instance': connector_elem.get('TOINSTANCE', ''),
                    'connector_type': connector_elem.get('CONNECTORTYPE', '')
                }
                details['connectors'].append(connector_data)
            
            # Extract instances
            for instance_elem in mapping_elem.findall('.//INSTANCE'):
                instance_data = {
                    'name': instance_elem.get('NAME', ''),
                    'transformation_name': instance_elem.get('TRANSFORMATION_NAME', ''),
                    'transformation_type': instance_elem.get('TRANSFORMATION_TYPE', ''),
                    'description': instance_elem.get('DESCRIPTION', ''),
                    'reusable': instance_elem.get('REUSABLE', 'NO')
                }
                details['instances'].append(instance_data)
            
            return details
            
        except Exception as e:
            self.logger.error(f"Error extracting mapping details: {str(e)}")
            return details
    
    def _parse_date(self, date_string: str) -> Optional[datetime]:
        """Parse date string from XML"""
        if not date_string:
            return None
        
        try:
            # Try different date formats
            date_formats = [
                '%m/%d/%Y %H:%M:%S',
                '%Y-%m-%d %H:%M:%S',
                '%m/%d/%Y',
                '%Y-%m-%d'
            ]
            
            for date_format in date_formats:
                try:
                    return datetime.strptime(date_string, date_format)
                except ValueError:
                    continue
            
            # If no format matches, return None
            self.logger.warning(f"Could not parse date: {date_string}")
            return None
            
        except Exception as e:
            self.logger.error(f"Error parsing date {date_string}: {str(e)}")
            return None
    
    def validate_xml_structure(self, file_path: str) -> bool:
        """Validate if XML file has correct Informatica structure"""
        try:
            tree = ET.parse(file_path)
            root = tree.getroot()
            
            # Check for required elements
            if root.tag != 'POWERMART':
                return False
            
            repository = root.find('REPOSITORY')
            if repository is None:
                return False
            
            folder = repository.find('FOLDER')
            if folder is None:
                return False
            
            return True
            
        except Exception:
            return False
    
    def get_workflow_summary(self, file_path: str) -> Dict[str, Any]:
        """Get quick summary without full parsing"""
        try:
            tree = ET.parse(file_path)
            root = tree.getroot()
            
            # Count different elements
            summary = {
                'file_path': file_path,
                'file_size': os.path.getsize(file_path),
                'sources_count': len(root.findall('.//SOURCE')),
                'transformations_count': len(root.findall('.//TRANSFORMATION')),
                'targets_count': len(root.findall('.//TARGET')),
                'mappings_count': len(root.findall('.//MAPPING')),
                'workflows_count': len(root.findall('.//WORKFLOW')),
                'is_valid': self.validate_xml_structure(file_path)
            }
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Error getting workflow summary for {file_path}: {str(e)}")
            return {
                'file_path': file_path,
                'error': str(e),
                'is_valid': False
            }
