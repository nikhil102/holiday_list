-- Informatica Workflow Analyzer Database Setup
-- Run this in SQL Server Management Studio if tables don't exist

USE msscdm_dev4;
GO

-- Create main workflows table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_workflows' AND xtype='U')
BEGIN
    CREATE TABLE informatica_workflows (
        workflow_id INT IDENTITY(1,1) PRIMARY KEY,
        workflow_name NVARCHAR(255) NOT NULL,
        workflow_path NVARCHAR(1000) NOT NULL,
        creation_date DATETIME2,
        repository_name NVARCHAR(255),
        folder_name NVARCHAR(255),
        description NVARCHAR(1000),
        parsed_date DATETIME2 NOT NULL DEFAULT GETDATE(),
        file_size BIGINT,
        created_date DATETIME2 DEFAULT GETDATE()
    );
    PRINT 'Created informatica_workflows table';
END
ELSE
    PRINT 'informatica_workflows table already exists';

-- Create sources table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_sources' AND xtype='U')
BEGIN
    CREATE TABLE informatica_sources (
        source_id INT IDENTITY(1,1) PRIMARY KEY,
        workflow_id INT NOT NULL,
        source_name NVARCHAR(255) NOT NULL,
        database_type NVARCHAR(100),
        db_name NVARCHAR(255),
        description NVARCHAR(1000),
        owner_name NVARCHAR(100),
        field_count INT DEFAULT 0,
        created_date DATETIME2 DEFAULT GETDATE()
    );
    PRINT 'Created informatica_sources table';
END
ELSE
    PRINT 'informatica_sources table already exists';

-- Create fields table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_fields' AND xtype='U')
BEGIN
    CREATE TABLE informatica_fields (
        field_id INT IDENTITY(1,1) PRIMARY KEY,
        workflow_id INT NOT NULL,
        source_name NVARCHAR(255),
        field_name NVARCHAR(255) NOT NULL,
        data_type NVARCHAR(100),
        length INT DEFAULT 0,
        precision_val INT DEFAULT 0,
        scale_val INT DEFAULT 0,
        nullable NVARCHAR(10),
        key_type NVARCHAR(50),
        field_number INT,
        created_date DATETIME2 DEFAULT GETDATE()
    );
    PRINT 'Created informatica_fields table';
END
ELSE
    PRINT 'informatica_fields table already exists';

-- Create indexes for performance
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_workflows_name')
    CREATE INDEX IX_workflows_name ON informatica_workflows(workflow_name);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_sources_workflow')
    CREATE INDEX IX_sources_workflow ON informatica_sources(workflow_id);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_fields_workflow')
    CREATE INDEX IX_fields_workflow ON informatica_fields(workflow_id);

PRINT 'Database setup completed successfully!';
PRINT 'Tables created: informatica_workflows, informatica_sources, informatica_fields';

-- Display table information
SELECT 
    TABLE_NAME,
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = t.TABLE_NAME) as COLUMN_COUNT
FROM INFORMATION_SCHEMA.TABLES t
WHERE TABLE_NAME LIKE 'informatica_%'
ORDER BY TABLE_NAME;
