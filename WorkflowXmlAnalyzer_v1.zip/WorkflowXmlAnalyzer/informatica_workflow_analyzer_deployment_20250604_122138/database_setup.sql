
-- Database Setup Script for Informatica Workflow Analyzer
-- Run this script if tables don't exist or need to be recreated

USE msscdm_dev4;
GO

-- Create main workflows table if not exists
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_workflows' AND xtype='U')
CREATE TABLE informatica_workflows (
    workflow_id INT IDENTITY(1,1) PRIMARY KEY,
    workflow_name NVARCHAR(255) NOT NULL,
    workflow_path NVARCHAR(1000) NOT NULL,
    creation_date DATETIME2,
    repository_name NVARCHAR(255),
    folder_name NVARCHAR(255),
    description NVARCHAR(1000),
    parsed_date DATETIME2 NOT NULL DEFAULT GETDATE(),
    file_size BIGINT,
    created_date DATETIME2 DEFAULT GETDATE()
);

-- Create sources table if not exists
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_sources' AND xtype='U')
CREATE TABLE informatica_sources (
    source_id INT IDENTITY(1,1) PRIMARY KEY,
    workflow_id INT NOT NULL,
    source_name NVARCHAR(255) NOT NULL,
    database_type NVARCHAR(100),
    db_name NVARCHAR(255),
    description NVARCHAR(1000),
    owner_name NVARCHAR(100),
    field_count INT DEFAULT 0,
    created_date DATETIME2 DEFAULT GETDATE()
);

-- Create fields table if not exists
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_fields' AND xtype='U')
CREATE TABLE informatica_fields (
    field_id INT IDENTITY(1,1) PRIMARY KEY,
    workflow_id INT NOT NULL,
    source_name NVARCHAR(255),
    field_name NVARCHAR(255) NOT NULL,
    data_type NVARCHAR(100),
    length INT DEFAULT 0,
    precision_val INT DEFAULT 0,
    scale_val INT DEFAULT 0,
    nullable NVARCHAR(10),
    key_type NVARCHAR(50),
    field_number INT,
    created_date DATETIME2 DEFAULT GETDATE()
);

-- Create indexes for performance
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_workflows_name')
CREATE INDEX IX_workflows_name ON informatica_workflows(workflow_name);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_sources_workflow')
CREATE INDEX IX_sources_workflow ON informatica_sources(workflow_id);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_fields_workflow')
CREATE INDEX IX_fields_workflow ON informatica_fields(workflow_id);

PRINT 'Database setup completed successfully!';
