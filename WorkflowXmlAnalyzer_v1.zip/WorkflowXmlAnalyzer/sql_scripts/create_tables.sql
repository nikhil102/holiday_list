-- Create database tables for Informatica Workflow Analyzer
-- MS SQL Server compatible

-- Drop existing tables if they exist (in correct order due to foreign keys)
IF OBJECT_ID('informatica_fields', 'U') IS NOT NULL DROP TABLE informatica_fields;
IF OBJECT_ID('informatica_targets', 'U') IS NOT NULL DROP TABLE informatica_targets;
IF OBJECT_ID('informatica_transformations', 'U') IS NOT NULL DROP TABLE informatica_transformations;
IF OBJECT_ID('informatica_mappings', 'U') IS NOT NULL DROP TABLE informatica_mappings;
IF OBJECT_ID('informatica_sources', 'U') IS NOT NULL DROP TABLE informatica_sources;
IF OBJECT_ID('informatica_workflows', 'U') IS NOT NULL DROP TABLE informatica_workflows;
IF OBJECT_ID('informatica_analysis_summary', 'U') IS NOT NULL DROP TABLE informatica_analysis_summary;

GO

-- Create main workflows table
CREATE TABLE informatica_workflows (
    workflow_id INT IDENTITY(1,1) PRIMARY KEY,
    workflow_name NVARCHAR(255) NOT NULL,
    workflow_path NVARCHAR(1000) NOT NULL,
    creation_date DATETIME2,
    repository_name NVARCHAR(255),
    repository_version NVARCHAR(50),
    folder_name NVARCHAR(255),
    folder_description NVARCHAR(1000),
    folder_owner NVARCHAR(100),
    folder_permissions NVARCHAR(50),
    description NVARCHAR(1000),
    parsed_date DATETIME2 NOT NULL DEFAULT GETDATE(),
    file_size BIGINT,
    is_active BIT DEFAULT 1,
    created_date DATETIME2 DEFAULT GETDATE(),
    updated_date DATETIME2 DEFAULT GETDATE()
);

GO

-- Create index on workflow_name for faster searches
CREATE INDEX IX_informatica_workflows_name ON informatica_workflows(workflow_name);
CREATE INDEX IX_informatica_workflows_folder ON informatica_workflows(folder_name);
CREATE INDEX IX_informatica_workflows_repository ON informatica_workflows(repository_name);

GO

-- Create sources table
CREATE TABLE informatica_sources (
    source_id INT IDENTITY(1,1) PRIMARY KEY,
    workflow_id INT NOT NULL,
    source_name NVARCHAR(255) NOT NULL,
    business_name NVARCHAR(255),
    database_type NVARCHAR(100),
    db_name NVARCHAR(255),
    description NVARCHAR(1000),
    owner_name NVARCHAR(100),
    version_number INT DEFAULT 1,
    object_version NVARCHAR(50),
    field_count INT DEFAULT 0,
    created_date DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (workflow_id) REFERENCES informatica_workflows(workflow_id) ON DELETE CASCADE
);

GO

-- Create index on source_name for faster lookups
CREATE INDEX IX_informatica_sources_name ON informatica_sources(source_name);
CREATE INDEX IX_informatica_sources_workflow ON informatica_sources(workflow_id);

GO

-- Create transformations table
CREATE TABLE informatica_transformations (
    transformation_id INT IDENTITY(1,1) PRIMARY KEY,
    workflow_id INT NOT NULL,
    transformation_name NVARCHAR(255) NOT NULL,
    transformation_type NVARCHAR(100),
    transformation_subtype NVARCHAR(100),
    description NVARCHAR(1000),
    version_number INT DEFAULT 1,
    object_version NVARCHAR(50),
    is_reusable BIT DEFAULT 0,
    input_field_count INT DEFAULT 0,
    output_field_count INT DEFAULT 0,
    properties_count INT DEFAULT 0,
    created_date DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (workflow_id) REFERENCES informatica_workflows(workflow_id) ON DELETE CASCADE
);

GO

-- Create index on transformation_name for faster lookups
CREATE INDEX IX_informatica_transformations_name ON informatica_transformations(transformation_name);
CREATE INDEX IX_informatica_transformations_type ON informatica_transformations(transformation_type);
CREATE INDEX IX_informatica_transformations_workflow ON informatica_transformations(workflow_id);

GO

-- Create targets table
CREATE TABLE informatica_targets (
    target_id INT IDENTITY(1,1) PRIMARY KEY,
    workflow_id INT NOT NULL,
    target_name NVARCHAR(255) NOT NULL,
    business_name NVARCHAR(255),
    database_type NVARCHAR(100),
    db_name NVARCHAR(255),
    description NVARCHAR(1000),
    owner_name NVARCHAR(100),
    version_number INT DEFAULT 1,
    object_version NVARCHAR(50),
    load_type NVARCHAR(100),
    constraint_based_load_ordering NVARCHAR(10),
    field_count INT DEFAULT 0,
    created_date DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (workflow_id) REFERENCES informatica_workflows(workflow_id) ON DELETE CASCADE
);

GO

-- Create index on target_name for faster lookups
CREATE INDEX IX_informatica_targets_name ON informatica_targets(target_name);
CREATE INDEX IX_informatica_targets_workflow ON informatica_targets(workflow_id);

GO

-- Create mappings table
CREATE TABLE informatica_mappings (
    mapping_id INT IDENTITY(1,1) PRIMARY KEY,
    workflow_id INT NOT NULL,
    mapping_name NVARCHAR(255) NOT NULL,
    description NVARCHAR(1000),
    version_number INT DEFAULT 1,
    object_version NVARCHAR(50),
    is_valid BIT DEFAULT 0,
    connector_count INT DEFAULT 0,
    instance_count INT DEFAULT 0,
    created_date DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (workflow_id) REFERENCES informatica_workflows(workflow_id) ON DELETE CASCADE
);

GO

-- Create index on mapping_name for faster lookups
CREATE INDEX IX_informatica_mappings_name ON informatica_mappings(mapping_name);
CREATE INDEX IX_informatica_mappings_workflow ON informatica_mappings(workflow_id);

GO

-- Create fields table (for both source and target fields)
CREATE TABLE informatica_fields (
    field_id INT IDENTITY(1,1) PRIMARY KEY,
    workflow_id INT NOT NULL,
    source_name NVARCHAR(255),
    target_name NVARCHAR(255),
    field_name NVARCHAR(255) NOT NULL,
    business_name NVARCHAR(255),
    data_type NVARCHAR(100),
    description NVARCHAR(1000),
    field_number INT,
    field_type NVARCHAR(50),
    length INT DEFAULT 0,
    precision_val INT DEFAULT 0,
    scale_val INT DEFAULT 0,
    nullable NVARCHAR(10),
    key_type NVARCHAR(50),
    is_hidden BIT DEFAULT 0,
    physical_offset INT DEFAULT 0,
    default_value NVARCHAR(500),
    expression NVARCHAR(2000),
    group_name NVARCHAR(255),
    created_date DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (workflow_id) REFERENCES informatica_workflows(workflow_id) ON DELETE CASCADE
);

GO

-- Create indexes on fields table
CREATE INDEX IX_informatica_fields_workflow ON informatica_fields(workflow_id);
CREATE INDEX IX_informatica_fields_source ON informatica_fields(source_name);
CREATE INDEX IX_informatica_fields_target ON informatica_fields(target_name);
CREATE INDEX IX_informatica_fields_name ON informatica_fields(field_name);
CREATE INDEX IX_informatica_fields_type ON informatica_fields(data_type);

GO

-- Create analysis summary table for reporting
CREATE TABLE informatica_analysis_summary (
    summary_id INT IDENTITY(1,1) PRIMARY KEY,
    analysis_date DATETIME2 DEFAULT GETDATE(),
    total_workflows INT DEFAULT 0,
    total_sources INT DEFAULT 0,
    total_transformations INT DEFAULT 0,
    total_targets INT DEFAULT 0,
    total_mappings INT DEFAULT 0,
    total_fields INT DEFAULT 0,
    unique_repositories INT DEFAULT 0,
    unique_folders INT DEFAULT 0,
    avg_sources_per_workflow DECIMAL(10,2) DEFAULT 0,
    avg_fields_per_workflow DECIMAL(10,2) DEFAULT 0,
    analysis_notes NVARCHAR(2000),
    created_by NVARCHAR(100) DEFAULT SYSTEM_USER
);

GO

-- Create stored procedure to refresh analysis summary
CREATE PROCEDURE sp_refresh_analysis_summary
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @total_workflows INT;
    DECLARE @total_sources INT;
    DECLARE @total_transformations INT;
    DECLARE @total_targets INT;
    DECLARE @total_mappings INT;
    DECLARE @total_fields INT;
    DECLARE @unique_repositories INT;
    DECLARE @unique_folders INT;
    DECLARE @avg_sources_per_workflow DECIMAL(10,2);
    DECLARE @avg_fields_per_workflow DECIMAL(10,2);
    
    -- Calculate summary statistics
    SELECT @total_workflows = COUNT(*) FROM informatica_workflows WHERE is_active = 1;
    SELECT @total_sources = COUNT(*) FROM informatica_sources s 
        INNER JOIN informatica_workflows w ON s.workflow_id = w.workflow_id 
        WHERE w.is_active = 1;
    SELECT @total_transformations = COUNT(*) FROM informatica_transformations t 
        INNER JOIN informatica_workflows w ON t.workflow_id = w.workflow_id 
        WHERE w.is_active = 1;
    SELECT @total_targets = COUNT(*) FROM informatica_targets t 
        INNER JOIN informatica_workflows w ON t.workflow_id = w.workflow_id 
        WHERE w.is_active = 1;
    SELECT @total_mappings = COUNT(*) FROM informatica_mappings m 
        INNER JOIN informatica_workflows w ON m.workflow_id = w.workflow_id 
        WHERE w.is_active = 1;
    SELECT @total_fields = COUNT(*) FROM informatica_fields f 
        INNER JOIN informatica_workflows w ON f.workflow_id = w.workflow_id 
        WHERE w.is_active = 1;
    SELECT @unique_repositories = COUNT(DISTINCT repository_name) 
        FROM informatica_workflows WHERE is_active = 1;
    SELECT @unique_folders = COUNT(DISTINCT folder_name) 
        FROM informatica_workflows WHERE is_active = 1;
    
    -- Calculate averages
    IF @total_workflows > 0
    BEGIN
        SET @avg_sources_per_workflow = CAST(@total_sources AS DECIMAL(10,2)) / @total_workflows;
        SET @avg_fields_per_workflow = CAST(@total_fields AS DECIMAL(10,2)) / @total_workflows;
    END
    ELSE
    BEGIN
        SET @avg_sources_per_workflow = 0;
        SET @avg_fields_per_workflow = 0;
    END
    
    -- Insert summary record
    INSERT INTO informatica_analysis_summary (
        analysis_date,
        total_workflows,
        total_sources,
        total_transformations,
        total_targets,
        total_mappings,
        total_fields,
        unique_repositories,
        unique_folders,
        avg_sources_per_workflow,
        avg_fields_per_workflow,
        analysis_notes
    )
    VALUES (
        GETDATE(),
        @total_workflows,
        @total_sources,
        @total_transformations,
        @total_targets,
        @total_mappings,
        @total_fields,
        @unique_repositories,
        @unique_folders,
        @avg_sources_per_workflow,
        @avg_fields_per_workflow,
        'Auto-generated summary'
    );
    
END;

GO

-- Create view for workflow summary
CREATE VIEW vw_workflow_summary AS
SELECT 
    w.workflow_id,
    w.workflow_name,
    w.workflow_path,
    w.folder_name,
    w.repository_name,
    w.creation_date,
    w.parsed_date,
    w.file_size,
    COUNT(DISTINCT s.source_id) as source_count,
    COUNT(DISTINCT t.transformation_id) as transformation_count,
    COUNT(DISTINCT tg.target_id) as target_count,
    COUNT(DISTINCT m.mapping_id) as mapping_count,
    COUNT(DISTINCT f.field_id) as field_count
FROM informatica_workflows w
LEFT JOIN informatica_sources s ON w.workflow_id = s.workflow_id
LEFT JOIN informatica_transformations t ON w.workflow_id = t.workflow_id
LEFT JOIN informatica_targets tg ON w.workflow_id = tg.workflow_id
LEFT JOIN informatica_mappings m ON w.workflow_id = m.workflow_id
LEFT JOIN informatica_fields f ON w.workflow_id = f.workflow_id
WHERE w.is_active = 1
GROUP BY 
    w.workflow_id,
    w.workflow_name,
    w.workflow_path,
    w.folder_name,
    w.repository_name,
    w.creation_date,
    w.parsed_date,
    w.file_size;

GO

-- Create view for field analysis
CREATE VIEW vw_field_analysis AS
SELECT 
    w.workflow_name,
    w.folder_name,
    f.source_name,
    f.field_name,
    f.data_type,
    f.length,
    f.precision_val,
    f.scale_val,
    f.nullable,
    f.key_type,
    CASE 
        WHEN f.key_type LIKE '%KEY%' THEN 'Key Field'
        WHEN f.nullable = 'NULL' THEN 'Nullable'
        ELSE 'Regular'
    END as field_category
FROM informatica_fields f
INNER JOIN informatica_workflows w ON f.workflow_id = w.workflow_id
WHERE w.is_active = 1;

GO

-- Create indexes on views for better performance
CREATE INDEX IX_vw_workflow_summary_name ON informatica_workflows(workflow_name) 
    INCLUDE (folder_name, repository_name, parsed_date);

GO

-- Insert initial analysis summary
EXEC sp_refresh_analysis_summary;

GO

PRINT 'Informatica Workflow Analyzer database tables created successfully!';
