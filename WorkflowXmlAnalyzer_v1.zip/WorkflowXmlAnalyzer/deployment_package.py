#!/usr/bin/env python3
"""
Deployment Package Generator for Informatica Workflow Analyzer
Creates a complete standalone package for company laptop deployment
"""

import os
import shutil
import zipfile
from datetime import datetime

def create_deployment_package():
    """Create deployment package for company laptop"""
    
    # Package information
    package_name = "informatica_workflow_analyzer_deployment"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    package_dir = f"{package_name}_{timestamp}"
    
    print(f"Creating deployment package: {package_dir}")
    
    # Create package directory
    if os.path.exists(package_dir):
        shutil.rmtree(package_dir)
    os.makedirs(package_dir)
    
    # Copy main application file
    shutil.copy2("standalone_informatica_analyzer.py", 
                os.path.join(package_dir, "informatica_analyzer.py"))
    
    # Copy sample XML files for testing
    sample_dir = os.path.join(package_dir, "sample_xml_files")
    os.makedirs(sample_dir)
    
    # Copy attached XML files if they exist
    attached_files = [
        "attached_assets/wf_landing_sfdc_to_cdm_contact_party.xml",
        "attached_assets/wf_landing_sfdc_to_cdm_organization_party.xml", 
        "attached_assets/wf_landing_sfdc_to_cdm_office_party.xml"
    ]
    
    for file_path in attached_files:
        if os.path.exists(file_path):
            shutil.copy2(file_path, sample_dir)
    
    # Create installation instructions
    install_instructions = """
Informatica Workflow Analyzer - Installation Instructions
=========================================================

SYSTEM REQUIREMENTS:
- Windows 10/11 with Python 3.7+
- Microsoft SQL Server with ODBC Driver 17
- Network access to SQL Server: w908925\\CGSQL

INSTALLATION STEPS:

1. Install Python Dependencies:
   pip install pyodbc pandas openpyxl

2. Verify Database Connection:
   - Ensure SQL Server is accessible
   - Test connection to: w908925\\CGSQL
   - Database: msscdm_dev4
   - Username: spark_user
   - Password: spark@25091990

3. Run the Application:
   python informatica_analyzer.py

FEATURES:
- Parse Informatica PowerCenter XML workflow files
- Extract sources, transformations, targets, and field information
- Store analysis results in MS SQL Server database
- Search and filter workflows
- Export data to Excel/CSV formats
- Detailed workflow analysis and reporting

CONFIGURATION:
The application is pre-configured for your company environment:
- Server: w908925\\CGSQL
- Database: msscdm_dev4
- Authentication: SQL Server authentication

TROUBLESHOOTING:
If database connection fails:
1. Verify SQL Server is running
2. Check ODBC Driver 17 for SQL Server is installed
3. Confirm network connectivity to database server
4. Validate credentials and permissions

USAGE:
1. Start the application
2. Use "File Processing" tab to select XML files
3. Process files to extract metadata
4. View results in "Workflow Analysis" tab
5. Export data using "Export" tab

SAMPLE FILES:
Sample Informatica XML files are included in the sample_xml_files folder
for testing the application functionality.

For support, contact the development team.
"""
    
    with open(os.path.join(package_dir, "INSTALLATION_INSTRUCTIONS.txt"), 'w') as f:
        f.write(install_instructions)
    
    # Create requirements file
    requirements = """pyodbc==5.0.1
pandas==2.1.4
openpyxl==3.1.2"""
    
    with open(os.path.join(package_dir, "requirements.txt"), 'w') as f:
        f.write(requirements)
    
    # Create database setup script
    db_setup_script = """
-- Database Setup Script for Informatica Workflow Analyzer
-- Run this script if tables don't exist or need to be recreated

USE msscdm_dev4;
GO

-- Create main workflows table if not exists
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_workflows' AND xtype='U')
CREATE TABLE informatica_workflows (
    workflow_id INT IDENTITY(1,1) PRIMARY KEY,
    workflow_name NVARCHAR(255) NOT NULL,
    workflow_path NVARCHAR(1000) NOT NULL,
    creation_date DATETIME2,
    repository_name NVARCHAR(255),
    folder_name NVARCHAR(255),
    description NVARCHAR(1000),
    parsed_date DATETIME2 NOT NULL DEFAULT GETDATE(),
    file_size BIGINT,
    created_date DATETIME2 DEFAULT GETDATE()
);

-- Create sources table if not exists
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_sources' AND xtype='U')
CREATE TABLE informatica_sources (
    source_id INT IDENTITY(1,1) PRIMARY KEY,
    workflow_id INT NOT NULL,
    source_name NVARCHAR(255) NOT NULL,
    database_type NVARCHAR(100),
    db_name NVARCHAR(255),
    description NVARCHAR(1000),
    owner_name NVARCHAR(100),
    field_count INT DEFAULT 0,
    created_date DATETIME2 DEFAULT GETDATE()
);

-- Create fields table if not exists
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_fields' AND xtype='U')
CREATE TABLE informatica_fields (
    field_id INT IDENTITY(1,1) PRIMARY KEY,
    workflow_id INT NOT NULL,
    source_name NVARCHAR(255),
    field_name NVARCHAR(255) NOT NULL,
    data_type NVARCHAR(100),
    length INT DEFAULT 0,
    precision_val INT DEFAULT 0,
    scale_val INT DEFAULT 0,
    nullable NVARCHAR(10),
    key_type NVARCHAR(50),
    field_number INT,
    created_date DATETIME2 DEFAULT GETDATE()
);

-- Create indexes for performance
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_workflows_name')
CREATE INDEX IX_workflows_name ON informatica_workflows(workflow_name);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_sources_workflow')
CREATE INDEX IX_sources_workflow ON informatica_sources(workflow_id);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_fields_workflow')
CREATE INDEX IX_fields_workflow ON informatica_fields(workflow_id);

PRINT 'Database setup completed successfully!';
"""
    
    with open(os.path.join(package_dir, "database_setup.sql"), 'w') as f:
        f.write(db_setup_script)
    
    # Create batch file for easy execution
    batch_file = """@echo off
echo Starting Informatica Workflow Analyzer...
echo.
echo Checking Python installation...
python --version
if errorlevel 1 (
    echo Python is not installed or not in PATH
    echo Please install Python 3.7+ and try again
    pause
    exit /b 1
)

echo.
echo Installing dependencies...
pip install -r requirements.txt

echo.
echo Starting application...
python informatica_analyzer.py

pause
"""
    
    with open(os.path.join(package_dir, "start_analyzer.bat"), 'w') as f:
        f.write(batch_file)
    
    print(f"Deployment package created successfully in: {package_dir}")
    print("\nPackage contents:")
    for root, dirs, files in os.walk(package_dir):
        level = root.replace(package_dir, '').count(os.sep)
        indent = ' ' * 2 * level
        print(f"{indent}{os.path.basename(root)}/")
        subindent = ' ' * 2 * (level + 1)
        for file in files:
            print(f"{subindent}{file}")
    
    print("\nDeployment package is ready for transfer to company laptop!")
    return package_dir

if __name__ == "__main__":
    create_deployment_package()