"""
Main GUI Application for Informatica Workflow Analyzer
Desktop interface built with tkinter
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import pandas as pd
import threading
import queue
import os
from datetime import datetime
from typing import List, Dict, Any, Optional
import logging

from xml_parser import InformaticaXMLParser
from database_manager import DatabaseManager
from config import APP_CONFIG, GUI_CONFIG, EXPORT_CONFIG
from utils import format_file_size, export_to_excel, export_to_csv

class InformaticaAnalyzerGUI:
    """Main GUI application class"""
    
    def __init__(self, root: tk.Tk):
        self.root = root
        self.logger = logging.getLogger(__name__)
        
        # Initialize components
        self.xml_parser = InformaticaXMLParser()
        self.db_manager = DatabaseManager()
        
        # GUI state
        self.current_workflows = []
        self.selected_workflow_id = None
        self.progress_queue = queue.Queue()
        
        # Setup GUI
        self.setup_window()
        self.create_widgets()
        self.setup_bindings()
        
        # Initialize database tables
        self.initialize_database()
        
        # Load existing data
        self.refresh_workflow_list()
    
    def setup_window(self):
        """Configure main window"""
        config = APP_CONFIG
        
        self.root.title(config['app_name'])
        self.root.geometry(f"{config['window_width']}x{config['window_height']}")
        self.root.minsize(config['min_width'], config['min_height'])
        
        # Configure style
        style = ttk.Style()
        style.theme_use('vista' if 'vista' in style.theme_names() else 'default')
        
        # Configure colors
        colors = GUI_CONFIG['colors']
        self.root.configure(bg=colors['background'])
    
    def create_widgets(self):
        """Create and layout GUI widgets"""
        # Create main frame
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create notebook for tabs
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # Create tabs
        self.create_file_processing_tab()
        self.create_workflow_analysis_tab()
        self.create_detailed_view_tab()
        self.create_export_tab()
        
        # Create status bar
        self.create_status_bar()
    
    def create_file_processing_tab(self):
        """Create file processing tab"""
        tab_frame = ttk.Frame(self.notebook)
        self.notebook.add(tab_frame, text="File Processing")
        
        # File selection frame
        file_frame = ttk.LabelFrame(tab_frame, text="XML File Selection", padding=10)
        file_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # File selection buttons
        button_frame = ttk.Frame(file_frame)
        button_frame.pack(fill=tk.X)
        
        ttk.Button(button_frame, text="Select Single File", 
                  command=self.select_single_file).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Select Multiple Files", 
                  command=self.select_multiple_files).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Select Folder", 
                  command=self.select_folder).pack(side=tk.LEFT, padx=5)
        
        # Selected files list
        list_frame = ttk.LabelFrame(tab_frame, text="Selected Files", padding=10)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create treeview for files
        columns = ('filename', 'path', 'size', 'status')
        self.files_tree = ttk.Treeview(list_frame, columns=columns, show='headings', height=10)
        
        # Configure columns
        self.files_tree.heading('filename', text='Filename')
        self.files_tree.heading('path', text='Path')
        self.files_tree.heading('size', text='Size')
        self.files_tree.heading('status', text='Status')
        
        self.files_tree.column('filename', width=200)
        self.files_tree.column('path', width=300)
        self.files_tree.column('size', width=100)
        self.files_tree.column('status', width=100)
        
        # Add scrollbars
        files_scrollbar_v = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.files_tree.yview)
        files_scrollbar_h = ttk.Scrollbar(list_frame, orient=tk.HORIZONTAL, command=self.files_tree.xview)
        self.files_tree.configure(yvscrollcommand=files_scrollbar_v.set, xscrollcommand=files_scrollbar_h.set)
        
        # Pack treeview and scrollbars
        self.files_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        files_scrollbar_v.pack(side=tk.RIGHT, fill=tk.Y)
        files_scrollbar_h.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Processing controls
        control_frame = ttk.Frame(tab_frame)
        control_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(control_frame, text="Process Files", 
                  command=self.process_selected_files).pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="Clear List", 
                  command=self.clear_file_list).pack(side=tk.LEFT, padx=5)
        
        # Progress bar
        progress_frame = ttk.Frame(tab_frame)
        progress_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(progress_frame, text="Progress:").pack(side=tk.LEFT)
        self.progress_var = tk.StringVar(value="Ready")
        self.progress_label = ttk.Label(progress_frame, textvariable=self.progress_var)
        self.progress_label.pack(side=tk.LEFT, padx=10)
        
        self.progress_bar = ttk.Progressbar(progress_frame, mode='determinate')
        self.progress_bar.pack(fill=tk.X, expand=True, padx=10)
    
    def create_workflow_analysis_tab(self):
        """Create workflow analysis tab"""
        tab_frame = ttk.Frame(self.notebook)
        self.notebook.add(tab_frame, text="Workflow Analysis")
        
        # Search frame
        search_frame = ttk.LabelFrame(tab_frame, text="Search & Filter", padding=10)
        search_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(search_frame, text="Search:").pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        
        ttk.Button(search_frame, text="Search", 
                  command=self.search_workflows).pack(side=tk.LEFT, padx=5)
        ttk.Button(search_frame, text="Refresh", 
                  command=self.refresh_workflow_list).pack(side=tk.LEFT, padx=5)
        
        # Workflow list
        list_frame = ttk.LabelFrame(tab_frame, text="Workflows", padding=10)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create treeview for workflows
        columns = ('workflow_name', 'folder_name', 'repository_name', 'source_count', 'field_count', 'parsed_date')
        self.workflows_tree = ttk.Treeview(list_frame, columns=columns, show='headings')
        
        # Configure columns
        self.workflows_tree.heading('workflow_name', text='Workflow Name')
        self.workflows_tree.heading('folder_name', text='Folder')
        self.workflows_tree.heading('repository_name', text='Repository')
        self.workflows_tree.heading('source_count', text='Sources')
        self.workflows_tree.heading('field_count', text='Fields')
        self.workflows_tree.heading('parsed_date', text='Parsed Date')
        
        self.workflows_tree.column('workflow_name', width=250)
        self.workflows_tree.column('folder_name', width=150)
        self.workflows_tree.column('repository_name', width=150)
        self.workflows_tree.column('source_count', width=80)
        self.workflows_tree.column('field_count', width=80)
        self.workflows_tree.column('parsed_date', width=150)
        
        # Add scrollbars
        workflow_scrollbar_v = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.workflows_tree.yview)
        workflow_scrollbar_h = ttk.Scrollbar(list_frame, orient=tk.HORIZONTAL, command=self.workflows_tree.xview)
        self.workflows_tree.configure(yvscrollcommand=workflow_scrollbar_v.set, xscrollcommand=workflow_scrollbar_h.set)
        
        # Pack treeview and scrollbars
        self.workflows_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        workflow_scrollbar_v.pack(side=tk.RIGHT, fill=tk.Y)
        workflow_scrollbar_h.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Statistics frame
        stats_frame = ttk.LabelFrame(tab_frame, text="Statistics", padding=10)
        stats_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.stats_text = scrolledtext.ScrolledText(stats_frame, height=6, state=tk.DISABLED)
        self.stats_text.pack(fill=tk.BOTH, expand=True)
    
    def create_detailed_view_tab(self):
        """Create detailed view tab"""
        tab_frame = ttk.Frame(self.notebook)
        self.notebook.add(tab_frame, text="Detailed View")
        
        # Create paned window for split view
        paned = ttk.PanedWindow(tab_frame, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Left panel - workflow info
        left_frame = ttk.LabelFrame(paned, text="Workflow Information", padding=10)
        paned.add(left_frame, weight=1)
        
        self.workflow_info_text = scrolledtext.ScrolledText(left_frame, height=15, state=tk.DISABLED)
        self.workflow_info_text.pack(fill=tk.BOTH, expand=True)
        
        # Right panel - tabbed details
        right_frame = ttk.Frame(paned)
        paned.add(right_frame, weight=2)
        
        detail_notebook = ttk.Notebook(right_frame)
        detail_notebook.pack(fill=tk.BOTH, expand=True)
        
        # Sources tab
        sources_frame = ttk.Frame(detail_notebook)
        detail_notebook.add(sources_frame, text="Sources")
        
        self.sources_tree = self._create_detail_tree(sources_frame, 
            ('name', 'database_type', 'db_name', 'field_count'),
            ('Source Name', 'Database Type', 'DB Name', 'Fields'))
        
        # Fields tab
        fields_frame = ttk.Frame(detail_notebook)
        detail_notebook.add(fields_frame, text="Fields")
        
        self.fields_tree = self._create_detail_tree(fields_frame,
            ('source_name', 'field_name', 'data_type', 'length', 'nullable'),
            ('Source', 'Field Name', 'Data Type', 'Length', 'Nullable'))
    
    def _create_detail_tree(self, parent, columns, headings):
        """Helper to create detail treeview"""
        tree = ttk.Treeview(parent, columns=columns, show='headings')
        
        for col, heading in zip(columns, headings):
            tree.heading(col, text=heading)
            tree.column(col, width=150)
        
        # Add scrollbars
        scrollbar_v = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=tree.yview)
        scrollbar_h = ttk.Scrollbar(parent, orient=tk.HORIZONTAL, command=tree.xview)
        tree.configure(yvscrollcommand=scrollbar_v.set, xscrollcommand=scrollbar_h.set)
        
        # Pack
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar_v.pack(side=tk.RIGHT, fill=tk.Y)
        scrollbar_h.pack(side=tk.BOTTOM, fill=tk.X)
        
        return tree
    
    def create_export_tab(self):
        """Create export tab"""
        tab_frame = ttk.Frame(self.notebook)
        self.notebook.add(tab_frame, text="Export")
        
        # Export options
        options_frame = ttk.LabelFrame(tab_frame, text="Export Options", padding=10)
        options_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Format selection
        format_frame = ttk.Frame(options_frame)
        format_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(format_frame, text="Format:").pack(side=tk.LEFT)
        self.export_format = tk.StringVar(value="xlsx")
        ttk.Radiobutton(format_frame, text="Excel (.xlsx)", variable=self.export_format, 
                       value="xlsx").pack(side=tk.LEFT, padx=10)
        ttk.Radiobutton(format_frame, text="CSV (.csv)", variable=self.export_format, 
                       value="csv").pack(side=tk.LEFT, padx=10)
        
        # Export scope
        scope_frame = ttk.Frame(options_frame)
        scope_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(scope_frame, text="Scope:").pack(side=tk.LEFT)
        self.export_scope = tk.StringVar(value="all")
        ttk.Radiobutton(scope_frame, text="All Workflows", variable=self.export_scope, 
                       value="all").pack(side=tk.LEFT, padx=10)
        ttk.Radiobutton(scope_frame, text="Selected Workflow", variable=self.export_scope, 
                       value="selected").pack(side=tk.LEFT, padx=10)
        
        # Export buttons
        button_frame = ttk.Frame(options_frame)
        button_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(button_frame, text="Export Data", 
                  command=self.export_data).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Export Summary Report", 
                  command=self.export_summary_report).pack(side=tk.LEFT, padx=5)
        
        # Export log
        log_frame = ttk.LabelFrame(tab_frame, text="Export Log", padding=10)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.export_log = scrolledtext.ScrolledText(log_frame, height=10, state=tk.DISABLED)
        self.export_log.pack(fill=tk.BOTH, expand=True)
    
    def create_status_bar(self):
        """Create status bar at bottom"""
        self.status_bar = ttk.Frame(self.root)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
        self.status_var = tk.StringVar(value="Ready")
        status_label = ttk.Label(self.status_bar, textvariable=self.status_var)
        status_label.pack(side=tk.LEFT, padx=10, pady=5)
        
        # Add connection status
        self.connection_var = tk.StringVar(value="Connected")
        connection_label = ttk.Label(self.status_bar, textvariable=self.connection_var)
        connection_label.pack(side=tk.RIGHT, padx=10, pady=5)
    
    def setup_bindings(self):
        """Setup event bindings"""
        # Workflow selection
        self.workflows_tree.bind('<<TreeviewSelect>>', self.on_workflow_select)
        
        # Search on Enter
        self.search_var.trace_add('write', self.on_search_change)
        
        # Double-click to view details
        self.workflows_tree.bind('<Double-1>', self.on_workflow_double_click)
    
    def initialize_database(self):
        """Initialize database tables"""
        try:
            self.db_manager.create_tables()
            self.update_status("Database initialized successfully")
        except Exception as e:
            self.logger.error(f"Database initialization failed: {str(e)}")
            messagebox.showerror("Database Error", 
                               f"Failed to initialize database:\n{str(e)}")
    
    def select_single_file(self):
        """Select single XML file"""
        file_path = filedialog.askopenfilename(
            title="Select Informatica XML File",
            filetypes=[("XML files", "*.xml"), ("All files", "*.*")]
        )
        
        if file_path:
            self.add_file_to_list(file_path)
    
    def select_multiple_files(self):
        """Select multiple XML files"""
        file_paths = filedialog.askopenfilenames(
            title="Select Informatica XML Files",
            filetypes=[("XML files", "*.xml"), ("All files", "*.*")]
        )
        
        for file_path in file_paths:
            self.add_file_to_list(file_path)
    
    def select_folder(self):
        """Select folder containing XML files"""
        folder_path = filedialog.askdirectory(title="Select Folder with XML Files")
        
        if folder_path:
            xml_files = []
            for root, dirs, files in os.walk(folder_path):
                for file in files:
                    if file.lower().endswith('.xml'):
                        xml_files.append(os.path.join(root, file))
            
            if xml_files:
                for file_path in xml_files:
                    self.add_file_to_list(file_path)
                self.update_status(f"Added {len(xml_files)} XML files from folder")
            else:
                messagebox.showinfo("No Files", "No XML files found in selected folder")
    
    def add_file_to_list(self, file_path: str):
        """Add file to processing list"""
        # Check if file already exists
        for item in self.files_tree.get_children():
            if self.files_tree.item(item)['values'][1] == file_path:
                return  # File already in list
        
        filename = os.path.basename(file_path)
        file_size = format_file_size(os.path.getsize(file_path))
        
        self.files_tree.insert('', tk.END, values=(filename, file_path, file_size, 'Pending'))
    
    def clear_file_list(self):
        """Clear file list"""
        for item in self.files_tree.get_children():
            self.files_tree.delete(item)
    
    def process_selected_files(self):
        """Process selected XML files"""
        files = []
        for item in self.files_tree.get_children():
            values = self.files_tree.item(item)['values']
            if values[3] == 'Pending':  # Status column
                files.append({'item': item, 'path': values[1]})
        
        if not files:
            messagebox.showinfo("No Files", "No pending files to process")
            return
        
        # Start processing in background thread
        self.progress_bar['maximum'] = len(files)
        self.progress_bar['value'] = 0
        
        thread = threading.Thread(target=self.process_files_thread, args=(files,))
        thread.daemon = True
        thread.start()
        
        # Start monitoring progress
        self.monitor_progress()
    
    def process_files_thread(self, files: List[Dict]):
        """Process files in background thread"""
        processed = 0
        
        for file_info in files:
            try:
                file_path = file_info['path']
                item = file_info['item']
                
                # Update status
                self.progress_queue.put({
                    'type': 'progress',
                    'item': item,
                    'status': 'Processing...',
                    'value': processed
                })
                
                # Parse XML file
                workflow_data = self.xml_parser.parse_workflow_file(file_path)
                
                # Save to database
                workflow_id = self.db_manager.insert_workflow_data(workflow_data)
                
                # Save sources and fields
                if workflow_data.get('sources'):
                    self.db_manager.insert_source_data(workflow_id, workflow_data['sources'])
                    
                    for source in workflow_data['sources']:
                        if source.get('fields'):
                            self.db_manager.insert_field_data(
                                workflow_id, source['name'], source['fields']
                            )
                
                # Update status
                self.progress_queue.put({
                    'type': 'progress',
                    'item': item,
                    'status': 'Completed',
                    'value': processed + 1
                })
                
                processed += 1
                
            except Exception as e:
                self.logger.error(f"Error processing file {file_path}: {str(e)}")
                self.progress_queue.put({
                    'type': 'progress',
                    'item': item,
                    'status': f'Error: {str(e)[:50]}...',
                    'value': processed
                })
        
        # Signal completion
        self.progress_queue.put({'type': 'complete', 'processed': processed})
    
    def monitor_progress(self):
        """Monitor progress queue and update GUI"""
        try:
            while True:
                progress_info = self.progress_queue.get_nowait()
                
                if progress_info['type'] == 'progress':
                    # Update file status
                    item = progress_info['item']
                    status = progress_info['status']
                    
                    values = list(self.files_tree.item(item)['values'])
                    values[3] = status  # Status column
                    self.files_tree.item(item, values=values)
                    
                    # Update progress bar
                    self.progress_bar['value'] = progress_info['value']
                    self.progress_var.set(f"Processing file {progress_info['value'] + 1}...")
                
                elif progress_info['type'] == 'complete':
                    processed = progress_info['processed']
                    self.progress_var.set(f"Completed! Processed {processed} files")
                    self.update_status(f"Successfully processed {processed} XML files")
                    
                    # Refresh workflow list
                    self.refresh_workflow_list()
                    return
                    
        except queue.Empty:
            pass
        
        # Schedule next check
        self.root.after(100, self.monitor_progress)
    
    def refresh_workflow_list(self):
        """Refresh workflow list from database"""
        try:
            # Clear existing items
            for item in self.workflows_tree.get_children():
                self.workflows_tree.delete(item)
            
            # Get workflow summary
            df = self.db_manager.get_workflow_summary()
            
            for _, row in df.iterrows():
                self.workflows_tree.insert('', tk.END, values=(
                    row['workflow_name'],
                    row['folder_name'],
                    row['repository_name'],
                    row['source_count'],
                    row['field_count'],
                    row['parsed_date'].strftime('%Y-%m-%d %H:%M') if pd.notna(row['parsed_date']) else ''
                ))
            
            # Update statistics
            self.update_statistics(df)
            self.update_status(f"Loaded {len(df)} workflows")
            
        except Exception as e:
            self.logger.error(f"Error refreshing workflow list: {str(e)}")
            messagebox.showerror("Database Error", 
                               f"Failed to load workflows:\n{str(e)}")
    
    def search_workflows(self):
        """Search workflows"""
        search_term = self.search_var.get().strip()
        
        if not search_term:
            self.refresh_workflow_list()
            return
        
        try:
            # Clear existing items
            for item in self.workflows_tree.get_children():
                self.workflows_tree.delete(item)
            
            # Search workflows
            df = self.db_manager.search_workflows(search_term)
            
            for _, row in df.iterrows():
                self.workflows_tree.insert('', tk.END, values=(
                    row['workflow_name'],
                    row['folder_name'],
                    row['repository_name'],
                    row['source_count'],
                    '',  # field_count not in search results
                    row['parsed_date'].strftime('%Y-%m-%d %H:%M') if pd.notna(row['parsed_date']) else ''
                ))
            
            self.update_status(f"Found {len(df)} workflows matching '{search_term}'")
            
        except Exception as e:
            self.logger.error(f"Error searching workflows: {str(e)}")
            messagebox.showerror("Search Error", 
                               f"Search failed:\n{str(e)}")
    
    def on_search_change(self, *args):
        """Handle search text changes"""
        # Implement debounced search if needed
        pass
    
    def on_workflow_select(self, event):
        """Handle workflow selection"""
        selection = self.workflows_tree.selection()
        if not selection:
            return
        
        item = selection[0]
        workflow_name = self.workflows_tree.item(item)['values'][0]
        
        try:
            # Find workflow ID
            df = self.db_manager.get_workflow_summary()
            workflow_row = df[df['workflow_name'] == workflow_name]
            
            if not workflow_row.empty:
                # Get workflow details (assuming workflow_id is available)
                # For now, we'll use a simple approach
                self.load_workflow_details(workflow_name)
                
        except Exception as e:
            self.logger.error(f"Error loading workflow details: {str(e)}")
    
    def on_workflow_double_click(self, event):
        """Handle workflow double-click"""
        self.notebook.select(2)  # Switch to detailed view tab
    
    def load_workflow_details(self, workflow_name: str):
        """Load detailed workflow information"""
        try:
            # This is a simplified version - you might need to enhance this
            # based on your actual database schema
            
            # Clear existing data
            self.workflow_info_text.config(state=tk.NORMAL)
            self.workflow_info_text.delete(1.0, tk.END)
            
            for item in self.sources_tree.get_children():
                self.sources_tree.delete(item)
            
            for item in self.fields_tree.get_children():
                self.fields_tree.delete(item)
            
            # Display workflow info
            info_text = f"Workflow: {workflow_name}\n"
            info_text += f"Loading detailed information...\n"
            
            self.workflow_info_text.insert(tk.END, info_text)
            self.workflow_info_text.config(state=tk.DISABLED)
            
        except Exception as e:
            self.logger.error(f"Error loading workflow details: {str(e)}")
    
    def update_statistics(self, df: pd.DataFrame):
        """Update statistics display"""
        try:
            self.stats_text.config(state=tk.NORMAL)
            self.stats_text.delete(1.0, tk.END)
            
            if df.empty:
                self.stats_text.insert(tk.END, "No workflows loaded.")
                self.stats_text.config(state=tk.DISABLED)
                return
            
            stats = f"Total Workflows: {len(df)}\n"
            stats += f"Total Sources: {df['source_count'].sum()}\n"
            stats += f"Total Fields: {df['field_count'].sum()}\n\n"
            
            # Repository breakdown
            repo_counts = df.groupby('repository_name').size()
            stats += "Repositories:\n"
            for repo, count in repo_counts.items():
                stats += f"  {repo}: {count} workflows\n"
            
            stats += "\n"
            
            # Folder breakdown
            folder_counts = df.groupby('folder_name').size().head(10)
            stats += "Top Folders:\n"
            for folder, count in folder_counts.items():
                stats += f"  {folder}: {count} workflows\n"
            
            self.stats_text.insert(tk.END, stats)
            self.stats_text.config(state=tk.DISABLED)
            
        except Exception as e:
            self.logger.error(f"Error updating statistics: {str(e)}")
    
    def export_data(self):
        """Export workflow data"""
        try:
            format_type = self.export_format.get()
            scope = self.export_scope.get()
            
            # Determine workflow IDs to export
            workflow_ids = None
            if scope == "selected" and self.selected_workflow_id:
                workflow_ids = [self.selected_workflow_id]
            
            # Get data
            df = self.db_manager.export_workflow_data(workflow_ids)
            
            if df.empty:
                messagebox.showinfo("No Data", "No data to export")
                return
            
            # Select file path
            default_filename = f"informatica_workflows_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            file_path = filedialog.asksaveasfilename(
                defaultextension=f".{format_type}",
                filetypes=[(f"{format_type.upper()} files", f"*.{format_type}")],
                initialname=default_filename
            )
            
            if not file_path:
                return
            
            # Export data
            if format_type == "xlsx":
                export_to_excel(df, file_path)
            else:
                export_to_csv(df, file_path)
            
            # Log export
            self.log_export(f"Successfully exported {len(df)} records to {file_path}")
            messagebox.showinfo("Export Complete", f"Data exported to:\n{file_path}")
            
        except Exception as e:
            self.logger.error(f"Error exporting data: {str(e)}")
            messagebox.showerror("Export Error", f"Export failed:\n{str(e)}")
    
    def export_summary_report(self):
        """Export summary report"""
        try:
            df = self.db_manager.get_workflow_summary()
            
            if df.empty:
                messagebox.showinfo("No Data", "No workflows to export")
                return
            
            # Select file path
            default_filename = f"workflow_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            file_path = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx")],
                initialname=default_filename
            )
            
            if not file_path:
                return
            
            # Export summary
            export_to_excel(df, file_path)
            
            # Log export
            self.log_export(f"Successfully exported workflow summary to {file_path}")
            messagebox.showinfo("Export Complete", f"Summary exported to:\n{file_path}")
            
        except Exception as e:
            self.logger.error(f"Error exporting summary: {str(e)}")
            messagebox.showerror("Export Error", f"Summary export failed:\n{str(e)}")
    
    def log_export(self, message: str):
        """Log export message"""
        self.export_log.config(state=tk.NORMAL)
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.export_log.insert(tk.END, f"[{timestamp}] {message}\n")
        self.export_log.see(tk.END)
        self.export_log.config(state=tk.DISABLED)
    
    def update_status(self, message: str):
        """Update status bar"""
        self.status_var.set(message)
        self.logger.info(message)
