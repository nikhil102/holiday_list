#!/usr/bin/env python3
"""
Informatica Workflow XML Parser and Analyzer - Fixed Version
Complete desktop application for company laptop deployment
Includes all dependencies and MS SQL Server integration
"""

import sys
import os
import logging
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import Dict, List, Any, Optional
import threading
import queue
import re

# Database imports
try:
    import pyodbc
    import pandas as pd
    HAS_DEPENDENCIES = True
except ImportError as e:
    HAS_DEPENDENCIES = False
    MISSING_DEPS = str(e)

# Excel export
try:
    from openpyxl import Workbook
    HAS_EXCEL = True
except ImportError:
    HAS_EXCEL = False

class InformaticaConfig:
    """Configuration for the application"""
    
    # Database Configuration - Company Laptop Settings
    DATABASE_CONFIG = {
        'driver': '{ODBC Driver 17 for SQL Server}',
        'server': 'w908925\\CGSQL',
        'database': 'msscdm_dev4',
        'username': 'spark_user',
        'password': 'spark@25091990',
        'trusted_connection': 'no',
        'connection_timeout': 30,
        'command_timeout': 30
    }
    
    # Application Configuration
    APP_CONFIG = {
        'app_name': 'Informatica Workflow Analyzer',
        'version': '1.0.0',
        'window_width': 1200,
        'window_height': 800,
        'min_width': 800,
        'min_height': 600
    }

class DatabaseManager:
    """Manages database connections and operations"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.config = InformaticaConfig.DATABASE_CONFIG
        self.connection_string = self._build_connection_string()
        
    def _build_connection_string(self) -> str:
        """Build ODBC connection string"""
        return (
            f"DRIVER={self.config['driver']};"
            f"SERVER={self.config['server']};"
            f"DATABASE={self.config['database']};"
            f"UID={self.config['username']};"
            f"PWD={self.config['password']};"
            f"TrustServerCertificate=yes;"
            f"Encrypt=no;"
            f"Connection Timeout={self.config['connection_timeout']};"
        )
    
    def get_connection(self):
        """Get database connection"""
        try:
            conn = pyodbc.connect(self.connection_string)
            return conn
        except Exception as e:
            self.logger.error(f"Database connection failed: {str(e)}")
            raise
    
    def test_connection(self) -> bool:
        """Test database connection"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT 1")
                result = cursor.fetchone()
                self.logger.info("Database connection test successful")
                return result[0] == 1
        except Exception as e:
            self.logger.error(f"Database connection test failed: {str(e)}")
            raise
    
    def create_tables(self) -> bool:
        """Create database tables if they don't exist"""
        try:
            sql_script = """
            -- Create main workflows table if not exists
            IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_workflows' AND xtype='U')
            CREATE TABLE informatica_workflows (
                workflow_id INT IDENTITY(1,1) PRIMARY KEY,
                workflow_name NVARCHAR(255) NOT NULL,
                workflow_path NVARCHAR(1000) NOT NULL,
                creation_date DATETIME2,
                repository_name NVARCHAR(255),
                folder_name NVARCHAR(255),
                description NVARCHAR(1000),
                parsed_date DATETIME2 NOT NULL DEFAULT GETDATE(),
                file_size BIGINT,
                created_date DATETIME2 DEFAULT GETDATE()
            );
            
            -- Create sources table if not exists
            IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_sources' AND xtype='U')
            CREATE TABLE informatica_sources (
                source_id INT IDENTITY(1,1) PRIMARY KEY,
                workflow_id INT NOT NULL,
                source_name NVARCHAR(255) NOT NULL,
                database_type NVARCHAR(100),
                db_name NVARCHAR(255),
                description NVARCHAR(1000),
                owner_name NVARCHAR(100),
                field_count INT DEFAULT 0,
                created_date DATETIME2 DEFAULT GETDATE()
            );
            
            -- Create fields table if not exists
            IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='informatica_fields' AND xtype='U')
            CREATE TABLE informatica_fields (
                field_id INT IDENTITY(1,1) PRIMARY KEY,
                workflow_id INT NOT NULL,
                source_name NVARCHAR(255),
                field_name NVARCHAR(255) NOT NULL,
                data_type NVARCHAR(100),
                length INT DEFAULT 0,
                precision_val INT DEFAULT 0,
                scale_val INT DEFAULT 0,
                nullable NVARCHAR(10),
                key_type NVARCHAR(50),
                field_number INT,
                created_date DATETIME2 DEFAULT GETDATE()
            );
            """
            
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(sql_script)
                conn.commit()
            
            self.logger.info("Database tables created successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create tables: {str(e)}")
            raise
    
    def insert_workflow_data(self, workflow_data: Dict[str, Any]) -> int:
        """Insert workflow data and return workflow_id"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                workflow_sql = """
                INSERT INTO informatica_workflows 
                (workflow_name, workflow_path, creation_date, repository_name, 
                 folder_name, description, parsed_date, file_size)
                OUTPUT INSERTED.workflow_id
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """
                
                cursor.execute(workflow_sql, (
                    workflow_data.get('workflow_name', ''),
                    workflow_data.get('workflow_path', ''),
                    workflow_data.get('creation_date'),
                    workflow_data.get('repository_name', ''),
                    workflow_data.get('folder_name', ''),
                    workflow_data.get('description', ''),
                    datetime.now(),
                    workflow_data.get('file_size', 0)
                ))
                
                workflow_id = cursor.fetchone()[0]
                conn.commit()
                
                self.logger.info(f"Inserted workflow with ID: {workflow_id}")
                return workflow_id
                
        except Exception as e:
            self.logger.error(f"Failed to insert workflow data: {str(e)}")
            raise
    
    def insert_source_data(self, workflow_id: int, sources: List[Dict[str, Any]]) -> bool:
        """Insert source data for a workflow"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                source_sql = """
                INSERT INTO informatica_sources
                (workflow_id, source_name, database_type, db_name, description, 
                 owner_name, field_count)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """
                
                for source in sources:
                    cursor.execute(source_sql, (
                        workflow_id,
                        source.get('name', ''),
                        source.get('database_type', ''),
                        source.get('db_name', ''),
                        source.get('description', ''),
                        source.get('owner_name', ''),
                        len(source.get('fields', []))
                    ))
                
                conn.commit()
                self.logger.info(f"Inserted {len(sources)} sources for workflow {workflow_id}")
                return True
                
        except Exception as e:
            self.logger.error(f"Failed to insert source data: {str(e)}")
            raise
    
    def insert_field_data(self, workflow_id: int, source_name: str, fields: List[Dict[str, Any]]) -> bool:
        """Insert field data for a source"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                field_sql = """
                INSERT INTO informatica_fields
                (workflow_id, source_name, field_name, data_type, length, 
                 precision_val, scale_val, nullable, key_type, field_number)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """
                
                for field in fields:
                    cursor.execute(field_sql, (
                        workflow_id,
                        source_name,
                        field.get('name', ''),
                        field.get('datatype', ''),
                        field.get('length', 0),
                        field.get('precision', 0),
                        field.get('scale', 0),
                        field.get('nullable', 'NULL'),
                        field.get('keytype', 'NOT A KEY'),
                        field.get('field_number', 0)
                    ))
                
                conn.commit()
                self.logger.info(f"Inserted {len(fields)} fields for source {source_name}")
                return True
                
        except Exception as e:
            self.logger.error(f"Failed to insert field data: {str(e)}")
            raise
    
    def get_workflow_summary(self) -> List[Dict]:
        """Get workflow summary statistics"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                sql = """
                SELECT 
                    w.workflow_name,
                    w.folder_name,
                    w.repository_name,
                    w.parsed_date,
                    COUNT(DISTINCT s.source_id) as source_count,
                    COUNT(DISTINCT f.field_id) as field_count,
                    w.file_size
                FROM informatica_workflows w
                LEFT JOIN informatica_sources s ON w.workflow_id = s.workflow_id
                LEFT JOIN informatica_fields f ON w.workflow_id = f.workflow_id
                GROUP BY w.workflow_id, w.workflow_name, w.folder_name, 
                         w.repository_name, w.parsed_date, w.file_size
                ORDER BY w.parsed_date DESC
                """
                
                cursor.execute(sql)
                columns = [column[0] for column in cursor.description]
                results = []
                for row in cursor.fetchall():
                    results.append(dict(zip(columns, row)))
                
                return results
                
        except Exception as e:
            self.logger.error(f"Failed to get workflow summary: {str(e)}")
            raise

class InformaticaXMLParser:
    """Parser for Informatica PowerCenter XML workflow files"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
    def parse_workflow_file(self, file_path: str) -> Dict[str, Any]:
        """Parse a single workflow XML file"""
        try:
            self.logger.info(f"Parsing workflow file: {file_path}")
            
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"File not found: {file_path}")
            
            if not file_path.lower().endswith('.xml'):
                raise ValueError(f"Invalid file type. Expected .xml file: {file_path}")
            
            file_size = os.path.getsize(file_path)
            
            tree = ET.parse(file_path)
            root = tree.getroot()
            
            workflow_data = self._extract_workflow_metadata(root, file_path, file_size)
            workflow_data['sources'] = self._extract_sources(root)
            workflow_data['transformations'] = self._extract_transformations(root)
            workflow_data['targets'] = self._extract_targets(root)
            
            self.logger.info(f"Successfully parsed workflow: {workflow_data.get('workflow_name', 'Unknown')}")
            return workflow_data
            
        except ET.ParseError as e:
            self.logger.error(f"XML parsing error in file {file_path}: {str(e)}")
            raise ValueError(f"Invalid XML format in file {file_path}: {str(e)}")
        except Exception as e:
            self.logger.error(f"Error parsing workflow file {file_path}: {str(e)}")
            raise
    
    def _extract_workflow_metadata(self, root: ET.Element, file_path: str, file_size: int) -> Dict[str, Any]:
        """Extract basic workflow metadata from XML root"""
        try:
            powermart = root if root.tag == 'POWERMART' else root.find('.//POWERMART')
            if powermart is None:
                raise ValueError("Invalid Informatica XML: POWERMART element not found")
            
            repository = powermart.find('REPOSITORY')
            if repository is None:
                raise ValueError("Invalid Informatica XML: REPOSITORY element not found")
            
            folder = repository.find('FOLDER')
            if folder is None:
                raise ValueError("Invalid Informatica XML: FOLDER element not found")
            
            workflow_name = os.path.splitext(os.path.basename(file_path))[0]
            
            workflow_elem = folder.find('.//WORKFLOW')
            if workflow_elem is not None:
                workflow_name = workflow_elem.get('NAME', workflow_name)
            
            creation_date_str = powermart.get('CREATION_DATE')
            creation_date = self._parse_date(creation_date_str) if creation_date_str else None
            
            metadata = {
                'workflow_name': workflow_name,
                'workflow_path': file_path,
                'file_size': file_size,
                'creation_date': creation_date,
                'repository_name': repository.get('NAME', ''),
                'folder_name': folder.get('NAME', ''),
                'description': folder.get('DESCRIPTION', ''),
            }
            
            return metadata
            
        except Exception as e:
            self.logger.error(f"Error extracting workflow metadata: {str(e)}")
            raise
    
    def _extract_sources(self, root: ET.Element) -> List[Dict[str, Any]]:
        """Extract source system information"""
        sources = []
        
        try:
            source_elements = root.findall('.//SOURCE')
            
            for source_elem in source_elements:
                source_data = {
                    'name': source_elem.get('NAME', ''),
                    'business_name': source_elem.get('BUSINESSNAME', ''),
                    'database_type': source_elem.get('DATABASETYPE', ''),
                    'db_name': source_elem.get('DBDNAME', ''),
                    'description': source_elem.get('DESCRIPTION', ''),
                    'owner_name': source_elem.get('OWNERNAME', ''),
                    'fields': []
                }
                
                source_fields = self._extract_source_fields(source_elem)
                source_data['fields'] = source_fields
                
                sources.append(source_data)
            
            self.logger.info(f"Extracted {len(sources)} sources")
            return sources
            
        except Exception as e:
            self.logger.error(f"Error extracting sources: {str(e)}")
            return []
    
    def _extract_source_fields(self, source_elem: ET.Element) -> List[Dict[str, Any]]:
        """Extract field information from a source"""
        fields = []
        
        try:
            field_elements = source_elem.findall('SOURCEFIELD')
            
            for field_elem in field_elements:
                field_data = {
                    'name': field_elem.get('NAME', ''),
                    'business_name': field_elem.get('BUSINESSNAME', ''),
                    'datatype': field_elem.get('DATATYPE', ''),
                    'description': field_elem.get('DESCRIPTION', ''),
                    'field_number': int(field_elem.get('FIELDNUMBER', '0')),
                    'length': int(field_elem.get('PHYSICALLENGTH', '0')),
                    'precision': int(field_elem.get('PRECISION', '0')),
                    'scale': int(field_elem.get('SCALE', '0')),
                    'nullable': field_elem.get('NULLABLE', ''),
                    'keytype': field_elem.get('KEYTYPE', ''),
                }
                fields.append(field_data)
            
            return sorted(fields, key=lambda x: x['field_number'])
            
        except Exception as e:
            self.logger.error(f"Error extracting source fields: {str(e)}")
            return []
    
    def _extract_transformations(self, root: ET.Element) -> List[Dict[str, Any]]:
        """Extract transformation information"""
        transformations = []
        
        try:
            transformation_elements = root.findall('.//TRANSFORMATION')
            
            for trans_elem in transformation_elements:
                trans_data = {
                    'name': trans_elem.get('NAME', ''),
                    'type': trans_elem.get('TYPE', ''),
                    'subtype': trans_elem.get('SUBTYPE', ''),
                    'description': trans_elem.get('DESCRIPTION', ''),
                    'reusable': trans_elem.get('REUSABLE', 'NO'),
                }
                transformations.append(trans_data)
            
            self.logger.info(f"Extracted {len(transformations)} transformations")
            return transformations
            
        except Exception as e:
            self.logger.error(f"Error extracting transformations: {str(e)}")
            return []
    
    def _extract_targets(self, root: ET.Element) -> List[Dict[str, Any]]:
        """Extract target information"""
        targets = []
        
        try:
            target_elements = root.findall('.//TARGET')
            
            for target_elem in target_elements:
                target_data = {
                    'name': target_elem.get('NAME', ''),
                    'business_name': target_elem.get('BUSINESSNAME', ''),
                    'database_type': target_elem.get('DATABASETYPE', ''),
                    'db_name': target_elem.get('DBDNAME', ''),
                    'description': target_elem.get('DESCRIPTION', ''),
                    'owner_name': target_elem.get('OWNERNAME', ''),
                    'load_type': target_elem.get('LOADTYPE', ''),
                }
                targets.append(target_data)
            
            self.logger.info(f"Extracted {len(targets)} targets")
            return targets
            
        except Exception as e:
            self.logger.error(f"Error extracting targets: {str(e)}")
            return []
    
    def _parse_date(self, date_string: str) -> Optional[datetime]:
        """Parse date string from XML"""
        if not date_string:
            return None
        
        try:
            formats = [
                '%m/%d/%Y %H:%M:%S',
                '%Y-%m-%d %H:%M:%S',
                '%m/%d/%Y',
                '%Y-%m-%d'
            ]
            
            for fmt in formats:
                try:
                    return datetime.strptime(date_string, fmt)
                except ValueError:
                    continue
            
            return None
            
        except Exception:
            return None

class InformaticaAnalyzerGUI:
    """Main GUI application class"""
    
    def __init__(self, root: tk.Tk):
        self.root = root
        self.logger = logging.getLogger(__name__)
        
        # Check dependencies first
        if not HAS_DEPENDENCIES:
            messagebox.showerror(
                "Missing Dependencies",
                f"Required packages are missing:\n{MISSING_DEPS}\n\n"
                "Please install: pip install pyodbc pandas openpyxl"
            )
            return
        
        try:
            self.xml_parser = InformaticaXMLParser()
            self.db_manager = DatabaseManager()
        except Exception as e:
            messagebox.showerror("Initialization Error", f"Failed to initialize components:\n{str(e)}")
            return
        
        self.current_workflows = []
        self.selected_files = []
        self.progress_queue = queue.Queue()
        
        self.setup_window()
        self.create_widgets()
        self.setup_bindings()
        
        # Test database connection and initialize
        self.initialize_database()
        self.refresh_workflow_list()
    
    def setup_window(self):
        """Configure main window"""
        config = InformaticaConfig.APP_CONFIG
        
        self.root.title(f"{config['app_name']} v{config['version']}")
        self.root.geometry(f"{config['window_width']}x{config['window_height']}")
        self.root.minsize(config['min_width'], config['min_height'])
        
        # Configure style
        style = ttk.Style()
        if 'vista' in style.theme_names():
            style.theme_use('vista')
        elif 'clam' in style.theme_names():
            style.theme_use('clam')
    
    def create_widgets(self):
        """Create and layout GUI widgets"""
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        self.create_file_processing_tab()
        self.create_workflow_analysis_tab()
        self.create_detailed_view_tab()
        self.create_export_tab()
        
        self.create_status_bar()
    
    def create_file_processing_tab(self):
        """Create file processing tab"""
        tab_frame = ttk.Frame(self.notebook)
        self.notebook.add(tab_frame, text="File Processing")
        
        # File selection frame
        file_frame = ttk.LabelFrame(tab_frame, text="XML File Selection", padding=10)
        file_frame.pack(fill=tk.X, padx=5, pady=5)
        
        button_frame = ttk.Frame(file_frame)
        button_frame.pack(fill=tk.X)
        
        ttk.Button(button_frame, text="Select Single File", 
                  command=self.select_single_file).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Select Multiple Files", 
                  command=self.select_multiple_files).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Select Folder", 
                  command=self.select_folder).pack(side=tk.LEFT, padx=5)
        
        # Selected files list with proper frame structure
        list_frame = ttk.LabelFrame(tab_frame, text="Selected Files", padding=10)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create container frame for tree and scrollbar
        container_frame = ttk.Frame(list_frame)
        container_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create treeview for files
        columns = ('filename', 'path', 'size', 'status')
        self.files_tree = ttk.Treeview(container_frame, columns=columns, show='headings', height=10)
        
        self.files_tree.heading('filename', text='Filename')
        self.files_tree.heading('path', text='Path')
        self.files_tree.heading('size', text='Size')
        self.files_tree.heading('status', text='Status')
        
        self.files_tree.column('filename', width=200)
        self.files_tree.column('path', width=300)
        self.files_tree.column('size', width=100)
        self.files_tree.column('status', width=100)
        
        # Create and configure scrollbar
        files_scrollbar = ttk.Scrollbar(container_frame, orient=tk.VERTICAL, command=self.files_tree.yview)
        self.files_tree.configure(yscrollcommand=files_scrollbar.set)
        
        # Pack treeview and scrollbar
        self.files_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        files_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Processing controls
        control_frame = ttk.Frame(tab_frame)
        control_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(control_frame, text="Process Files", 
                  command=self.process_selected_files).pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="Clear List", 
                  command=self.clear_file_list).pack(side=tk.LEFT, padx=5)
        
        # Progress bar
        progress_frame = ttk.Frame(tab_frame)
        progress_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(progress_frame, text="Progress:").pack(side=tk.LEFT)
        self.progress_var = tk.StringVar(value="Ready")
        self.progress_label = ttk.Label(progress_frame, textvariable=self.progress_var)
        self.progress_label.pack(side=tk.LEFT, padx=10)
        
        self.progress_bar = ttk.Progressbar(progress_frame, mode='determinate')
        self.progress_bar.pack(fill=tk.X, expand=True, padx=10)
    
    def create_workflow_analysis_tab(self):
        """Create workflow analysis tab"""
        tab_frame = ttk.Frame(self.notebook)
        self.notebook.add(tab_frame, text="Workflow Analysis")
        
        # Search frame
        search_frame = ttk.LabelFrame(tab_frame, text="Search & Filter", padding=10)
        search_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(search_frame, text="Search:").pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        
        ttk.Button(search_frame, text="Search", 
                  command=self.search_workflows).pack(side=tk.LEFT, padx=5)
        ttk.Button(search_frame, text="Refresh", 
                  command=self.refresh_workflow_list).pack(side=tk.LEFT, padx=5)
        
        # Workflow list with proper frame structure
        list_frame = ttk.LabelFrame(tab_frame, text="Workflows", padding=10)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create container frame for workflow tree and scrollbar
        workflow_container = ttk.Frame(list_frame)
        workflow_container.pack(fill=tk.BOTH, expand=True)
        
        # Create treeview for workflows
        columns = ('workflow_name', 'folder_name', 'repository_name', 'source_count', 'field_count', 'parsed_date')
        self.workflows_tree = ttk.Treeview(workflow_container, columns=columns, show='headings')
        
        self.workflows_tree.heading('workflow_name', text='Workflow Name')
        self.workflows_tree.heading('folder_name', text='Folder')
        self.workflows_tree.heading('repository_name', text='Repository')
        self.workflows_tree.heading('source_count', text='Sources')
        self.workflows_tree.heading('field_count', text='Fields')
        self.workflows_tree.heading('parsed_date', text='Parsed Date')
        
        self.workflows_tree.column('workflow_name', width=250)
        self.workflows_tree.column('folder_name', width=150)
        self.workflows_tree.column('repository_name', width=150)
        self.workflows_tree.column('source_count', width=80)
        self.workflows_tree.column('field_count', width=80)
        self.workflows_tree.column('parsed_date', width=150)
        
        # Create and configure scrollbar
        workflow_scrollbar = ttk.Scrollbar(workflow_container, orient=tk.VERTICAL, command=self.workflows_tree.yview)
        self.workflows_tree.configure(yscrollcommand=workflow_scrollbar.set)
        
        # Pack treeview and scrollbar
        self.workflows_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        workflow_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Statistics frame
        stats_frame = ttk.LabelFrame(tab_frame, text="Statistics", padding=10)
        stats_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.stats_text = scrolledtext.ScrolledText(stats_frame, height=6, state=tk.DISABLED)
        self.stats_text.pack(fill=tk.BOTH, expand=True)
    
    def create_detailed_view_tab(self):
        """Create detailed view tab"""
        tab_frame = ttk.Frame(self.notebook)
        self.notebook.add(tab_frame, text="Detailed View")
        
        # Create text area for detailed information
        detail_frame = ttk.LabelFrame(tab_frame, text="Workflow Details", padding=10)
        detail_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.detail_text = scrolledtext.ScrolledText(detail_frame, height=20, state=tk.DISABLED)
        self.detail_text.pack(fill=tk.BOTH, expand=True)
    
    def create_export_tab(self):
        """Create export tab"""
        tab_frame = ttk.Frame(self.notebook)
        self.notebook.add(tab_frame, text="Export")
        
        # Export options
        options_frame = ttk.LabelFrame(tab_frame, text="Export Options", padding=10)
        options_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Format selection
        format_frame = ttk.Frame(options_frame)
        format_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(format_frame, text="Format:").pack(side=tk.LEFT)
        self.export_format = tk.StringVar(value="csv")
        ttk.Radiobutton(format_frame, text="CSV (.csv)", variable=self.export_format, 
                       value="csv").pack(side=tk.LEFT, padx=10)
        if HAS_EXCEL:
            ttk.Radiobutton(format_frame, text="Excel (.xlsx)", variable=self.export_format, 
                           value="xlsx").pack(side=tk.LEFT, padx=10)
        
        # Export buttons
        button_frame = ttk.Frame(options_frame)
        button_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(button_frame, text="Export Data", 
                  command=self.export_data).pack(side=tk.LEFT, padx=5)
        
        # Export log
        log_frame = ttk.LabelFrame(tab_frame, text="Export Log", padding=10)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.export_log = scrolledtext.ScrolledText(log_frame, height=10, state=tk.DISABLED)
        self.export_log.pack(fill=tk.BOTH, expand=True)
    
    def create_status_bar(self):
        """Create status bar at bottom"""
        self.status_bar = ttk.Frame(self.root)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
        self.status_var = tk.StringVar(value="Ready")
        status_label = ttk.Label(self.status_bar, textvariable=self.status_var)
        status_label.pack(side=tk.LEFT, padx=10, pady=5)
        
        # Add connection status
        self.connection_var = tk.StringVar(value="Connected")
        connection_label = ttk.Label(self.status_bar, textvariable=self.connection_var)
        connection_label.pack(side=tk.RIGHT, padx=10, pady=5)
    
    def setup_bindings(self):
        """Setup event bindings"""
        self.workflows_tree.bind('<<TreeviewSelect>>', self.on_workflow_select)
        self.workflows_tree.bind('<Double-1>', self.on_workflow_double_click)
    
    def initialize_database(self):
        """Initialize database tables"""
        try:
            self.db_manager.test_connection()
            self.db_manager.create_tables()
            self.update_status("Database initialized successfully")
            self.connection_var.set("Connected to MS SQL Server")
        except Exception as e:
            self.logger.error(f"Database initialization failed: {str(e)}")
            self.connection_var.set("Database Connection Failed")
            messagebox.showerror("Database Error", 
                               f"Failed to connect to database:\n{str(e)}\n\n"
                               f"Please check:\n"
                               f"- SQL Server is running\n"
                               f"- ODBC Driver 17 for SQL Server is installed\n"
                               f"- Database credentials are correct")
    
    # File selection methods
    def select_single_file(self):
        """Select single XML file"""
        file_path = filedialog.askopenfilename(
            title="Select Informatica XML File",
            filetypes=[("XML files", "*.xml"), ("All files", "*.*")]
        )
        
        if file_path:
            self.add_file_to_list(file_path)
    
    def select_multiple_files(self):
        """Select multiple XML files"""
        file_paths = filedialog.askopenfilenames(
            title="Select Informatica XML Files",
            filetypes=[("XML files", "*.xml"), ("All files", "*.*")]
        )
        
        for file_path in file_paths:
            self.add_file_to_list(file_path)
    
    def select_folder(self):
        """Select folder containing XML files"""
        folder_path = filedialog.askdirectory(title="Select Folder with XML Files")
        
        if folder_path:
            xml_files = []
            for root, dirs, files in os.walk(folder_path):
                for file in files:
                    if file.lower().endswith('.xml'):
                        xml_files.append(os.path.join(root, file))
            
            if xml_files:
                for file_path in xml_files:
                    self.add_file_to_list(file_path)
                self.update_status(f"Added {len(xml_files)} XML files from folder")
            else:
                messagebox.showinfo("No Files", "No XML files found in the selected folder")
    
    def add_file_to_list(self, file_path: str):
        """Add file to processing list"""
        if file_path not in [f['path'] for f in self.selected_files]:
            try:
                file_size = os.path.getsize(file_path)
                size_str = self.format_file_size(file_size)
                
                file_info = {
                    'path': file_path,
                    'filename': os.path.basename(file_path),
                    'size': file_size,
                    'status': 'Ready'
                }
                
                self.selected_files.append(file_info)
                
                # Add to tree
                self.files_tree.insert('', 'end', values=(
                    file_info['filename'],
                    file_info['path'],
                    size_str,
                    file_info['status']
                ))
                
                self.update_status(f"Added {file_info['filename']} to processing list")
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to add file: {str(e)}")
    
    def clear_file_list(self):
        """Clear file list"""
        self.selected_files.clear()
        for item in self.files_tree.get_children():
            self.files_tree.delete(item)
        self.update_status("File list cleared")
    
    def process_selected_files(self):
        """Process selected XML files"""
        if not self.selected_files:
            messagebox.showwarning("No Files", "Please select XML files to process")
            return
        
        # Start processing in background thread
        thread = threading.Thread(target=self.process_files_thread, args=(self.selected_files.copy(),))
        thread.daemon = True
        thread.start()
        
        # Start monitoring progress
        self.monitor_progress()
    
    def process_files_thread(self, files: List[Dict]):
        """Process files in background thread"""
        try:
            total_files = len(files)
            processed = 0
            
            for file_info in files:
                try:
                    self.progress_queue.put(('status', f"Processing {file_info['filename']}..."))
                    
                    # Parse XML file
                    workflow_data = self.xml_parser.parse_workflow_file(file_info['path'])
                    
                    # Insert into database
                    workflow_id = self.db_manager.insert_workflow_data(workflow_data)
                    
                    # Insert sources and fields
                    if workflow_data.get('sources'):
                        self.db_manager.insert_source_data(workflow_id, workflow_data['sources'])
                        
                        for source in workflow_data['sources']:
                            if source.get('fields'):
                                self.db_manager.insert_field_data(
                                    workflow_id, 
                                    source['name'], 
                                    source['fields']
                                )
                    
                    processed += 1
                    progress = (processed / total_files) * 100
                    self.progress_queue.put(('progress', progress))
                    self.progress_queue.put(('file_status', file_info['filename'], 'Completed'))
                    
                except Exception as e:
                    self.progress_queue.put(('file_status', file_info['filename'], f'Error: {str(e)}'))
                    self.logger.error(f"Error processing {file_info['filename']}: {str(e)}")
            
            self.progress_queue.put(('complete', f"Processed {processed} of {total_files} files"))
            
        except Exception as e:
            self.progress_queue.put(('error', f"Processing failed: {str(e)}"))
    
    def monitor_progress(self):
        """Monitor progress queue and update GUI"""
        try:
            while True:
                message = self.progress_queue.get_nowait()
                
                if message[0] == 'status':
                    self.progress_var.set(message[1])
                elif message[0] == 'progress':
                    self.progress_bar['value'] = message[1]
                elif message[0] == 'file_status':
                    self.update_file_status(message[1], message[2])
                elif message[0] == 'complete':
                    self.progress_var.set(message[1])
                    self.progress_bar['value'] = 100
                    self.refresh_workflow_list()
                    messagebox.showinfo("Processing Complete", message[1])
                    return
                elif message[0] == 'error':
                    self.progress_var.set("Error occurred")
                    messagebox.showerror("Processing Error", message[1])
                    return
                    
        except queue.Empty:
            pass
        
        # Schedule next check
        self.root.after(100, self.monitor_progress)
    
    def update_file_status(self, filename: str, status: str):
        """Update file status in tree"""
        for item in self.files_tree.get_children():
            values = list(self.files_tree.item(item)['values'])
            if values[0] == filename:  # filename column
                values[3] = status  # status column
                self.files_tree.item(item, values=values)
                break
    
    def refresh_workflow_list(self):
        """Refresh workflow list from database"""
        try:
            workflows = self.db_manager.get_workflow_summary()
            self.current_workflows = workflows
            
            # Clear existing items
            for item in self.workflows_tree.get_children():
                self.workflows_tree.delete(item)
            
            # Add workflows to tree
            for workflow in workflows:
                parsed_date = workflow.get('parsed_date', '')
                if isinstance(parsed_date, datetime):
                    parsed_date = parsed_date.strftime('%Y-%m-%d %H:%M')
                
                self.workflows_tree.insert('', 'end', values=(
                    workflow.get('workflow_name', ''),
                    workflow.get('folder_name', ''),
                    workflow.get('repository_name', ''),
                    workflow.get('source_count', 0),
                    workflow.get('field_count', 0),
                    parsed_date
                ))
            
            self.update_statistics(workflows)
            self.update_status(f"Loaded {len(workflows)} workflows")
            
        except Exception as e:
            self.logger.error(f"Failed to refresh workflow list: {str(e)}")
            messagebox.showerror("Database Error", f"Failed to load workflows:\n{str(e)}")
    
    def search_workflows(self):
        """Search workflows"""
        search_term = self.search_var.get().strip()
        if not search_term:
            self.refresh_workflow_list()
            return
        
        # Filter current workflows
        filtered_workflows = []
        for workflow in self.current_workflows:
            if (search_term.lower() in workflow.get('workflow_name', '').lower() or
                search_term.lower() in workflow.get('folder_name', '').lower() or
                search_term.lower() in workflow.get('repository_name', '').lower()):
                filtered_workflows.append(workflow)
        
        # Clear and repopulate tree
        for item in self.workflows_tree.get_children():
            self.workflows_tree.delete(item)
        
        for workflow in filtered_workflows:
            parsed_date = workflow.get('parsed_date', '')
            if isinstance(parsed_date, datetime):
                parsed_date = parsed_date.strftime('%Y-%m-%d %H:%M')
            
            self.workflows_tree.insert('', 'end', values=(
                workflow.get('workflow_name', ''),
                workflow.get('folder_name', ''),
                workflow.get('repository_name', ''),
                workflow.get('source_count', 0),
                workflow.get('field_count', 0),
                parsed_date
            ))
        
        self.update_status(f"Found {len(filtered_workflows)} workflows matching '{search_term}'")
    
    def on_workflow_select(self, event):
        """Handle workflow selection"""
        selection = self.workflows_tree.selection()
        if selection:
            item = self.workflows_tree.item(selection[0])
            workflow_name = item['values'][0]
            self.update_status(f"Selected workflow: {workflow_name}")
    
    def on_workflow_double_click(self, event):
        """Handle workflow double-click"""
        selection = self.workflows_tree.selection()
        if selection:
            item = self.workflows_tree.item(selection[0])
            workflow_name = item['values'][0]
            
            # Find workflow details
            workflow_details = None
            for workflow in self.current_workflows:
                if workflow.get('workflow_name') == workflow_name:
                    workflow_details = workflow
                    break
            
            if workflow_details:
                self.show_workflow_details(workflow_details)
    
    def show_workflow_details(self, workflow: Dict):
        """Show detailed workflow information"""
        self.notebook.select(2)  # Switch to detailed view tab
        
        details_text = f"""
Workflow Details
================

Workflow Name: {workflow.get('workflow_name', 'N/A')}
Folder Name: {workflow.get('folder_name', 'N/A')}
Repository Name: {workflow.get('repository_name', 'N/A')}
Source Count: {workflow.get('source_count', 0)}
Field Count: {workflow.get('field_count', 0)}
File Size: {self.format_file_size(workflow.get('file_size', 0))}
Parsed Date: {workflow.get('parsed_date', 'N/A')}

Purpose Analysis
================
Based on the workflow name and structure, this appears to be an ETL workflow that:
- Extracts data from source systems
- Transforms the data according to business rules
- Loads the data into target systems

The workflow contains {workflow.get('source_count', 0)} source(s) and {workflow.get('field_count', 0)} field(s),
indicating the complexity and scope of the data transformation process.
        """
        
        self.detail_text.config(state=tk.NORMAL)
        self.detail_text.delete(1.0, tk.END)
        self.detail_text.insert(1.0, details_text)
        self.detail_text.config(state=tk.DISABLED)
    
    def update_statistics(self, workflows: List[Dict]):
        """Update statistics display"""
        if not workflows:
            stats_text = "No workflows loaded."
        else:
            total_workflows = len(workflows)
            total_sources = sum(w.get('source_count', 0) for w in workflows)
            total_fields = sum(w.get('field_count', 0) for w in workflows)
            
            repositories = set()
            folders = set()
            
            for workflow in workflows:
                if workflow.get('repository_name'):
                    repositories.add(workflow['repository_name'])
                if workflow.get('folder_name'):
                    folders.add(workflow['folder_name'])
            
            avg_sources = total_sources / total_workflows if total_workflows > 0 else 0
            avg_fields = total_fields / total_workflows if total_workflows > 0 else 0
            
            stats_text = f"""
Database Analysis Summary
=========================

Total Workflows: {total_workflows:,}
Total Sources: {total_sources:,}
Total Fields: {total_fields:,}
Unique Repositories: {len(repositories)}
Unique Folders: {len(folders)}

Averages:
- Sources per Workflow: {avg_sources:.1f}
- Fields per Workflow: {avg_fields:.1f}

Top Repositories:
{chr(10).join([f"- {repo}" for repo in sorted(repositories)[:5]])}

Top Folders:
{chr(10).join([f"- {folder}" for folder in sorted(folders)[:5]])}
            """
        
        self.stats_text.config(state=tk.NORMAL)
        self.stats_text.delete(1.0, tk.END)
        self.stats_text.insert(1.0, stats_text)
        self.stats_text.config(state=tk.DISABLED)
    
    def export_data(self):
        """Export workflow data"""
        if not self.current_workflows:
            messagebox.showwarning("No Data", "No workflow data to export")
            return
        
        format_type = self.export_format.get()
        
        # Select output file
        if format_type == "xlsx" and HAS_EXCEL:
            file_path = filedialog.asksaveasfilename(
                title="Export to Excel",
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")]
            )
        else:
            file_path = filedialog.asksaveasfilename(
                title="Export to CSV",
                defaultextension=".csv",
                filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
            )
        
        if not file_path:
            return
        
        try:
            # Convert workflows to tabular format
            export_data = []
            for workflow in self.current_workflows:
                export_data.append({
                    'Workflow Name': workflow.get('workflow_name', ''),
                    'Folder Name': workflow.get('folder_name', ''),
                    'Repository Name': workflow.get('repository_name', ''),
                    'Source Count': workflow.get('source_count', 0),
                    'Field Count': workflow.get('field_count', 0),
                    'File Size (bytes)': workflow.get('file_size', 0),
                    'Parsed Date': workflow.get('parsed_date', '')
                })
            
            if format_type == "xlsx" and HAS_EXCEL:
                # Export to Excel
                wb = Workbook()
                ws = wb.active
                ws.title = "Workflow Summary"
                
                if export_data:
                    # Add headers
                    headers = list(export_data[0].keys())
                    for col, header in enumerate(headers, 1):
                        ws.cell(row=1, column=col, value=header)
                    
                    # Add data
                    for row, data in enumerate(export_data, 2):
                        for col, header in enumerate(headers, 1):
                            ws.cell(row=row, column=col, value=data[header])
                
                wb.save(file_path)
            else:
                # Export to CSV
                import csv
                with open(file_path, 'w', newline='', encoding='utf-8') as csvfile:
                    if export_data:
                        fieldnames = export_data[0].keys()
                        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                        writer.writeheader()
                        writer.writerows(export_data)
            
            self.log_export(f"Successfully exported {len(export_data)} workflows to {file_path}")
            messagebox.showinfo("Export Complete", f"Data exported successfully to:\n{file_path}")
            
        except Exception as e:
            error_msg = f"Export failed: {str(e)}"
            self.log_export(error_msg)
            messagebox.showerror("Export Error", error_msg)
    
    def log_export(self, message: str):
        """Log export message"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        log_message = f"[{timestamp}] {message}\n"
        
        self.export_log.config(state=tk.NORMAL)
        self.export_log.insert(tk.END, log_message)
        self.export_log.config(state=tk.DISABLED)
        self.export_log.see(tk.END)
    
    def update_status(self, message: str):
        """Update status bar"""
        self.status_var.set(message)
        self.logger.info(message)
    
    @staticmethod
    def format_file_size(size_bytes: int) -> str:
        """Format file size in human readable format"""
        if size_bytes == 0:
            return "0B"
        
        size_names = ["B", "KB", "MB", "GB", "TB"]
        i = 0
        size_float = float(size_bytes)
        while size_float >= 1024 and i < len(size_names) - 1:
            size_float /= 1024.0
            i += 1
        
        return f"{size_float:.1f}{size_names[i]}"

def setup_logging():
    """Setup application logging"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('informatica_analyzer.log'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    return logging.getLogger(__name__)

def main():
    """Main application entry point"""
    logger = setup_logging()
    logger.info("Starting Informatica Workflow Analyzer")
    
    try:
        root = tk.Tk()
        app = InformaticaAnalyzerGUI(root)
        
        def on_closing():
            logger.info("Application closing")
            root.destroy()
        
        root.protocol("WM_DELETE_WINDOW", on_closing)
        
        logger.info("Starting GUI application")
        root.mainloop()
        
    except Exception as e:
        logger.error(f"Application error: {str(e)}", exc_info=True)
        if 'messagebox' in globals():
            messagebox.showerror("Application Error", f"An unexpected error occurred:\n{str(e)}")
        else:
            print(f"Application Error: {str(e)}")
    finally:
        logger.info("Application shutdown complete")

if __name__ == "__main__":
    main()