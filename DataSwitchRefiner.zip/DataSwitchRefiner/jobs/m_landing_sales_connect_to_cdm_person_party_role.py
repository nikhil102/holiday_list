"""
Sales Connect to CDM Person Party Role ETL Job.

This job extracts person role data from Sales Connect and transforms it into
the CDM Person Party Role format for loading.
"""

import os
import sys
import uuid
from datetime import datetime

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

from dataswitch_framework.config import config_manager
from dataswitch_framework.connections import ConnectionManager
from dataswitch_framework.logging_utils import configure_logging, JobLogger
from dataswitch_framework.monitoring import JobMetrics
from dataswitch_framework.spark_utils import create_spark_session, optimize_spark_session, safe_data_frame_conversion
from dataswitch_framework.transforms import trim_string_columns, is_spaces_udf
from dataswitch_framework.error_handling import ErrorHandler, try_catch, DataSwitchException

class SalesConnectToCdmPersonPartyRoleJob:
    """Job to transform Sales Connect data to CDM Person Party Role."""
    
    def __init__(self):
        """Initialize the job."""
        self.job_name = "m_landing_sales_connect_to_cdm_person_party_role"
        self.execution_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Set up logging
        configure_logging(job_name=self.job_name, execution_id=self.execution_id)
        self.logger = JobLogger(self.job_name, self.execution_id)
        
        # Initialize metrics
        self.metrics = JobMetrics(self.job_name, self.execution_id)
        
        # Initialize error handler
        self.error_handler = ErrorHandler(self.job_name, self.execution_id)
        
        # Load job configuration
        self.config = config_manager.get_job_config(self.job_name)
        
        # Initialize Spark session
        self.spark = create_spark_session(self.job_name)
        optimize_spark_session(self.spark)
        
        # Initialize connection manager
        self.conn_manager = ConnectionManager(self.spark)
        
        # Set current stage to None (will be updated during execution)
        self.current_stage = None
    
    @try_catch(error_handler=None, stage="initialize", fatal=True)
    def initialize(self):
        """Initialize the job with error handler assignment."""
        # This is needed because the error_handler parameter in the decorator is None
        # during class initialization (chicken-egg problem)
        self.logger.info(f"Initializing job {self.job_name}")
        self.metrics.start_job()
        return True
    
    @try_catch(error_handler=None, stage="extract_source_data", fatal=True)
    def extract_source_data(self):
        """Extract data from source systems."""
        self.current_stage = "extract_source_data"
        self.logger.start_stage(self.current_stage)
        self.metrics.start_stage(self.current_stage)
        
        # Source connection
        source_conn = self.config.get("source_connection", "source_db")
        
        # Extract Sales Connect representative data
        query = """
        SELECT pre_land_sales_connect_rep.Contact_Id, 
               pre_land_sales_connect_rep.Rep_First_Name,
               pre_land_sales_connect_rep.Rep_Middle_Name, 
               pre_land_sales_connect_rep.Rep_Last_Name, 
               pre_land_sales_connect_rep.Rep_Prefix, 
               pre_land_sales_connect_rep.Rep_Suffix, 
               pre_land_sales_connect_rep.Rep_Partnership_Indicator, 
               pre_land_sales_connect_rep.Rep_Crd_Number, 
               pre_land_sales_connect_rep.Sc_Rep_Action_Code, 
               pre_land_sales_connect_rep.Rep_Market_Timer_Indicator,
               pre_land_sales_connect_rep.Rep_Nickname,
               pre_land_sales_connect_rep.Rep_Status_Code,
               pre_land_sales_connect_rep.Rep_Entity_Date_Time_Update,
               pre_land_sales_connect_rep.Rep_Type
        FROM pre_land_sales_connect_rep, PRE_LAND_SALES_CONNECT_FIRM 
        WHERE pre_land_sales_connect_rep.Rep_Firm_Id = PRE_LAND_SALES_CONNECT_FIRM.Firm_Id 
          AND pre_land_sales_connect_rep.REP_PARTNERSHIP_INDICATOR = 'N' 
          AND UPPER(PRE_LAND_SALES_CONNECT_FIRM.Channel_Code) IN ('RIA', 'TRUST')
          AND UPPER(pre_land_sales_connect_rep.REP_STATUS_CODE) IN ('ACTIVE', 'INACTIVE')
          AND UPPER(pre_land_sales_connect_rep.REP_TYPE) <> 'HOUSE' 
          AND UPPER(pre_land_sales_connect_rep.REP_TYPE) <> 'DEFAULT REP'
          AND UPPER(pre_land_sales_connect_rep.REP_TYPE) <> 'PARTNERSHIP'
          AND pre_land_sales_connect_rep.Contact_Id in
           (select source_party_id from today_party_xform where source_system='SC' AND party_type_id='2102')
        """
        
        self.logger.info("Extracting Sales Connect representative data")
        self.source_df = self.conn_manager.read_jdbc_query(source_conn, query)
        self.source_df = self.source_df.coalesce(1).withColumn("jkey", monotonically_increasing_id())
        
        # Cache the DataFrame to improve performance
        self.source_df = safe_data_frame_conversion(self.source_df, cache=True)
        
        source_count = self.source_df.count()
        self.logger.info(f"Extracted {source_count} records from source")
        self.metrics.update_records(processed=source_count)
        
        # Extract lookup data
        self.logger.info("Extracting lookup transformation map")
        lookup_query = """
        SELECT 
            LTRIM(RTRIM(std_lkup_id)) as std_lkup_id,
            LTRIM(RTRIM(src_sys_nm)) as src_sys_nm,
            LTRIM(RTRIM(src_val)) as src_val,
            LTRIM(RTRIM(attrib_nm)) as attrib_nm 
        FROM lkup_transformation_map 
        WHERE src_sys_nm in ('SC')
        """
        
        self.lookup_df = self.conn_manager.read_jdbc_query(source_conn, lookup_query)
        
        lookup_count = self.lookup_df.count()
        self.logger.info(f"Extracted {lookup_count} lookup records")
        
        self.logger.end_stage("completed")
        self.metrics.end_stage("completed")
        return True
    
    @try_catch(error_handler=None, stage="transform_data", fatal=True)
    def transform_data(self):
        """Transform the source data into target format."""
        self.current_stage = "transform_data"
        self.logger.start_stage(self.current_stage)
        self.metrics.start_stage(self.current_stage)
        
        # Process for PARTY_ROLE_TYPE_ID
        self.logger.info("Processing PARTY_ROLE_TYPE_ID")
        df_role_type = self.source_df.select("*")
        df_role_type = df_role_type.withColumn("src_val_in", lit("Rep")) \
                               .withColumn("attrib_nm_in", lit("PARTY_ROLE_TYPE_ID"))
        
        # Lookup for PARTY_ROLE_TYPE_ID
        role_type_lookup = df_role_type.select(col("src_val_in"), col("attrib_nm_in"), col("jkey").alias("jkey1"))
        role_type_result = role_type_lookup.join(
            self.lookup_df,
            (self.lookup_df['src_val'] == role_type_lookup['src_val_in']) & 
            (self.lookup_df['attrib_nm'] == role_type_lookup['attrib_nm_in']),
            "left"
        ).select(role_type_lookup["*"], self.lookup_df["std_lkup_id"].alias("unLkpRT_std_lkup_id1"))
        
        # Group by to handle duplicate keys
        role_type_result = role_type_result.groupBy("jkey1").agg(first("unLkpRT_std_lkup_id1").alias("unLkpRT_std_lkup_id1"))
        
        # Process for PARTY_ROLE_STATUS_ID
        self.logger.info("Processing PARTY_ROLE_STATUS_ID")
        df_role_status = self.source_df.select("*")
        df_role_status = df_role_status.withColumn("V_SOURCE_SYSTEM", lit("SC")) \
                                 .withColumn("V_ORGANIZATION_STATUS_NAME", 
                                           when(col("V_SOURCE_SYSTEM") == 'SC', ltrim(rtrim(col("Rep_Status_Code"))))) \
                                 .withColumn("src_val_in", col("V_ORGANIZATION_STATUS_NAME")) \
                                 .withColumn("attrib_nm_in", lit('PARTY_ROLE_STATUS_ID'))
        
        # Lookup for PARTY_ROLE_STATUS_ID
        role_status_lookup = df_role_status.select(col("src_val_in"), col("attrib_nm_in"), col("jkey").alias("jkey2"))
        role_status_result = role_status_lookup.join(
            self.lookup_df,
            (self.lookup_df['src_val'] == role_status_lookup['src_val_in']) & 
            (self.lookup_df['attrib_nm'] == role_status_lookup['attrib_nm_in']),
            "left"
        ).select(role_status_lookup["*"], self.lookup_df["std_lkup_id"].alias("unLkpRT_std_lkup_id2"))
        
        # Group by to handle duplicate keys
        role_status_result = role_status_result.groupBy("jkey2").agg(first("unLkpRT_std_lkup_id2").alias("unLkpRT_std_lkup_id2"))
        
        # Join the source data with both lookup results
        self.logger.info("Joining lookup results")
        joined_df = self.source_df.join(
            role_type_result,
            self.source_df['jkey'] == role_type_result['jkey1'],
            "inner"
        ).join(
            role_status_result,
            self.source_df['jkey'] == role_status_result['jkey2'],
            "inner"
        ).select(
            self.source_df["*"],
            role_type_result["unLkpRT_std_lkup_id1"],
            role_status_result["unLkpRT_std_lkup_id2"]
        )
        
        # Final transformation
        self.logger.info("Creating final transformation")
        transformed_df = joined_df.withColumn("SOURCE_PARTY_ID", col("Contact_Id")) \
            .withColumn("V_SOURCE_SYSTEM", lit('SC')) \
            .withColumn("SOURCE_SYSTEM", col("V_SOURCE_SYSTEM")) \
            .withColumn("V_ORGANIZATION_STATUS_NAME", when(col("V_SOURCE_SYSTEM") == 'SC', ltrim(rtrim(col("Rep_Status_Code"))))) \
            .withColumn("V_LOOKUP_STATUS_ID", col("unLkpRT_std_lkup_id2")) \
            .withColumn("STATUS_ID", 
                       when(col("V_LOOKUP_STATUS_ID").isNotNull(), col("V_LOOKUP_STATUS_ID"))
                       .otherwise(when((col("V_LOOKUP_STATUS_ID").isNull() & col("V_ORGANIZATION_STATUS_NAME").isNull()), 
                                      lit(None))
                                 .otherwise('9999'))) \
            .withColumn("V_ROLE_TYPE_ID", col("unLkpRT_std_lkup_id1")) \
            .withColumn("ROLE_TYPE_ID_v", 
                       when(col("V_ROLE_TYPE_ID").isNotNull(), col("V_ROLE_TYPE_ID"))
                       .otherwise('9999')) \
            .withColumn("ROLE_TYPE_ID", col("ROLE_TYPE_ID_v")) \
            .withColumn("SUB_ROLE_TYPE_ID", lit(None)) \
            .withColumn("PRIMARY_INDICATOR", lit('Y')) \
            .withColumn("INACTIVATION_DATE", lit(None)) \
            .withColumn("INACTIVATION_REASON_ID", lit(None)) \
            .withColumn("CREATED_DATE", col("Rep_Entity_Date_Time_Update")) \
            .withColumn("CREATED_BY", lit('DST-SALES-CONNECT')) \
            .withColumn("LAST_UPDATED_DATE", col("Rep_Entity_Date_Time_Update")) \
            .withColumn("LAST_UPDATED_BY", lit('DST-SALES-CONNECT')) \
            .withColumn("DELETED_INDICATOR", lit(None)) \
            .withColumn("PARENT_SOURCE_SYSTEM", lit('SC')) \
            .withColumn("DEFERRED_OWNERSHIP_IND", lit('N')) \
            .withColumn("MAPPING_NAME", lit(self.job_name)) \
            .withColumn("SOURCE_PARTY_ROLE_ID", concat(col("Contact_Id"), lit("_"), col("ROLE_TYPE_ID_v"), lit("_PER_ROLE")))
        
        # Select target columns
        target_columns = [
            "SOURCE_PARTY_ID", "SOURCE_SYSTEM", "STATUS_ID", "ROLE_TYPE_ID", 
            "SUB_ROLE_TYPE_ID", "PRIMARY_INDICATOR", "INACTIVATION_DATE", 
            "INACTIVATION_REASON_ID", "CREATED_DATE", "CREATED_BY", 
            "LAST_UPDATED_DATE", "LAST_UPDATED_BY", "DELETED_INDICATOR",
            "PARENT_SOURCE_SYSTEM", "DEFERRED_OWNERSHIP_IND", "MAPPING_NAME",
            "SOURCE_PARTY_ROLE_ID"
        ]
        
        self.target_df = transformed_df.select(target_columns)
        
        # Cache the result
        self.target_df = self.target_df.cache()
        
        # Log record counts
        target_count = self.target_df.count()
        
        self.logger.info(f"Transformed {target_count} records")
        self.metrics.update_records(processed=target_count, succeeded=target_count)
        
        self.logger.end_stage("completed")
        self.metrics.end_stage("completed")
        return True
    
    @try_catch(error_handler=None, stage="load_target_data", fatal=True)
    def load_target_data(self):
        """Load transformed data to target."""
        self.current_stage = "load_target_data"
        self.logger.start_stage(self.current_stage)
        self.metrics.start_stage(self.current_stage)
        
        # Get target table name from config
        target_conn = self.config.get("target_connection", "target_db")
        target_table = self.config.get("target_table", "today_party_role_xform")
        
        # Write to target table
        self.logger.info(f"Writing {self.target_df.count()} records to {target_table}")
        
        # Use the JDBC connection for direct SQL execution
        conn = self.conn_manager.get_connection(target_conn)
        jdbc_cursor = conn['cursor']
        
        # Truncate and load approach
        temp_table = f"tmp_{target_table}_{self.execution_id.replace('-', '_')}"
        
        # Get the target schema and create the temporary table
        try:
            # Define the table schema
            self.logger.info(f"Creating temporary table {temp_table}")
            create_temp_table_sql = f"""
            CREATE TABLE {temp_table} (
                SOURCE_PARTY_ID VARCHAR(255) NOT NULL,
                SOURCE_SYSTEM VARCHAR(50) NOT NULL,
                STATUS_ID VARCHAR(50),
                ROLE_TYPE_ID VARCHAR(50),
                SUB_ROLE_TYPE_ID VARCHAR(50),
                PRIMARY_INDICATOR VARCHAR(1),
                INACTIVATION_DATE DATETIME,
                INACTIVATION_REASON_ID VARCHAR(50),
                CREATED_DATE DATETIME,
                CREATED_BY VARCHAR(255),
                LAST_UPDATED_DATE DATETIME,
                LAST_UPDATED_BY VARCHAR(255),
                DELETED_INDICATOR VARCHAR(1),
                PARENT_SOURCE_SYSTEM VARCHAR(50),
                DEFERRED_OWNERSHIP_IND VARCHAR(1),
                MAPPING_NAME VARCHAR(255),
                SOURCE_PARTY_ROLE_ID VARCHAR(255)
            )
            """
            jdbc_cursor.execute(create_temp_table_sql)
            
            # Write data to temporary table
            self.logger.info(f"Writing data to temporary table {temp_table}")
            self.target_df.write.format("jdbc") \
                .option("url", conn['jdbc_url']) \
                .option("dbtable", temp_table) \
                .option("driver", conn['driver']) \
                .mode("append") \
                .save()
            
            # Get count from temporary table
            count_query = f"SELECT COUNT(*) FROM {temp_table}"
            jdbc_cursor.execute(count_query)
            temp_count = jdbc_cursor.fetchone()[0]
            self.logger.info(f"Temporary table contains {temp_count} records")
            
            # Insert from temporary table to target table
            self.logger.info(f"Inserting data from temporary table to {target_table}")
            insert_sql = f"""
            INSERT INTO {target_table} (
                SOURCE_PARTY_ID, SOURCE_SYSTEM, STATUS_ID, ROLE_TYPE_ID, 
                SUB_ROLE_TYPE_ID, PRIMARY_INDICATOR, INACTIVATION_DATE, 
                INACTIVATION_REASON_ID, CREATED_DATE, CREATED_BY, 
                LAST_UPDATED_DATE, LAST_UPDATED_BY, DELETED_INDICATOR,
                PARENT_SOURCE_SYSTEM, DEFERRED_OWNERSHIP_IND, MAPPING_NAME,
                SOURCE_PARTY_ROLE_ID
            )
            SELECT 
                SOURCE_PARTY_ID, SOURCE_SYSTEM, STATUS_ID, ROLE_TYPE_ID, 
                SUB_ROLE_TYPE_ID, PRIMARY_INDICATOR, INACTIVATION_DATE, 
                INACTIVATION_REASON_ID, CREATED_DATE, CREATED_BY, 
                LAST_UPDATED_DATE, LAST_UPDATED_BY, DELETED_INDICATOR,
                PARENT_SOURCE_SYSTEM, DEFERRED_OWNERSHIP_IND, MAPPING_NAME,
                SOURCE_PARTY_ROLE_ID
            FROM {temp_table}
            """
            jdbc_cursor.execute(insert_sql)
            
            # Get inserted count
            jdbc_cursor.execute(f"SELECT @@ROWCOUNT")
            inserted_count = jdbc_cursor.fetchone()[0]
            self.logger.info(f"Inserted {inserted_count} records into {target_table}")
            
            # Drop temporary table
            self.logger.info(f"Dropping temporary table {temp_table}")
            jdbc_cursor.execute(f"DROP TABLE {temp_table}")
            
            self.metrics.update_records(processed=temp_count, succeeded=inserted_count)
            
        except Exception as e:
            self.logger.error(f"Error during data load: {str(e)}")
            # Try to drop temporary table if it exists
            try:
                jdbc_cursor.execute(f"IF OBJECT_ID('{temp_table}', 'U') IS NOT NULL DROP TABLE {temp_table}")
            except:
                pass
            raise
        
        self.logger.end_stage("completed")
        self.metrics.end_stage("completed")
        return True
    
    @try_catch(error_handler=None, stage="cleanup", fatal=False)
    def cleanup(self):
        """Clean up resources."""
        self.current_stage = "cleanup"
        self.logger.start_stage(self.current_stage)
        self.metrics.start_stage(self.current_stage)
        
        # Unpersist cached DataFrames
        self.logger.info("Unpersisting cached DataFrames")
        if hasattr(self, 'source_df'):
            self.source_df.unpersist()
        
        if hasattr(self, 'lookup_df'):
            self.lookup_df.unpersist()
        
        if hasattr(self, 'target_df'):
            self.target_df.unpersist()
        
        # Close all connections
        self.logger.info("Closing database connections")
        self.conn_manager.close_all_connections()
        
        self.logger.end_stage("completed")
        self.metrics.end_stage("completed")
        return True
    
    def run(self):
        """Run the complete ETL job."""
        try:
            self.initialize()
            
            # Decorate methods with the actual error handler instance
            for method_name in ["extract_source_data", "transform_data", "load_target_data", "cleanup"]:
                method = getattr(self, method_name)
                setattr(self, method_name, try_catch(self.error_handler, method_name)(method))
            
            # Execute the job stages
            self.extract_source_data()
            self.transform_data()
            self.load_target_data()
            
            # Save metrics regardless of success or failure
            metrics_file = self.metrics.save_metrics_file()
            
            # End the job
            status = "completed"
            self.metrics.end_job(status)
            self.logger.end_job(status)
            
            return True
            
        except Exception as e:
            status = "failed"
            self.logger.error(f"Job failed: {str(e)}")
            self.logger.exception("Exception details")
            
            # Try to cleanup resources even if job failed
            try:
                self.cleanup()
            except Exception as cleanup_error:
                self.logger.error(f"Cleanup after failure also failed: {str(cleanup_error)}")
            
            # End the job with failed status
            self.metrics.end_job(status)
            self.logger.end_job(status)
            
            return False

# Main execution
if __name__ == "__main__":
    job = SalesConnectToCdmPersonPartyRoleJob()
    success = job.run()
    sys.exit(0 if success else 1)
