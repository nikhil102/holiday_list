"""
DataSwitch Job Package.

This package contains the implementations of various data integration jobs
that utilize the DataSwitch framework.
"""
