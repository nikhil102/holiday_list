"""
Salesforce to CDM Office Party ETL Job.

This job extracts office data from Salesforce and transforms it into
the CDM Office Party format for loading.
"""

import os
import sys
import uuid
from datetime import datetime

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

from dataswitch_framework.config import config_manager
from dataswitch_framework.connections import ConnectionManager
from dataswitch_framework.logging_utils import configure_logging, JobLogger
from dataswitch_framework.monitoring import JobMetrics
from dataswitch_framework.spark_utils import create_spark_session, optimize_spark_session, safe_data_frame_conversion
from dataswitch_framework.transforms import trim_string_columns, add_audit_columns
from dataswitch_framework.error_handling import ErrorHandler, try_catch, DataSwitchException

class SalesforceToCdmOfficePartyJob:
    """Job to transform Salesforce data to CDM Office Party."""
    
    def __init__(self):
        """Initialize the job."""
        self.job_name = "m_landing_sfdc_to_cdm_office_party"
        self.execution_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Set up logging
        configure_logging(job_name=self.job_name, execution_id=self.execution_id)
        self.logger = JobLogger(self.job_name, self.execution_id)
        
        # Initialize metrics
        self.metrics = JobMetrics(self.job_name, self.execution_id)
        
        # Initialize error handler
        self.error_handler = ErrorHandler(self.job_name, self.execution_id)
        
        # Load job configuration
        self.config = config_manager.get_job_config(self.job_name)
        
        # Initialize Spark session
        self.spark = create_spark_session(self.job_name)
        optimize_spark_session(self.spark)
        
        # Initialize connection manager
        self.conn_manager = ConnectionManager(self.spark)
        
        # Set current stage to None (will be updated during execution)
        self.current_stage = None
    
    @try_catch(error_handler=None, stage="initialize", fatal=True)
    def initialize(self):
        """Initialize the job with error handler assignment."""
        # This is needed because the error_handler parameter in the decorator is None
        # during class initialization (chicken-egg problem)
        self.logger.info(f"Initializing job {self.job_name}")
        self.metrics.start_job()
        return True
    
    @try_catch(error_handler=None, stage="extract_source_data", fatal=True)
    def extract_source_data(self):
        """Extract data from source systems."""
        self.current_stage = "extract_source_data"
        self.logger.start_stage(self.current_stage)
        self.metrics.start_stage(self.current_stage)
        
        # Source connection
        source_conn = self.config.get("source_connection", "source_db")
        
        # Extract Salesforce office data
        self.logger.info("Extracting Salesforce office data")
        office_query = """
        SELECT pre_land_sfdc_office.Id, 
            pre_land_sfdc_office.Status__c, pre_land_sfdc_office.Type, 
            pre_land_sfdc_office.Direct__c, pre_land_sfdc_office.Name, 
            pre_land_sfdc_office.CreatedByAlias, pre_land_sfdc_office.CreatedDate, 
            pre_land_sfdc_office.LastModifiedByAlias, pre_land_sfdc_office.LastModifiedDate, 
            pre_land_sfdc_office.Source_System_Name, pre_land_sfdc_office.RecordTypeName, 
            pre_land_sfdc_office.Location_Type__c, pre_land_sfdc_office.Inactivated_Date__c,
            case
            when Client_Group_C is null and RecordTypeName='NT Advisory Office RO' then 'United States of America'
            when pre_land_sfdc_office.Client_Group_C IN ('ECM Local Consultant','ECM Global Consultant') and pre_land_sfdc_office.BillingCountry IN('United Kingdom','Ireland','Channel Islands','Guernsey') then 'UK' 
            when Client_Group_C='Australia' and pre_land_sfdc_office.BillingCountry<>'Australia' then null
            when pre_land_sfdc_office.Client_Group_C IN ('ECM Local Consultant','ECM Global Consultant') and pre_land_sfdc_office.BillingCountry NOT IN('United Kingdom','Ireland','Channel Islands','Guernsey') then null 
            else
            pre_land_sfdc_office.Client_Group_C
            end CLIENT_GROUP_ID 
        FROM
            pre_land_sfdc_office
        where RecordTypeName in
            ('Financial Institutions Office',
            'Institutional Client Office',
            'Institutional Consultant Office',
            'Institutional Other Intermediary Office'
            ,'NT Advisory Office RO','Retail Office RO','CIAM Office RO')
            and 
            ((Client_Group_C<>'Australia' and pre_land_sfdc_office.BillingCountry <> 'Australia') or Client_Group_C is null or (Client_Group_C='Australia' and pre_land_sfdc_office.BillingCountry <> 'Australia') or  ( Client_Group_C<>'Australia'  and pre_land_sfdc_office.BillingCountry is null))

        --CAR ORG Business Office
        union
        SELECT concat(pre_land_sfdc_office.Id,'|BUSSADDR') id, 
            pre_land_sfdc_office.Status__c, pre_land_sfdc_office.Type, 
            pre_land_sfdc_office.Direct__c, pre_land_sfdc_office.Name, 
            pre_land_sfdc_office.CreatedByAlias, pre_land_sfdc_office.CreatedDate, 
            pre_land_sfdc_office.LastModifiedByAlias, pre_land_sfdc_office.LastModifiedDate, 
            pre_land_sfdc_office.Source_System_Name, pre_land_sfdc_office.RecordTypeName, 
            pre_land_sfdc_office.Location_Type__c, pre_land_sfdc_office.Inactivated_Date__c ,'Australia' CLIENT_GROUP_ID
        FROM
            pre_land_sfdc_office
        where pre_land_sfdc_office.[RecordTypeName] in
            ('Financial Institutions Office',
            'Institutional Client Office',
            'Institutional Consultant Office',
            'Institutional Other Intermediary Office'
            ,'NT Advisory Office RO','Retail Office RO','CIAM Office RO')
            and ((Client_Group_C='Australia' and BillingCountry is NULL) OR (Client_Group_C is NOT NULL and BillingCountry = 'Australia'))
            and BillingCountry is not null
        
        --CAR ORG Mailing Office
        union
        SELECT concat(pre_land_sfdc_office.Id,'|MAILADDR') id, 
            pre_land_sfdc_office.Status__c, pre_land_sfdc_office.Type, 
            pre_land_sfdc_office.Direct__c, pre_land_sfdc_office.Name, 
            pre_land_sfdc_office.CreatedByAlias, pre_land_sfdc_office.CreatedDate, 
            pre_land_sfdc_office.LastModifiedByAlias, pre_land_sfdc_office.LastModifiedDate, 
            pre_land_sfdc_office.Source_System_Name, pre_land_sfdc_office.RecordTypeName, 
            pre_land_sfdc_office.Location_Type__c, pre_land_sfdc_office.Inactivated_Date__c ,'Australia' CLIENT_GROUP_ID
        FROM
            pre_land_sfdc_office
        where pre_land_sfdc_office.[RecordTypeName] in
            ('Financial Institutions Office',
            'Institutional Client Office',
            'Institutional Consultant Office',
            'Institutional Other Intermediary Office'
            ,'NT Advisory Office RO','Retail Office RO','CIAM Office RO')
            and ((Client_Group_C='Australia' and BillingCountry is NULL) OR (Client_Group_C is NOT NULL and BillingCountry = 'Australia'))
            and shipingcountry IS NOT NULL 
            AND (
            shippingstreet IS NOT NULL
            OR shippingcity IS NOT NULL
            OR shippingstate IS NOT NULL
            OR shippingpostalcode IS NOT NULL
            )
        
        union
        --LIC Org Business Office
        SELECT distinct concat(org.Id,'|BUSSADDR') id, 
            org.Status__c,
            Null Type, 
            Null Direct__c,
            org.Name, 
            org.CreatedByAlias,
            org.CreatedDate, 
            org.LastModifiedByAlias,
            org.LastModifiedDate, 
            org.Source_System_Name,
            org.RecordTypeName, 
            Null Location_Type__c,
            org.Inactivated_Date__c ,'Australia' CLIENT_GROUP_ID
        FROM
            pre_land_sfdc_organization org
            left join 
            pre_land_sfdc_office ofc
            on org.id=ofc.ParentId
        where ofc.[RecordTypeName] in
            ('Financial Institutions Office',
            'Institutional Client Office',
            'Institutional Consultant Office',
            'Institutional Other Intermediary Office'
            ,'NT Advisory Office RO','Retail Office RO','CIAM Office RO')
            and ((ofc.Client_Group_C='Australia' and ofc.BillingCountry is NULL) OR (ofc.Client_Group_C is NOT NULL and ofc.BillingCountry = 'Australia'))
            and org.BillingCountry is not null

        union
        --LIC ORG Mailing Office
        SELECT distinct concat(org.Id,'|MAILADDR') id, 
            org.Status__c,
            Null Type, 
            Null Direct__c,
            org.Name, 
            org.CreatedByAlias,
            org.CreatedDate, 
            org.LastModifiedByAlias,
            org.LastModifiedDate, 
            org.Source_System_Name,
            org.RecordTypeName, 
            Null Location_Type__c,
            org.Inactivated_Date__c ,'Australia' CLIENT_GROUP_ID
        FROM
            pre_land_sfdc_organization org
            left join 
            pre_land_sfdc_office ofc
            on org.id=ofc.ParentId
        where ofc.[RecordTypeName] in
            ('Financial Institutions Office',
            'Institutional Client Office',
            'Institutional Consultant Office',
            'Institutional Other Intermediary Office'
            ,'NT Advisory Office RO','Retail Office RO','CIAM Office RO')
            and ((ofc.Client_Group_C='Australia' and ofc.BillingCountry is NULL) OR (ofc.Client_Group_C is NOT NULL and ofc.BillingCountry = 'Australia'))
            and org.ShippingCountry is not null
            AND (
            org.shippingstreet IS NOT NULL
            OR org.shippingcity IS NOT NULL
            OR org.shippingstate IS NOT NULL
            OR org.shippingpostalcode IS NOT NULL
            )
        """
        
        self.source_df = self.conn_manager.read_jdbc_query(source_conn, office_query)
        
        # Cache the DataFrame to improve performance
        self.source_df = safe_data_frame_conversion(self.source_df, cache=True)
        
        source_count = self.source_df.count()
        self.logger.info(f"Extracted {source_count} records from source")
        self.metrics.update_records(processed=source_count)
        
        # Extract lookup data
        self.logger.info("Extracting lookup transformation map")
        lookup_query = """
        SELECT 
            LTRIM(RTRIM(std_lkup_id)) as std_lkup_id,
            LTRIM(RTRIM(src_sys_nm)) as src_sys_nm,
            LTRIM(RTRIM(src_val)) as src_val,
            LTRIM(RTRIM(attrib_nm)) as attrib_nm 
        FROM lkup_transformation_map
        WHERE src_sys_nm in ('SFDC')
        """
        
        self.lookup_df = self.conn_manager.read_jdbc_query(source_conn, lookup_query)
        self.lookup_df = self.lookup_df.groupBy("src_val", "attrib_nm").agg(first("std_lkup_id").alias("std_lkup_id")).cache()
        
        # Extract TODAY_PARTY_XFORM data
        self.logger.info("Extracting TODAY_PARTY_XFORM data")
        party_xform_query = """
        SELECT 
            LTRIM(RTRIM(SOURCE_SYSTEM)) as SOURCE_SYSTEM, 
            LTRIM(RTRIM(SOURCE_PARTY_ID)) as SOURCE_PARTY_ID 
        FROM TODAY_PARTY_XFORM
        WHERE SOURCE_SYSTEM in ('SOFI','DORIS','SALESCONNECT')
        """
        
        self.party_xform_df = self.conn_manager.read_jdbc_query(source_conn, party_xform_query)
        self.party_xform_df = self.party_xform_df.groupBy("SOURCE_PARTY_ID").agg(first("SOURCE_SYSTEM").alias("SOURCE_SYSTEM")).cache()
        
        lookup_count = self.lookup_df.count()
        party_xform_count = self.party_xform_df.count()
        self.logger.info(f"Extracted {lookup_count} lookup records and {party_xform_count} party transform records")
        
        self.logger.end_stage("completed")
        self.metrics.end_stage("completed")
        return True
    
    @try_catch(error_handler=None, stage="transform_data", fatal=True)
    def transform_data(self):
        """Transform the source data into target format."""
        self.current_stage = "transform_data"
        self.logger.start_stage(self.current_stage)
        self.metrics.start_stage(self.current_stage)
        
        # Filter records as required
        self.logger.info("Filtering records as required")
        df = self.source_df.select(
            col("Id"), col("Status__c"), col("Type"), col("Direct__c"),
            col("Name"), col("CreatedByAlias"), col("CreatedDate"),
            col("LastModifiedByAlias"), col("LastModifiedDate"),
            col("Source_System_Name"), col("RecordTypeName").alias("RecordTypeName1"),
            col("Location_Type__c"), col("Inactivated_Date__c"), col("CLIENT_GROUP_ID")
        ).filter(lit(True))  # The original filter was a 'SELECT ALL'
        
        # Lookup PARTY_STATUS_ID
        self.logger.info("Looking up PARTY_STATUS_ID")
        df = df.withColumn("src_val_in", ltrim(rtrim(col("Status__c")))) \
               .withColumn("attrib_nm_in", lit('PARTY_STATUS_ID'))
        
        df = df.join(
            self.lookup_df,
            (self.lookup_df['src_val'] == df['src_val_in']) & 
            (self.lookup_df['attrib_nm'] == df['attrib_nm_in']),
            "left"
        ).select(df["*"], self.lookup_df["std_lkup_id"].alias("unLkpRT_std_lkup_id1"))
        
        # Lookup PARTY_TYPE_ID
        self.logger.info("Looking up PARTY_TYPE_ID")
        df = df.withColumn("src_val_in", lit('Office')) \
               .withColumn("attrib_nm_in", lit('PARTY_TYPE_ID'))
        
        df = df.join(
            self.lookup_df,
            (self.lookup_df['src_val'] == df['src_val_in']) & 
            (self.lookup_df['attrib_nm'] == df['attrib_nm_in']),
            "left"
        ).select(df["*"], self.lookup_df["std_lkup_id"].alias("unLkpRT_std_lkup_id2"))
        
        # Process source party ID
        self.logger.info("Processing source party ID")
        df = df.withColumn("IN_Id", concat(lit('OFF_'), col("Direct__c")))
        
        # Final transformations
        self.logger.info("Applying final transformations")
        df = df.withColumn("SOURCE_PARTY_ID", col("Id")) \
               .withColumn("SOURCE_SYSTEM", lit('SFDC')) \
               .withColumn("PARTY_TYPE_ID", col("unLkpRT_std_lkup_id2")) \
               .withColumn("PARTY_STATUS_ID", 
                         when(col("unLkpRT_std_lkup_id1").isNotNull(), col("unLkpRT_std_lkup_id1"))
                         .when(col("Status__c").isNull(), lit('2000'))
                         .otherwise(lit('9999'))) \
               .withColumn("PARTY_INACTIVATION_DATE", 
                         when(col("Status__c") == 'Inactive', col("Inactivated_Date__c"))
                         .otherwise(lit(None))) \
               .withColumn("PARTY_INCTVTN_RSN_TYPE_ID", lit(None).cast("string")) \
               .withColumn("PARTY_SOURCE_KEY", col("Id")) \
               .withColumn("CREATED_DATE", col("CreatedDate")) \
               .withColumn("CREATED_BY", lit('DST-SFDC')) \
               .withColumn("LAST_UPDATED_DATE", col("LastModifiedDate")) \
               .withColumn("LAST_UPDATED_BY", lit('DST-SFDC')) \
               .withColumn("DELETED_INDICATOR", lit(None).cast("string")) \
               .withColumn("DEFERRED_OWNERSHIP_IND", lit('N')) \
               .withColumn("MAPPING_NAME", lit(self.job_name)) \
               .withColumn("ORG_FULL_NAME_TEXT", col("Name")) \
               .withColumn("ORG_CLIENT_GROUP_ID", col("CLIENT_GROUP_ID"))
        
        # Select final columns for target
        target_columns = [
            "SOURCE_PARTY_ID", "SOURCE_SYSTEM", "PARTY_TYPE_ID", "PARTY_STATUS_ID",
            "PARTY_INACTIVATION_DATE", "PARTY_INCTVTN_RSN_TYPE_ID", "PARTY_SOURCE_KEY",
            "CREATED_DATE", "CREATED_BY", "LAST_UPDATED_DATE", "LAST_UPDATED_BY",
            "DELETED_INDICATOR", "DEFERRED_OWNERSHIP_IND", "MAPPING_NAME",
            "ORG_FULL_NAME_TEXT", "ORG_CLIENT_GROUP_ID"
        ]
        
        self.target_df = df.select(target_columns)
        
        # Cache the result
        self.target_df = self.target_df.cache()
        
        # Log record counts
        target_count = self.target_df.count()
        
        self.logger.info(f"Transformed {target_count} records")
        self.metrics.update_records(processed=target_count, succeeded=target_count)
        
        self.logger.end_stage("completed")
        self.metrics.end_stage("completed")
        return True
    
    @try_catch(error_handler=None, stage="load_target_data", fatal=True)
    def load_target_data(self):
        """Load transformed data to target."""
        self.current_stage = "load_target_data"
        self.logger.start_stage(self.current_stage)
        self.metrics.start_stage(self.current_stage)
        
        # Get target table name from config
        target_conn = self.config.get("target_connection", "target_db")
        target_table = self.config.get("target_table", "today_party_xform")
        
        # Write to target table
        self.logger.info(f"Writing {self.target_df.count()} records to {target_table}")
        
        # Use the JDBC connection for direct SQL execution
        conn = self.conn_manager.get_connection(target_conn)
        jdbc_cursor = conn['cursor']
        
        # Truncate and load approach
        temp_table = f"tmp_{target_table}_{self.execution_id.replace('-', '_')}"
        
        # Get the target schema and create the temporary table
        try:
            # Define the table schema
            self.logger.info(f"Creating temporary table {temp_table}")
            create_temp_table_sql = f"""
            CREATE TABLE {temp_table} (
                SOURCE_PARTY_ID VARCHAR(255) NOT NULL,
                SOURCE_SYSTEM VARCHAR(50) NOT NULL,
                PARTY_TYPE_ID VARCHAR(50),
                PARTY_STATUS_ID VARCHAR(50),
                PARTY_INACTIVATION_DATE DATETIME,
                PARTY_INCTVTN_RSN_TYPE_ID VARCHAR(50),
                PARTY_SOURCE_KEY VARCHAR(255),
                CREATED_DATE DATETIME,
                CREATED_BY VARCHAR(255),
                LAST_UPDATED_DATE DATETIME,
                LAST_UPDATED_BY VARCHAR(255),
                DELETED_INDICATOR VARCHAR(1),
                DEFERRED_OWNERSHIP_IND VARCHAR(1),
                MAPPING_NAME VARCHAR(255),
                ORG_FULL_NAME_TEXT VARCHAR(255),
                ORG_CLIENT_GROUP_ID VARCHAR(255)
            )
            """
            jdbc_cursor.execute(create_temp_table_sql)
            
            # Write data to temporary table
            self.logger.info(f"Writing data to temporary table {temp_table}")
            self.target_df.write.format("jdbc") \
                .option("url", conn['jdbc_url']) \
                .option("dbtable", temp_table) \
                .option("driver", conn['driver']) \
                .mode("append") \
                .save()
            
            # Get count from temporary table
            count_query = f"SELECT COUNT(*) FROM {temp_table}"
            jdbc_cursor.execute(count_query)
            temp_count = jdbc_cursor.fetchone()[0]
            self.logger.info(f"Temporary table contains {temp_count} records")
            
            # Insert from temporary table to target table
            self.logger.info(f"Inserting data from temporary table to {target_table}")
            insert_sql = f"""
            INSERT INTO {target_table} (
                SOURCE_PARTY_ID, SOURCE_SYSTEM, PARTY_TYPE_ID, PARTY_STATUS_ID,
                PARTY_INACTIVATION_DATE, PARTY_INCTVTN_RSN_TYPE_ID, PARTY_SOURCE_KEY,
                CREATED_DATE, CREATED_BY, LAST_UPDATED_DATE, LAST_UPDATED_BY,
                DELETED_INDICATOR, DEFERRED_OWNERSHIP_IND, MAPPING_NAME,
                ORG_FULL_NAME_TEXT, ORG_CLIENT_GROUP_ID
            )
            SELECT 
                SOURCE_PARTY_ID, SOURCE_SYSTEM, PARTY_TYPE_ID, PARTY_STATUS_ID,
                PARTY_INACTIVATION_DATE, PARTY_INCTVTN_RSN_TYPE_ID, PARTY_SOURCE_KEY,
                CREATED_DATE, CREATED_BY, LAST_UPDATED_DATE, LAST_UPDATED_BY,
                DELETED_INDICATOR, DEFERRED_OWNERSHIP_IND, MAPPING_NAME,
                ORG_FULL_NAME_TEXT, ORG_CLIENT_GROUP_ID
            FROM {temp_table}
            """
            jdbc_cursor.execute(insert_sql)
            
            # Get inserted count
            jdbc_cursor.execute(f"SELECT @@ROWCOUNT")
            inserted_count = jdbc_cursor.fetchone()[0]
            self.logger.info(f"Inserted {inserted_count} records into {target_table}")
            
            # Drop temporary table
            self.logger.info(f"Dropping temporary table {temp_table}")
            jdbc_cursor.execute(f"DROP TABLE {temp_table}")
            
            self.metrics.update_records(processed=temp_count, succeeded=inserted_count)
            
        except Exception as e:
            self.logger.error(f"Error during data load: {str(e)}")
            # Try to drop temporary table if it exists
            try:
                jdbc_cursor.execute(f"IF OBJECT_ID('{temp_table}', 'U') IS NOT NULL DROP TABLE {temp_table}")
            except:
                pass
            raise
        
        self.logger.end_stage("completed")
        self.metrics.end_stage("completed")
        return True
    
    @try_catch(error_handler=None, stage="cleanup", fatal=False)
    def cleanup(self):
        """Clean up resources."""
        self.current_stage = "cleanup"
        self.logger.start_stage(self.current_stage)
        self.metrics.start_stage(self.current_stage)
        
        # Unpersist cached DataFrames
        self.logger.info("Unpersisting cached DataFrames")
        if hasattr(self, 'source_df'):
            self.source_df.unpersist()
        
        if hasattr(self, 'lookup_df'):
            self.lookup_df.unpersist()
        
        if hasattr(self, 'party_xform_df'):
            self.party_xform_df.unpersist()
        
        if hasattr(self, 'target_df'):
            self.target_df.unpersist()
        
        # Close all connections
        self.logger.info("Closing database connections")
        self.conn_manager.close_all_connections()
        
        self.logger.end_stage("completed")
        self.metrics.end_stage("completed")
        return True
    
    def run(self):
        """Run the complete ETL job."""
        try:
            self.initialize()
            
            # Decorate methods with the actual error handler instance
            for method_name in ["extract_source_data", "transform_data", "load_target_data", "cleanup"]:
                method = getattr(self, method_name)
                setattr(self, method_name, try_catch(self.error_handler, method_name)(method))
            
            # Execute the job stages
            self.extract_source_data()
            self.transform_data()
            self.load_target_data()
            
            # Save metrics regardless of success or failure
            metrics_file = self.metrics.save_metrics_file()
            
            # End the job
            status = "completed"
            self.metrics.end_job(status)
            self.logger.end_job(status)
            
            return True
            
        except Exception as e:
            status = "failed"
            self.logger.error(f"Job failed: {str(e)}")
            self.logger.exception("Exception details")
            
            # Try to cleanup resources even if job failed
            try:
                self.cleanup()
            except Exception as cleanup_error:
                self.logger.error(f"Cleanup after failure also failed: {str(cleanup_error)}")
            
            # End the job with failed status
            self.metrics.end_job(status)
            self.logger.end_job(status)
            
            return False

# Main execution
if __name__ == "__main__":
    job = SalesforceToCdmOfficePartyJob()
    success = job.run()
    sys.exit(0 if success else 1)
