"""
DataSwitch Job Runner

A command-line utility for running DataSwitch ETL jobs with proper configuration
and monitoring.
"""

import os
import sys
import argparse
import importlib
import logging
from datetime import datetime
import time

from dataswitch_framework.config import config_manager
from dataswitch_framework.logging_utils import configure_logging

# Configure root logger
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("job_runner")

def list_available_jobs():
    """List all available jobs in the jobs package.
    
    Returns:
        List of job module names
    """
    available_jobs = []
    jobs_dir = os.path.join(os.path.dirname(__file__), "jobs")
    
    # Ensure the jobs directory exists
    if not os.path.isdir(jobs_dir):
        logger.error(f"Jobs directory not found: {jobs_dir}")
        return []
    
    # Find all Python files in the jobs directory
    for file in os.listdir(jobs_dir):
        if file.endswith(".py") and not file.startswith("__"):
            job_name = file[:-3]  # Remove .py extension
            available_jobs.append(job_name)
    
    return available_jobs

def import_job_class(job_module_name):
    """Import the job class from the module name.
    
    Args:
        job_module_name: Module name (e.g., m_landing_sales_connect_to_cdm_person_party)
    
    Returns:
        Job class or None if not found
    """
    try:
        # Import the module from the jobs package
        module = importlib.import_module(f"jobs.{job_module_name}")
        
        # Find the job class in the module
        # Convention: CamelCase version of the module name
        class_name = ''.join(part.capitalize() for part in job_module_name.split('_'))
        
        # Look for the class in the module
        for name in dir(module):
            if name.lower() == class_name.lower() or "job" in name.lower():
                job_class = getattr(module, name)
                if isinstance(job_class, type):
                    return job_class
        
        logger.error(f"Could not find job class in module {job_module_name}")
        return None
        
    except Exception as e:
        logger.error(f"Failed to import job module {job_module_name}: {str(e)}")
        return None

def run_job(job_module_name):
    """Run a specific job.
    
    Args:
        job_module_name: Module name of the job
    
    Returns:
        True if job succeeded, False otherwise
    """
    logger.info(f"Preparing to run job: {job_module_name}")
    
    # Import the job class
    job_class = import_job_class(job_module_name)
    if not job_class:
        return False
    
    # Create and run job instance
    try:
        logger.info(f"Initializing job class: {job_class.__name__}")
        job_instance = job_class()
        
        logger.info(f"Running job: {job_module_name}")
        start_time = time.time()
        success = job_instance.run()
        end_time = time.time()
        
        duration = end_time - start_time
        if success:
            logger.info(f"Job {job_module_name} completed successfully in {duration:.2f} seconds")
        else:
            logger.error(f"Job {job_module_name} failed after {duration:.2f} seconds")
        
        return success
        
    except Exception as e:
        logger.exception(f"Error running job {job_module_name}: {str(e)}")
        return False

def main():
    """Main entry point for the job runner."""
    parser = argparse.ArgumentParser(description="DataSwitch Job Runner")
    
    # Command-line arguments
    parser.add_argument(
        "--job", 
        help="Name of job to run (e.g., m_landing_sales_connect_to_cdm_person_party)"
    )
    parser.add_argument(
        "--list", 
        action="store_true", 
        help="List available jobs"
    )
    parser.add_argument(
        "--config", 
        help="Path to configuration file"
    )
    
    args = parser.parse_args()
    
    # Set up configuration if specified
    if args.config:
        config_path = args.config
        logger.info(f"Using configuration file: {config_path}")
        if not os.path.exists(config_path):
            logger.error(f"Configuration file not found: {config_path}")
            return 1
    else:
        config_path = None  # Use default
    
    # Configure general logging
    configure_logging()
    
    # List available jobs
    if args.list:
        available_jobs = list_available_jobs()
        
        if available_jobs:
            print("Available jobs:")
            for job in sorted(available_jobs):
                # Get job description from config if available
                job_config = config_manager.get_job_config(job)
                description = job_config.get("description", "No description available")
                print(f"  - {job}: {description}")
        else:
            print("No jobs available")
        
        return 0
    
    # Run specified job
    if args.job:
        job_name = args.job
        success = run_job(job_name)
        return 0 if success else 1
    
    # If neither list nor job specified, show help
    parser.print_help()
    return 1

if __name__ == "__main__":
    sys.exit(main())
