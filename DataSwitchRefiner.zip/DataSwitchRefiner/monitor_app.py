"""
DataSwitch Job Monitoring Dashboard

A Streamlit-based application for monitoring and analyzing DataSwitch job executions.
"""

import os
import json
import glob
import pandas as pd
import streamlit as st
import altair as alt
from datetime import datetime, timedelta
import time

# Set page configuration
st.set_page_config(
    page_title="DataSwitch Monitoring Dashboard",
    page_icon="📊",
    layout="wide"
)

# Function to load metrics from JSON files
def load_metrics_data(metrics_dir="./metrics"):
    """Load metrics data from JSON files in the metrics directory.
    
    Args:
        metrics_dir: Directory containing metrics JSON files
        
    Returns:
        List of metrics dictionaries
    """
    all_metrics = []
    
    # Create metrics directory if it doesn't exist
    os.makedirs(metrics_dir, exist_ok=True)
    
    # Find all JSON files in the metrics directory
    json_files = glob.glob(os.path.join(metrics_dir, "*.json"))
    
    for file_path in json_files:
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
                all_metrics.append(data)
        except Exception as e:
            st.warning(f"Failed to load metrics from {file_path}: {str(e)}")
    
    return all_metrics

# Function to load log data
def load_log_data(log_file="./logs/jobs.log"):
    """Load log data from job log file.
    
    Args:
        log_file: Path to log file
        
    Returns:
        List of log entries
    """
    log_entries = []
    
    if not os.path.exists(log_file):
        return []
    
    try:
        with open(log_file, 'r') as f:
            for line in f:
                # Parse log line (simple parsing, can be enhanced)
                parts = line.strip().split(' - ', 3)
                if len(parts) >= 4:
                    timestamp = parts[0]
                    logger = parts[1]
                    level = parts[2]
                    message = parts[3]
                    
                    log_entries.append({
                        'timestamp': timestamp,
                        'logger': logger,
                        'level': level,
                        'message': message
                    })
    except Exception as e:
        st.warning(f"Failed to load log data: {str(e)}")
    
    return log_entries

# Convert metrics to DataFrame for easier analysis
def metrics_to_dataframe(metrics_list):
    """Convert metrics list to DataFrame.
    
    Args:
        metrics_list: List of metrics dictionaries
        
    Returns:
        DataFrame with job metrics
    """
    records = []
    
    for job in metrics_list:
        # Skip incomplete metrics
        if not job.get('end_time'):
            continue
            
        record = {
            'job_name': job.get('job_name', 'unknown'),
            'execution_id': job.get('execution_id', 'unknown'),
            'start_time': job.get('start_time'),
            'end_time': job.get('end_time'),
            'duration_seconds': job.get('duration_seconds', 0),
            'status': job.get('status', 'unknown'),
            'records_processed': job.get('records', {}).get('processed', 0),
            'records_succeeded': job.get('records', {}).get('succeeded', 0),
            'records_failed': job.get('records', {}).get('failed', 0),
            'stage_count': len(job.get('stages', {}))
        }
        
        records.append(record)
    
    # Create DataFrame
    if records:
        df = pd.DataFrame(records)
        
        # Convert string timestamps to datetime
        for col in ['start_time', 'end_time']:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col])
        
        return df
    
    return pd.DataFrame()

# Convert stage metrics to DataFrame
def stages_to_dataframe(job_metrics):
    """Convert stage metrics to DataFrame.
    
    Args:
        job_metrics: Job metrics dictionary
        
    Returns:
        DataFrame with stage metrics
    """
    records = []
    
    for stage_name, stage in job_metrics.get('stages', {}).items():
        # Skip incomplete stages
        if not stage.get('end_time'):
            continue
            
        record = {
            'job_name': job_metrics.get('job_name', 'unknown'),
            'execution_id': job_metrics.get('execution_id', 'unknown'),
            'stage_name': stage_name,
            'start_time': stage.get('start_time'),
            'end_time': stage.get('end_time'),
            'duration_seconds': stage.get('duration_seconds', 0),
            'status': stage.get('status', 'unknown'),
            'records_processed': stage.get('records', {}).get('processed', 0),
            'records_succeeded': stage.get('records', {}).get('succeeded', 0),
            'records_failed': stage.get('records', {}).get('failed', 0)
        }
        
        records.append(record)
    
    # Create DataFrame
    if records:
        df = pd.DataFrame(records)
        
        # Convert string timestamps to datetime
        for col in ['start_time', 'end_time']:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col])
        
        return df
    
    return pd.DataFrame()

# Function to create execution history chart
def create_execution_history_chart(df):
    """Create execution history chart.
    
    Args:
        df: DataFrame with job metrics
        
    Returns:
        Altair chart object
    """
    if df.empty:
        return None
    
    # Create chart data
    chart_data = df.copy()
    chart_data['job_label'] = chart_data['job_name'] + ' (' + chart_data['execution_id'] + ')'
    
    # Create bar chart for execution duration
    chart = alt.Chart(chart_data).mark_bar().encode(
        x=alt.X('duration_seconds:Q', title='Duration (seconds)'),
        y=alt.Y('job_label:N', title=None, sort='-x'),
        color=alt.Color('status:N', 
                      scale=alt.Scale(domain=['completed', 'failed'], 
                                     range=['#2ca02c', '#d62728'])),
        tooltip=['job_name', 'execution_id', 'start_time', 'end_time', 
                'duration_seconds', 'records_processed', 'status']
    ).properties(
        title='Job Execution History',
        height=max(len(chart_data) * 30, 300)
    )
    
    return chart

# Function to create record processing chart
def create_record_processing_chart(df):
    """Create record processing chart.
    
    Args:
        df: DataFrame with job metrics
        
    Returns:
        Altair chart object
    """
    if df.empty:
        return None
    
    # Create chart data
    chart_data = df.copy()
    chart_data['job_label'] = chart_data['job_name'] + ' (' + chart_data['execution_id'] + ')'
    
    # Reshape the data for stacked bars
    records_data = pd.melt(
        chart_data, 
        id_vars=['job_label', 'job_name', 'execution_id'], 
        value_vars=['records_succeeded', 'records_failed'],
        var_name='record_type', 
        value_name='count'
    )
    
    # Rename for better labels
    records_data['record_type'] = records_data['record_type'].map({
        'records_succeeded': 'Succeeded',
        'records_failed': 'Failed'
    })
    
    # Create stacked bar chart
    chart = alt.Chart(records_data).mark_bar().encode(
        x=alt.X('count:Q', title='Records'),
        y=alt.Y('job_label:N', title=None, sort='-x'),
        color=alt.Color('record_type:N', 
                       scale=alt.Scale(domain=['Succeeded', 'Failed'], 
                                      range=['#2ca02c', '#d62728'])),
        tooltip=['job_name', 'execution_id', 'record_type', 'count']
    ).properties(
        title='Records Processed by Job',
        height=max(len(chart_data) * 30, 300)
    )
    
    return chart

# Function to create stage duration chart
def create_stage_duration_chart(stages_df):
    """Create stage duration chart.
    
    Args:
        stages_df: DataFrame with stage metrics
        
    Returns:
        Altair chart object
    """
    if stages_df.empty:
        return None
    
    # Create chart
    chart = alt.Chart(stages_df).mark_bar().encode(
        x=alt.X('duration_seconds:Q', title='Duration (seconds)'),
        y=alt.Y('stage_name:N', title=None, sort='-x'),
        color=alt.Color('status:N', 
                      scale=alt.Scale(domain=['completed', 'failed'], 
                                     range=['#2ca02c', '#d62728'])),
        tooltip=['stage_name', 'start_time', 'end_time', 
                'duration_seconds', 'records_processed', 'status']
    ).properties(
        title='Stage Durations',
        height=max(len(stages_df) * 30, 300)
    )
    
    return chart

# Sidebar for controls
st.sidebar.title("DataSwitch Monitor")

# Refresh button and auto-refresh toggle
refresh_col, auto_refresh_col = st.sidebar.columns(2)

with refresh_col:
    if st.button("🔄 Refresh"):
        st.experimental_rerun()

with auto_refresh_col:
    auto_refresh = st.checkbox("Auto Refresh", value=False)
    if auto_refresh:
        refresh_interval = st.slider("Interval (sec)", 5, 60, 30)
        time_placeholder = st.empty()
        # Display countdown
        for remaining in range(refresh_interval, 0, -1):
            time_placeholder.text(f"Refreshing in {remaining}s")
            time.sleep(1)
        time_placeholder.text("Refreshing now...")
        st.experimental_rerun()

# Filter options
st.sidebar.header("Filters")
time_filter = st.sidebar.selectbox(
    "Time Range",
    ["Last 24 hours", "Last 7 days", "Last 30 days", "All"]
)

# Main dashboard content
st.title("DataSwitch Job Monitoring Dashboard")

# Load metrics and log data
metrics_data = load_metrics_data()
log_data = load_log_data()

# Convert to DataFrames
jobs_df = metrics_to_dataframe(metrics_data)

# Apply time filters
if not jobs_df.empty:
    now = pd.Timestamp.now()
    if time_filter == "Last 24 hours":
        jobs_df = jobs_df[jobs_df['start_time'] > (now - pd.Timedelta(days=1))]
    elif time_filter == "Last 7 days":
        jobs_df = jobs_df[jobs_df['start_time'] > (now - pd.Timedelta(days=7))]
    elif time_filter == "Last 30 days":
        jobs_df = jobs_df[jobs_df['start_time'] > (now - pd.Timedelta(days=30))]

# KPI metrics at the top
if not jobs_df.empty:
    total_jobs = len(jobs_df)
    successful_jobs = len(jobs_df[jobs_df['status'] == 'completed'])
    failed_jobs = len(jobs_df[jobs_df['status'] == 'failed'])
    avg_duration = jobs_df['duration_seconds'].mean()
    total_records = jobs_df['records_processed'].sum()
    
    st.subheader("Job Statistics")
    
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        st.metric("Total Jobs", total_jobs)
    
    with col2:
        st.metric("Successful Jobs", successful_jobs)
    
    with col3:
        st.metric("Failed Jobs", failed_jobs)
    
    with col4:
        st.metric("Avg Duration (sec)", f"{avg_duration:.2f}")
    
    with col5:
        st.metric("Records Processed", f"{total_records:,}")
else:
    st.info("No job metrics data available. Run some jobs to see statistics.")

# Tabs for different views
tab1, tab2, tab3, tab4 = st.tabs(["Jobs Overview", "Job Details", "Logs", "Configuration"])

# Jobs Overview tab
with tab1:
    if not jobs_df.empty:
        # Job execution history
        st.subheader("Job Execution History")
        history_chart = create_execution_history_chart(jobs_df)
        if history_chart:
            st.altair_chart(history_chart, use_container_width=True)
            
        # Record processing chart
        st.subheader("Records Processed")
        records_chart = create_record_processing_chart(jobs_df)
        if records_chart:
            st.altair_chart(records_chart, use_container_width=True)
        
        # Jobs table
        st.subheader("Recent Job Executions")
        jobs_display = jobs_df.copy()
        jobs_display['start_time'] = jobs_display['start_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
        jobs_display['end_time'] = jobs_display['end_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
        jobs_display = jobs_display.sort_values('start_time', ascending=False)
        st.dataframe(jobs_display)
    else:
        st.info("No job data available. Run some jobs to see metrics here.")

# Job Details tab
with tab2:
    # Show detailed information for a selected job
    if not jobs_df.empty:
        # Create a selector for job executions
        job_options = [f"{row['job_name']} ({row['execution_id']}) - {row['start_time'].strftime('%Y-%m-%d %H:%M:%S')}" 
                     for _, row in jobs_df.sort_values('start_time', ascending=False).iterrows()]
        
        selected_job = st.selectbox("Select a job execution", job_options)
        
        if selected_job:
            # Extract execution_id from selection
            execution_id = selected_job.split('(')[1].split(')')[0]
            
            # Find the job in the metrics data
            job_detail = None
            for job in metrics_data:
                if job.get('execution_id') == execution_id:
                    job_detail = job
                    break
            
            if job_detail:
                # Display job details
                st.subheader(f"Job Details: {job_detail.get('job_name')}")
                
                # Job summary
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Status", job_detail.get('status', 'Unknown'))
                with col2:
                    st.metric("Duration", f"{job_detail.get('duration_seconds', 0):.2f} seconds")
                with col3:
                    st.metric("Records Processed", job_detail.get('records', {}).get('processed', 0))
                
                # Stage information
                st.subheader("Stage Information")
                
                # Convert stages to DataFrame
                stages_df = stages_to_dataframe(job_detail)
                
                if not stages_df.empty:
                    # Stage duration chart
                    duration_chart = create_stage_duration_chart(stages_df)
                    if duration_chart:
                        st.altair_chart(duration_chart, use_container_width=True)
                    
                    # Stage details table
                    stages_display = stages_df.copy()
                    stages_display['start_time'] = stages_display['start_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
                    stages_display['end_time'] = stages_display['end_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
                    st.dataframe(stages_display)
                else:
                    st.info("No stage information available for this job.")
                
                # Raw JSON
                with st.expander("View Raw Job Metrics JSON"):
                    st.json(job_detail)
                
    else:
        st.info("No job data available. Run some jobs to see details here.")

# Logs tab
with tab3:
    if log_data:
        # Create a DataFrame from log entries
        logs_df = pd.DataFrame(log_data)
        
        # Add filter controls
        log_level_filter = st.selectbox("Filter by Log Level", ["All", "INFO", "WARNING", "ERROR", "CRITICAL"])
        
        search_term = st.text_input("Search in logs")
        
        # Filter logs
        filtered_logs = logs_df
        
        if log_level_filter != "All":
            filtered_logs = filtered_logs[filtered_logs['level'] == log_level_filter]
        
        if search_term:
            filtered_logs = filtered_logs[filtered_logs['message'].str.contains(search_term, case=False)]
        
        # Display logs
        st.subheader(f"Log Entries ({len(filtered_logs)} entries)")
        
        if not filtered_logs.empty:
            # Convert to display format
            logs_display = filtered_logs.copy()
            
            # Custom CSS for log levels
            st.markdown("""
                <style>
                    .log-info { color: #0d6efd; }
                    .log-warning { color: #ffc107; }
                    .log-error { color: #dc3545; }
                    .log-critical { color: #dc3545; font-weight: bold; }
                </style>
            """, unsafe_allow_html=True)
            
            # Display logs in a nice format
            for _, log in logs_display.iterrows():
                level_class = f"log-{log['level'].lower()}"
                st.markdown(f"<span class='{level_class}'>{log['timestamp']} - {log['level']}</span> - {log['message']}", unsafe_allow_html=True)
        else:
            st.info("No logs match the selected filters.")
    else:
        st.info("No log data available.")

# Configuration tab
with tab4:
    # Load and display configuration files
    st.subheader("Configuration Files")
    
    # Job Config
    with st.expander("Job Configuration"):
        try:
            with open("config/job_config.yaml", "r") as f:
                job_config = f.read()
            st.code(job_config, language="yaml")
        except Exception as e:
            st.warning(f"Failed to load job configuration: {str(e)}")
    
    # Logging Config
    with st.expander("Logging Configuration"):
        try:
            with open("config/logging_config.yaml", "r") as f:
                logging_config = f.read()
            st.code(logging_config, language="yaml")
        except Exception as e:
            st.warning(f"Failed to load logging configuration: {str(e)}")
