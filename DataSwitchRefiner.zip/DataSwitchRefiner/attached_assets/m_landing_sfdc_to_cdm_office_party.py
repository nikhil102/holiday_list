import pyspark
from pyspark import SparkConf,SQLContext,SparkContext,StorageLevel
from pyspark.sql import SparkSession,DataFrame,Window,Row
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import pyspark.sql.functions as f
import pyspark.sql.types as t
import datetime
import time
import os
import sys
from functools import reduce
from os.path import join, abspath

# Hardcoded JDBC connection details
server_name = "w908925\\CGSQL"
database_name_lkp = "msscdm_dev3"
database_name_source = "msscdm_dev3"
database_name_target = "msscdm_dev4"
jdbc_url_lkp = f"jdbc:sqlserver://w908925.cguser.capgroup.com\\CGSQL;databaseName={database_name_lkp};user=spark_user;password=spark@25091990;trustServerCertificate=true;encrypt=false"
jdbc_url_source = f"jdbc:sqlserver://w908925.cguser.capgroup.com\\CGSQL;databaseName={database_name_source};user=spark_user;password=spark@25091990;trustServerCertificate=true;encrypt=false"
jdbc_url_target = f"jdbc:sqlserver://w908925.cguser.capgroup.com\\CGSQL;databaseName={database_name_target};user=spark_user;password=spark@25091990;trustServerCertificate=true;encrypt=false"

# JDBC Driver Path
jdbc_driver_path = "C:/Drivers/mssql-jdbc-12.4.2.jre11.jar"
authentication_dll_path = "C:/Drivers"  # Location of `mssql-jdbc_auth-12.4.2.x64.dll`

# Initialize Spark Session with Authentication DLL Config
spark = SparkSession.builder \
    .appName("s_m_landing_sfdc_to_cdm_office_party_pyspark") \
    .config("spark.ui.port", "4040") \
    .config("spark.driver.extraClassPath", jdbc_driver_path) \
    .config("spark.executor.extraClassPath", jdbc_driver_path) \
    .config("spark.executor.extraJavaOptions", f"-Djava.library.path={authentication_dll_path}") \
    .getOrCreate()

# Connection Properties
connection_properties = {
    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"
}
user = "spark_user"
password = "spark@25091990"
conn = spark._sc._gateway.jvm.java.sql.DriverManager.getConnection(jdbc_url_target,user,password)
stmt = conn.createStatement()

# Global Variables
PMMappingName = "m_landing_sfdc_to_cdm_office_party_pyspark" 

try:

	# Reading Data From Source - SQ_pre_land_sfdc_office
	# Description : Relational Reader

	query = f""" SELECT pre_land_sfdc_office.Id, 
	pre_land_sfdc_office.Status__c, pre_land_sfdc_office.Type, 
	pre_land_sfdc_office.Direct__c, pre_land_sfdc_office.Name, 
	pre_land_sfdc_office.CreatedByAlias, pre_land_sfdc_office.CreatedDate, 
	pre_land_sfdc_office.LastModifiedByAlias, pre_land_sfdc_office.LastModifiedDate, 
	pre_land_sfdc_office.Source_System_Name, pre_land_sfdc_office.RecordTypeName, 
	pre_land_sfdc_office.Location_Type__c, pre_land_sfdc_office.Inactivated_Date__c,
	case
	when Client_Group_C is null and RecordTypeName='NT Advisory Office RO' then 'United States of America'
	when pre_land_sfdc_office.Client_Group_C IN ('ECM Local Consultant','ECM Global Consultant') and pre_land_sfdc_office.BillingCountry IN('United Kingdom','Ireland','Channel Islands','Guernsey') then 'UK' 
	when Client_Group_C='Australia' and pre_land_sfdc_office.BillingCountry<>'Australia' then null
	when pre_land_sfdc_office.Client_Group_C IN ('ECM Local Consultant','ECM Global Consultant') and pre_land_sfdc_office.BillingCountry NOT IN('United Kingdom','Ireland','Channel Islands','Guernsey') then null 
	else
	pre_land_sfdc_office.Client_Group_C
	end CLIENT_GROUP_ID 
	FROM
	pre_land_sfdc_office
	where RecordTypeName in
	('Financial Institutions Office',
	'Institutional Client Office',
	'Institutional Consultant Office',
	'Institutional Other Intermediary Office'
	,'NT Advisory Office RO','Retail Office RO','CIAM Office RO')
	and 
	((Client_Group_C<>'Australia' and pre_land_sfdc_office.BillingCountry <> 'Australia') or Client_Group_C is null or (Client_Group_C='Australia' and pre_land_sfdc_office.BillingCountry <> 'Australia') or  ( Client_Group_C<>'Australia'  and pre_land_sfdc_office.BillingCountry is null))

	--CAR ORG Business Office
	union
	SELECT concat(pre_land_sfdc_office.Id,'|BUSSADDR') id, 
	pre_land_sfdc_office.Status__c, pre_land_sfdc_office.Type, 
	pre_land_sfdc_office.Direct__c, pre_land_sfdc_office.Name, 
	pre_land_sfdc_office.CreatedByAlias, pre_land_sfdc_office.CreatedDate, 
	pre_land_sfdc_office.LastModifiedByAlias, pre_land_sfdc_office.LastModifiedDate, 
	pre_land_sfdc_office.Source_System_Name, pre_land_sfdc_office.RecordTypeName, 
	pre_land_sfdc_office.Location_Type__c, pre_land_sfdc_office.Inactivated_Date__c ,'Australia' CLIENT_GROUP_ID
	FROM
	pre_land_sfdc_office
	where pre_land_sfdc_office.[RecordTypeName] in
	('Financial Institutions Office',
	'Institutional Client Office',
	'Institutional Consultant Office',
	'Institutional Other Intermediary Office'
	,'NT Advisory Office RO','Retail Office RO','CIAM Office RO')
	and ((Client_Group_C='Australia' and BillingCountry is NULL) OR (Client_Group_C is NOT NULL and BillingCountry = 'Australia'))
	and BillingCountry is not null
	--CAR ORG Mailing Office
	union
	SELECT concat(pre_land_sfdc_office.Id,'|MAILADDR') id, 
	pre_land_sfdc_office.Status__c, pre_land_sfdc_office.Type, 
	pre_land_sfdc_office.Direct__c, pre_land_sfdc_office.Name, 
	pre_land_sfdc_office.CreatedByAlias, pre_land_sfdc_office.CreatedDate, 
	pre_land_sfdc_office.LastModifiedByAlias, pre_land_sfdc_office.LastModifiedDate, 
	pre_land_sfdc_office.Source_System_Name, pre_land_sfdc_office.RecordTypeName, 
	pre_land_sfdc_office.Location_Type__c, pre_land_sfdc_office.Inactivated_Date__c ,'Australia' CLIENT_GROUP_ID
	FROM
	pre_land_sfdc_office
	where pre_land_sfdc_office.[RecordTypeName] in
	('Financial Institutions Office',
	'Institutional Client Office',
	'Institutional Consultant Office',
	'Institutional Other Intermediary Office'
	,'NT Advisory Office RO','Retail Office RO','CIAM Office RO')
	and ((Client_Group_C='Australia' and BillingCountry is NULL) OR (Client_Group_C is NOT NULL and BillingCountry = 'Australia'))
	and shipingcountry IS NOT NULL 
	AND (
	shippingstreet IS NOT NULL
	OR shippingcity IS NOT NULL
	OR shippingstate IS NOT NULL
	OR shippingpostalcode IS NOT NULL
	)
	union

	--LIC Org Business Office
	SELECT distinct concat(org.Id,'|BUSSADDR') id, 
	org.Status__c,
	Null Type, 
	Null Direct__c,
	org.Name, 
	org.CreatedByAlias,
	org.CreatedDate, 
	org.LastModifiedByAlias,
	org.LastModifiedDate, 
	org.Source_System_Name,
	org.RecordTypeName, 
	Null Location_Type__c,
	org.Inactivated_Date__c ,'Australia' CLIENT_GROUP_ID
	FROM
	pre_land_sfdc_organization org
	left join 
	pre_land_sfdc_office ofc
	on org.id=ofc.ParentId
	where ofc.[RecordTypeName] in
	('Financial Institutions Office',
	'Institutional Client Office',
	'Institutional Consultant Office',
	'Institutional Other Intermediary Office'
	,'NT Advisory Office RO','Retail Office RO','CIAM Office RO')
	and ((ofc.Client_Group_C='Australia' and ofc.BillingCountry is NULL) OR (ofc.Client_Group_C is NOT NULL and ofc.BillingCountry = 'Australia'))
	and org.BillingCountry is not null

	union
	--LIC ORG Mailing Office
	SELECT distinct concat(org.Id,'|MAILADDR') id, 
	org.Status__c,
	Null Type, 
	Null Direct__c,
	org.Name, 
	org.CreatedByAlias,
	org.CreatedDate, 
	org.LastModifiedByAlias,
	org.LastModifiedDate, 
	org.Source_System_Name,
	org.RecordTypeName, 
	Null Location_Type__c,
	org.Inactivated_Date__c ,'Australia' CLIENT_GROUP_ID
	FROM
	pre_land_sfdc_organization org
	left join 
	pre_land_sfdc_office ofc
	on org.id=ofc.ParentId
	where ofc.[RecordTypeName] in
	('Financial Institutions Office',
	'Institutional Client Office',
	'Institutional Consultant Office',
	'Institutional Other Intermediary Office'
	,'NT Advisory Office RO','Retail Office RO','CIAM Office RO')
	and ((ofc.Client_Group_C='Australia' and ofc.BillingCountry is NULL) OR (ofc.Client_Group_C is NOT NULL and ofc.BillingCountry = 'Australia'))
	and org.ShippingCountry is not null
	AND (
	org.shippingstreet IS NOT NULL
	OR org.shippingcity IS NOT NULL
	OR org.shippingstate IS NOT NULL
	OR org.shippingpostalcode IS NOT NULL
	) """
	sq_pre_land_sfdc_office = spark.read.format("jdbc").options(url=jdbc_url_source, driver="com.microsoft.sqlserver.jdbc.SQLServerDriver", query=query).load()
	print("source",sq_pre_land_sfdc_office.count())
	# Reading Data From Source - lkup_transformation_map
	# Description : NA

	query = f""" SELECT LTRIM(RTRIM(std_lkup_id)) as std_lkup_id
	,LTRIM(RTRIM(src_sys_nm)) as src_sys_nm
	,LTRIM(RTRIM(src_val)) as src_val
	,LTRIM(RTRIM(attrib_nm)) as attrib_nm 
	FROM lkup_transformation_map
	where src_sys_nm in ('SFDC') """
	lkup_transformation_map = spark.read.format("jdbc").options(url=jdbc_url_source, driver="com.microsoft.sqlserver.jdbc.SQLServerDriver", query=query).load()
	lkup_transformation_map = lkup_transformation_map.groupBy("src_val","attrib_nm").agg(first("std_lkup_id").alias("std_lkup_id"))
	# Reading Data From Source - TODAY_PARTY_XFORM_S3
	# Description : NA

	query = f""" SELECT LTRIM(RTRIM(SOURCE_SYSTEM)) as SOURCE_SYSTEM, LTRIM(RTRIM(SOURCE_PARTY_ID)) as SOURCE_PARTY_ID FROM  TODAY_PARTY_XFORM  WHERE SOURCE_SYSTEM in ( 'SOFI','DORIS','SALESCONNECT')"""
	today_party_xform_s3 = spark.read.format("jdbc").options(url=jdbc_url_source, driver="com.microsoft.sqlserver.jdbc.SQLServerDriver", query=query).load()
	today_party_xform_s3 = today_party_xform_s3.groupBy("SOURCE_PARTY_ID").agg(first("SOURCE_SYSTEM").alias("SOURCE_SYSTEM"))
	# Filter Transformation  - fltr_as_reqrd
	# Description : NA

	fltr_as_reqrd = sq_pre_land_sfdc_office.select(col("Id"),col("Status__c"),col("Type"),col("Direct__c"),col("Name"),col("CreatedByAlias"),col("CreatedDate"),col("LastModifiedByAlias"),col("LastModifiedDate"),col("Source_System_Name"),col("RecordTypeName").alias("RecordTypeName1"),col("Location_Type__c"),col("Inactivated_Date__c"),col("CLIENT_GROUP_ID")).filter(lit(True))

	# Expression Transformation  - DSExp_lkp_values_exp_transformation_5
	# Description : NA - lookup1
	dsexp_lkp_values_exp_transformation_5 = fltr_as_reqrd.select(col("Id"),col("Name"),col("LastModifiedDate"),col("CreatedByAlias"),col("CreatedDate"),col("Type"),col("Direct__c"),col("LastModifiedByAlias"),col("RecordTypeName1"),col("Location_Type__c"),col("Inactivated_Date__c"),col("Status__c"),col("Source_System_Name"),col("CLIENT_GROUP_ID"))
	dsexp_lkp_values_exp_transformation_5 = dsexp_lkp_values_exp_transformation_5.withColumn("src_val_in",ltrim(rtrim(col("Status__c")))) \
	.withColumn("attrib_nm_in",lit('PARTY_STATUS_ID'))
	# Lookup Transformation  - DSUnLkp_lkp_values_exp_transformation_5
	# Description : NA - lookup1
	dsunlkp_lkp_values_exp_transformation_5 = dsexp_lkp_values_exp_transformation_5.join(lkup_transformation_map,(lkup_transformation_map['src_val'] == dsexp_lkp_values_exp_transformation_5['src_val_in']) & (lkup_transformation_map['attrib_nm'] == dsexp_lkp_values_exp_transformation_5['attrib_nm_in']),how='left').select(dsexp_lkp_values_exp_transformation_5["*"],lkup_transformation_map["std_lkup_id"].alias("unLkpRT_std_lkup_id1") ).drop("src_val_in","attrib_nm_in")

	# Expression Transformation  - DSExp_lkp_values_exp_transformation_1
	# Description : NA - lookup2
	dsexp_lkp_values_exp_transformation_1 = dsunlkp_lkp_values_exp_transformation_5.withColumn("src_val_in",lit('Office')) \
	.withColumn("attrib_nm_in",lit('PARTY_TYPE_ID'))
	# Lookup Transformation  - DSUnLkp_lkp_values_exp_transformation_1
	# Description : NA lookup2
	dsunlkp_lkp_values_exp_transformation_1 = dsexp_lkp_values_exp_transformation_1.join(lkup_transformation_map,(lkup_transformation_map['src_val'] == dsexp_lkp_values_exp_transformation_1['src_val_in']) & (lkup_transformation_map['attrib_nm'] == dsexp_lkp_values_exp_transformation_1['attrib_nm_in']),how='left').select(dsexp_lkp_values_exp_transformation_1["*"],lkup_transformation_map["std_lkup_id"].alias("unLkpRT_std_lkup_id2") ).drop("src_val_in","attrib_nm_in")

	# Expression Transformation  - DSExp_TODAY_PARTY_XFORM_LOOKUP_exp_transformation_4
	# Description : NA -lookup3
	dsexp_today_party_xform_lookup_exp_transformation_4 = dsunlkp_lkp_values_exp_transformation_1.withColumn("IN_Id",concat(lit('OFF_'),col("Direct__c")))
	# Lookup Transformation  - DSUnLkp_TODAY_PARTY_XFORM_LOOKUP_exp_transformation_4
	# Description : NA - lookup3
	dsunlkp_today_party_xform_lookup_exp_transformation_4 = dsexp_today_party_xform_lookup_exp_transformation_4.join(today_party_xform_s3,(today_party_xform_s3['SOURCE_PARTY_ID'] == dsexp_today_party_xform_lookup_exp_transformation_4['IN_Id']),how='left').select(dsexp_today_party_xform_lookup_exp_transformation_4["*"],today_party_xform_s3["SOURCE_SYSTEM"].alias("unLkpRT_SOURCE_SYSTEM3") ).drop("IN_Id")

	# Expression Transformation  - DSExp_lkp_values_exp_transformation_6
	# Description : NA  - lookup4
	dsexp_lkp_values_exp_transformation_6 = dsunlkp_today_party_xform_lookup_exp_transformation_4.withColumn("src_val_in",lit('RM-RIA/BT')) \
	.withColumn("attrib_nm_in",lit('OFFICE_RIA_COVERAGE_TYPE'))
	# Lookup Transformation  - DSUnLkp_lkp_values_exp_transformation_6
	# Description : NA
	dsunlkp_lkp_values_exp_transformation_6 = dsexp_lkp_values_exp_transformation_6.join(lkup_transformation_map,(lkup_transformation_map['src_val'] == dsexp_lkp_values_exp_transformation_6['src_val_in']) & (lkup_transformation_map['attrib_nm'] == dsexp_lkp_values_exp_transformation_6['attrib_nm_in']),how='left').select(dsexp_lkp_values_exp_transformation_6["*"],lkup_transformation_map["std_lkup_id"].alias("unLkpRT_std_lkup_id4") ).drop("src_val_in","attrib_nm_in")

	# Expression Transformation  - DSExp_lkp_values_exp_transformation_0
	# Description : NA - lookup5
	dsexp_lkp_values_exp_transformation_0 = dsunlkp_lkp_values_exp_transformation_6.withColumn("src_val_in",col("CLIENT_GROUP_ID")) \
	.withColumn("attrib_nm_in",lit('CLIENT_GROUP_ID'))
	# Lookup Transformation  - DSUnLkp_lkp_values_exp_transformation_0
	# Description : NA

	dsunlkp_lkp_values_exp_transformation_0 = dsexp_lkp_values_exp_transformation_0.join(lkup_transformation_map,(lkup_transformation_map['src_val'] == dsexp_lkp_values_exp_transformation_0['src_val_in']) & (lkup_transformation_map['attrib_nm'] == dsexp_lkp_values_exp_transformation_0['attrib_nm_in']),how='left').select(dsexp_lkp_values_exp_transformation_0["*"],lkup_transformation_map["std_lkup_id"].alias("unLkpRT_std_lkup_id5")).drop("src_val_in","attrib_nm_in")

	# Expression Transformation  - DSExp_LKP_VALUES_exp_transformation_2
	# Description : NA lookup6
	dsexp_lkp_values_exp_transformation_2 = dsunlkp_lkp_values_exp_transformation_0.withColumn("src_val_in",lit('Branch (OSJ)')) \
	.withColumn("attrib_nm_in",lit('OFFICE_TYPE_ID'))
	# Lookup Transformation  - DSUnLkp_LKP_VALUES_exp_transformation_2
	# Description : NA
	dsunlkp_lkp_values_exp_transformation_2 = dsexp_lkp_values_exp_transformation_2.join(lkup_transformation_map,(lkup_transformation_map['src_val'] == dsexp_lkp_values_exp_transformation_2['src_val_in']) & (lkup_transformation_map['attrib_nm'] == dsexp_lkp_values_exp_transformation_2['attrib_nm_in']),how='left').select(dsexp_lkp_values_exp_transformation_2["*"],lkup_transformation_map["std_lkup_id"].alias("unLkpRT_std_lkup_id6") ).drop("src_val_in","attrib_nm_in")	

	# Expression Transformation  - DSExp_LKP_VALUES_exp_transformation_3
	# Description : NA - lookup7
	dsexp_lkp_values_exp_transformation_3 = dsunlkp_lkp_values_exp_transformation_2.withColumn("src_val_in",ltrim(rtrim(col("Location_Type__c")))) \
	.withColumn("attrib_nm_in",lit('OFFICE_TYPE_ID'))	
	# Lookup Transformation  - DSUnLkp_LKP_VALUES_exp_transformation_3
	# Description : NA
	dsunlkp_lkp_values_exp_transformation_3 = dsexp_lkp_values_exp_transformation_3.join(lkup_transformation_map,(lkup_transformation_map['src_val'] == dsexp_lkp_values_exp_transformation_3['src_val_in']) & (lkup_transformation_map['attrib_nm'] == dsexp_lkp_values_exp_transformation_3['attrib_nm_in']),how='left').select(dsexp_lkp_values_exp_transformation_3["*"],lkup_transformation_map["std_lkup_id"].alias("unLkpRT_std_lkup_id7") ).drop("src_val_in","attrib_nm_in")


	# Expression Transformation  - exp_transformation
	# Description : NA
	exp_transformation = dsunlkp_lkp_values_exp_transformation_3.withColumn("Id_VAR",concat(lit('OFF_'),col("Id"))) \
	.withColumn("Id_OUT",col("Id_VAR")) \
	.withColumn("var_status_Id",col("unLkpRT_std_lkup_id1")) \
	.withColumn("PARTY_STATUS_ID",when(col("Status__c").isNull(),lit(None)).otherwise(when(col("var_status_Id").isNull(),lit(9999)).otherwise(col("var_status_Id")))) \
	.withColumn("var_type_id",col("unLkpRT_std_lkup_id2")) \
	.withColumn("PARTY_TYPE_ID",when(col("var_type_id").isNull(),lit(9999)).otherwise(col("var_type_id"))) \
	.withColumn("Direct__c_out",when(col("Direct__c").isNull(),lit(None)).otherwise(concat(lit('OFF_'),col("Direct__c")))) \
	.withColumn("MAPPING_NAME",lit(PMMappingName)) \
	.withColumn("lookupSOFIDORIS",col("unLkpRT_SOURCE_SYSTEM3")) \
	.withColumn("DEFERRED_OWNERSHIP_IND_OUT",when(ltrim(rtrim(col("RecordTypeName1"))).isin('Retail Office RO','CIAM Office RO','Financial Intermediary','NT Advisory Office RO'),'Y').otherwise('N')) \
    .withColumn("V_Lookup_Office_Type_ID",when(((ltrim(rtrim(col("Location_Type__c"))) == 'Home/Main (HQ)')| (ltrim(rtrim(col("Location_Type__c"))) == 'Home or Main (HQ)')),col("unLkpRT_std_lkup_id6")).otherwise(col("unLkpRT_std_lkup_id7"))) \
    .withColumn("V_Office_Type_ID",when((col("V_Lookup_Office_Type_ID").isNotNull()) & (col("Location_Type__c").isNotNull()),col("V_Lookup_Office_Type_ID")).when((col("V_Lookup_Office_Type_ID").isNull()) & (col("Location_Type__c").isNull()),lit(None)).otherwise(lit(9999))) \
	.withColumn("Office_Type_ID",col("V_Office_Type_ID")) \
	.withColumn("V_RIA_COVERAGE_TYPE_ID",col("unLkpRT_std_lkup_id4")) \
	.withColumn("V_RIA_COVERAGE_TYPE_ID1",when(col("V_RIA_COVERAGE_TYPE_ID").isNotNull(),col("V_RIA_COVERAGE_TYPE_ID")).otherwise('9999')) \
	.withColumn("RIA_COVERAGE_TYPE_ID",when(col("RecordTypeName1") == 'NT Advisory Office RO',col("V_RIA_COVERAGE_TYPE_ID1")).otherwise(lit(None))) \
	.withColumn("CLIENT_GROUP_ID1",col("unLkpRT_std_lkup_id5"))
	# Filter Transformation  - FILTRANS
	# Description : NA

	filtrans = exp_transformation.select(col("RecordTypeName1"),col("Name"),col("Status__c"),col("Type"),col("lookupSOFIDORIS"),col("DEFERRED_OWNERSHIP_IND_OUT"),col("Office_Type_ID"),col("Inactivated_Date__c").alias("Party_Inactivation_Date"),col("Id_OUT"),col("LastModifiedDate"),col("RIA_COVERAGE_TYPE_ID"),col("PARTY_STATUS_ID"),col("PARTY_TYPE_ID"),col("Source_System_Name"),col("CreatedByAlias"),col("CreatedDate"),col("Direct__c_out"),col("LastModifiedByAlias"),col("MAPPING_NAME"),col("CLIENT_GROUP_ID1").alias("CLIENT_GROUP_ID")).filter(lit(True))
    #column name change
	filtrans_out = filtrans.select(col("Id_OUT").alias("source_party_id"),col("LastModifiedDate").alias("last_updated_date"),col("Party_Inactivation_Date").alias("party_inactivation_date"),col("PARTY_STATUS_ID").alias("party_status_id"),col("PARTY_TYPE_ID").alias("party_type_id"),col("Source_System_Name").alias("source_system"),col("CreatedByAlias").alias("created_by"),col("CreatedDate").alias("created_date"),col("LastModifiedByAlias").alias("last_updated_by"),col("MAPPING_NAME").alias("MAPPING_NAME"),col("DEFERRED_OWNERSHIP_IND_OUT").alias("DEFERRED_OWNERSHIP_IND"),col("Office_Type_ID").alias("office_type_id"),col("RIA_COVERAGE_TYPE_ID").alias("RIA_COVERAGE_TYPE_ID"),col("CLIENT_GROUP_ID").alias("CLIENT_GROUP_ID"))
	 
	# Target Pre SQL
	delete_query = f"""delete from dbo.TODAY_PARTY_XFORM where MAPPING_NAME='{PMMappingName}'"""
	stmt.executeUpdate(delete_query)
	stmt.close()
	conn.close()

	# Writing data to Target insert
	# Description : NA
	filtrans_out.write.format('jdbc').option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver").option("url",jdbc_url_target).option("dbtable","today_party_xform").option("user", user).option("password", password).mode('append').save()
	print("Target Count",filtrans_out.count())
	print("Execution completed")   
    

except Exception as Error:
	print(Error)