import pyspark
from pyspark import SparkConf,SQLContext,SparkContext,StorageLevel
from pyspark.sql import SparkSession,DataFrame,Window,Row
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import pyspark.sql.functions as f
import pyspark.sql.types as t
import datetime
import time
import os
import sys
from functools import reduce
from os.path import join, abspath
import jaydebeapi
import subprocess

# Hardcoded JDBC connection details
server_name = "w908925\\CGSQL"
database_name_lkp = "msscdm_dev4"
database_name_source = "msscdm_dev4"
database_name_target = "msscdm_dev4"
db_user="spark_user"
db_password="spark@25091990"
jdbc_url_lkp = f"jdbc:sqlserver://w908925.cguser.capgroup.com\\CGSQL;databaseName={database_name_lkp};user={db_user};password={db_password};trustServerCertificate=true;encrypt=false"
jdbc_url_source = f"jdbc:sqlserver://w908925.cguser.capgroup.com\\CGSQL;databaseName={database_name_source};user={db_user};password={db_password};trustServerCertificate=true;encrypt=false"
jdbc_url_target = f"jdbc:sqlserver://w908925.cguser.capgroup.com\\CGSQL;databaseName={database_name_target};user={db_user};password={db_password};trustServerCertificate=true;encrypt=false"

# JDBC Driver Path
jdbc_driver_path = "C:/Drivers/mssql-jdbc-12.4.2.jre11.jar"
authentication_dll_path = "C:/Drivers"  # Location of `mssql-jdbc_auth-12.4.2.x64.dll`

os.environ['PYSPARK_PYTHON'] = sys.executable
os.environ['PYSPARK_DRIVER_PYTHON'] = sys.executable

# Initialize Spark Session with Authentication DLL Config
# Modify Spark configuration for better memory management
spark = SparkSession.builder \
    .appName("s_m_landing_sales_connect_to_cdm_person_party") \
    .config("spark.ui.port", "4040") \
    .config("spark.driver.extraClassPath", jdbc_driver_path) \
    .config("spark.executor.extraClassPath", jdbc_driver_path) \
    .config("spark.executor.extraJavaOptions", f"-Djava.library.path={authentication_dll_path}") \
    .config("spark.driver.memory", "16g") \
    .config("spark.executor.memory", "16g") \
    .config("spark.memory.offHeap.enabled", "true") \
    .config("spark.memory.offHeap.size", "16g") \
    .config("spark.sql.shuffle.partitions", "50") \
    .config("spark.default.parallelism", "50") \
    .config("spark.sql.debug.maxToStringFields", "100") \
    .config("spark.driver.maxResultSize", "8g") \
    .config("spark.sql.autoBroadcastJoinThreshold", "-1") \
    .config("spark.memory.fraction", "0.8") \
    .config("spark.memory.storageFraction", "0.3") \
    .config("spark.sql.shuffle.partitions", "50") \
    .config("spark.dynamicAllocation.enabled", "true") \
    .config("spark.shuffle.service.enabled", "true") \
    .getOrCreate()

# Connection Properties
# connection_properties = {
    # "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"
# }

conn = spark._sc._gateway.jvm.java.sql.DriverManager.getConnection(jdbc_url_target,db_user,db_password)
stmt = conn.createStatement()
conn = jaydebeapi.connect(
	"com.microsoft.sqlserver.jdbc.SQLServerDriver",
	jdbc_url_target,
	[db_user, db_password],
	jars=jdbc_driver_path
	)
curs = conn.cursor()

# Global Variables
PMMappingName = "m_landing_sales_connect_to_cdm_person_party_pyspark"
PMWorkflowName = "wf_landing_sales_connect_to_cdm_person_party"

def is_spaces(text):
    if (text is None):
        return(False)
    return(text.isspace())
 
is_spaces_udf = udf(is_spaces, BooleanType())
     
try:

    query=f"""SELECT pre_land_sales_connect_rep.Contact_Id, pre_land_sales_connect_rep.Rep_First_Name, pre_land_sales_connect_rep.Rep_Middle_Name, pre_land_sales_connect_rep.Rep_Last_Name, pre_land_sales_connect_rep.Rep_Prefix, pre_land_sales_connect_rep.Rep_Suffix, pre_land_sales_connect_rep.Rep_Partnership_Indicator, pre_land_sales_connect_rep.Rep_Crd_Number, pre_land_sales_connect_rep.Sc_Rep_Action_Code, pre_land_sales_connect_rep.Rep_Market_Timer_Indicator, pre_land_sales_connect_rep.Rep_Ud_Maintained_Code, pre_land_sales_connect_rep.Sc_Rep_Activity_Code, pre_land_sales_connect_rep.Rep_Member_Flag, pre_land_sales_connect_rep.Rep_Language_Id, pre_land_sales_connect_rep.Rep_Time_Zone_Id, pre_land_sales_connect_rep.Rep_Title, pre_land_sales_connect_rep.Rep_Nickname, pre_land_sales_connect_rep.External_Rep_Identifier, pre_land_sales_connect_rep.Rep_Office_Id, pre_land_sales_connect_rep.Rep_Firm_Id, pre_land_sales_connect_rep.Rep_Status_Code, pre_land_sales_connect_rep.Rep_Channel_Code, pre_land_sales_connect_rep.Rep_Sub_Channel_Code, pre_land_sales_connect_rep.First_Trade_Date_Rep, pre_land_sales_connect_rep.Last_Trade_Date_Rep, pre_land_sales_connect_rep.Last_Timer_Trade_Date_Rep, pre_land_sales_connect_rep.Rep_Channel_Locked_Code, pre_land_sales_connect_rep.Rep_Sub_Channel_Locked_Code, pre_land_sales_connect_rep.Work_Address_Line_1, pre_land_sales_connect_rep.Work_Address_Line_2, pre_land_sales_connect_rep.Work_Address_Line_3, pre_land_sales_connect_rep.Work_Address_Line_4, pre_land_sales_connect_rep.Work_City, pre_land_sales_connect_rep.Work_State_Or_Province, pre_land_sales_connect_rep.Work_Postal_Code_1, pre_land_sales_connect_rep.Work_Postal_Code_2, pre_land_sales_connect_rep.Work_Country_Code, pre_land_sales_connect_rep.Work_Address_Locked_Code, pre_land_sales_connect_rep.Home_Address_Line_1, pre_land_sales_connect_rep.Home_Address_Line_2, pre_land_sales_connect_rep.Home_Address_Line_3, pre_land_sales_connect_rep.Home_Address_Line_4, pre_land_sales_connect_rep.Home_City, pre_land_sales_connect_rep.Home_State_Or_Province, pre_land_sales_connect_rep.Home_Postal_Code_1, pre_land_sales_connect_rep.Home_Postal_Code_2, pre_land_sales_connect_rep.Home_Country_Code, pre_land_sales_connect_rep.Rep_Business_Phone_Number, pre_land_sales_connect_rep.Rep_Business_Phone_Extension, pre_land_sales_connect_rep.Rep_Home_Phone_Number, pre_land_sales_connect_rep.Rep_Fax_Number_1, pre_land_sales_connect_rep.Rep_Fax_Number_2, pre_land_sales_connect_rep.Rep_Mobile_Phone_Number, pre_land_sales_connect_rep.Rep_Wireless_Carrier_Id, pre_land_sales_connect_rep.Rep_Assistant_Name, pre_land_sales_connect_rep.Rep_Assistant_Phone_Number, pre_land_sales_connect_rep.Rep_Type, pre_land_sales_connect_rep.Rep_Email_Address, pre_land_sales_connect_rep.Rep_Email_Address_Continuation, pre_land_sales_connect_rep.Territory_For_Category_1, pre_land_sales_connect_rep.Territory_For_Category_2, pre_land_sales_connect_rep.Territory_For_Category_3, pre_land_sales_connect_rep.Territory_For_Category_4, pre_land_sales_connect_rep.Territory_For_Category_5, pre_land_sales_connect_rep.Territory_For_Category_6, pre_land_sales_connect_rep.Territory_For_Category_7, pre_land_sales_connect_rep.Territory_For_Category_8, pre_land_sales_connect_rep.Territory_For_Category_9, pre_land_sales_connect_rep.Territory_For_Category_10, pre_land_sales_connect_rep.Territory_For_Category_11, pre_land_sales_connect_rep.Territory_For_Category_12, pre_land_sales_connect_rep.Territory_For_Category_13, pre_land_sales_connect_rep.Territory_For_Category_14, pre_land_sales_connect_rep.Territory_For_Category_15, pre_land_sales_connect_rep.Rep_Unique_Id_For_First_Partnership_Member, pre_land_sales_connect_rep.Percentage_Allocated_To_First_Member, pre_land_sales_connect_rep.Rep_Unique_Id_For_Second_Partnership_Member, pre_land_sales_connect_rep.Percentage_Allocated_To_Second_Member, pre_land_sales_connect_rep.Rep_Unique_Id_For_Third_Partnership_Member, pre_land_sales_connect_rep.Percentage_Allocated_To_Third_Member, pre_land_sales_connect_rep.Rep_Unique_Id_For_Fourth_Partnership_Member, pre_land_sales_connect_rep.Percentage_Allocated_To_Fourth_Member, pre_land_sales_connect_rep.Rep_Unique_Id_For_Fifth_Partnership_Member, pre_land_sales_connect_rep.Percentage_Allocated_To_Fifth_Member, pre_land_sales_connect_rep.Rep_Unique_Id_For_Sixth_Partnership_Member, pre_land_sales_connect_rep.Percentage_Allocated_To_Sixth_Member, pre_land_sales_connect_rep.Rep_Unique_Id_For_Seventh_Partnership_Member, pre_land_sales_connect_rep.Percentage_Allocated_To_Seventh_Member, pre_land_sales_connect_rep.Rep_Entity_Date_Time_Update, pre_land_sales_connect_rep.Office_Type, pre_land_sales_connect_rep.Rep_Primary_Firm_Trading_Id, pre_land_sales_connect_rep.Rep_Primary_Office_Trading_Id, pre_land_sales_connect_rep.Rep_Primary_Rep_Trading_Id, pre_land_sales_connect_rep.Transfer_Agent_For_Primary_Trading_Id, pre_land_sales_connect_rep.Client_Defined_Field_1, pre_land_sales_connect_rep.Client_Defined_Field_2, pre_land_sales_connect_rep.Client_Defined_Field_3, pre_land_sales_connect_rep.Client_Defined_Field_4, pre_land_sales_connect_rep.Client_Defined_Field_5, pre_land_sales_connect_rep.Territory_For_Category_1_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_2_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_3_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_4_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_5_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_6_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_7_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_8_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_9_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_10_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_11_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_12_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_13_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_14_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_15_Is_Locked, pre_land_sales_connect_rep.Winning_Firm_Id, pre_land_sales_connect_rep.Winning_Office_Id, pre_land_sales_connect_rep.Winning_Contact_Id, pre_land_sales_connect_rep.Secondary_Firm_Id, pre_land_sales_connect_rep.Secondary_Office_Id, pre_land_sales_connect_rep.Tertiary_Firm_Id, pre_land_sales_connect_rep.Tertiary_Office_Id, pre_land_sales_connect_rep.Website_Url, pre_land_sales_connect_rep.Producing_Rep_Flag, pre_land_sales_connect_rep.Record_Type, pre_land_sales_connect_rep.Default_Role, pre_land_sales_connect_rep.Group_Name, pre_land_sales_connect_rep.Rep_Second_Title 
    FROM
    pre_land_sales_connect_rep , PRE_LAND_SALES_CONNECT_FIRM 
    where pre_land_sales_connect_rep.Rep_Firm_Id=PRE_LAND_SALES_CONNECT_FIRM.Firm_Id and  pre_land_sales_connect_rep.REP_PARTNERSHIP_INDICATOR = 'N' 
    and UPPER(PRE_LAND_SALES_CONNECT_FIRM.Channel_Code) IN ('RIA', 'TRUST')
    and UPPER(pre_land_sales_connect_rep.REP_STATUS_CODE) IN ('ACTIVE', 'INACTIVE')
    and UPPER(pre_land_sales_connect_rep.REP_TYPE) <> 'HOUSE' 
    and UPPER(pre_land_sales_connect_rep.REP_TYPE) <> 'DEFAULT REP'
    AND UPPER(pre_land_sales_connect_rep.REP_TYPE)<> 'PARTNERSHIP'"""

    SQ_pre_land_sales_connect_rep = spark.read.format("jdbc").options(url=jdbc_url_source, driver="com.microsoft.sqlserver.jdbc.SQLServerDriver", query=query).load().cache()

    print("Source Count For Pre_land_sfdc_org_office_role : ",SQ_pre_land_sales_connect_rep.count())

    query=f"""SELECT pre_land_sales_connect_rep.Contact_Id, pre_land_sales_connect_rep.Rep_First_Name, pre_land_sales_connect_rep.Rep_Middle_Name, pre_land_sales_connect_rep.Rep_Last_Name, pre_land_sales_connect_rep.Rep_Prefix, pre_land_sales_connect_rep.Rep_Suffix, pre_land_sales_connect_rep.Rep_Partnership_Indicator, pre_land_sales_connect_rep.Rep_Crd_Number, pre_land_sales_connect_rep.Sc_Rep_Action_Code, pre_land_sales_connect_rep.Rep_Market_Timer_Indicator, pre_land_sales_connect_rep.Rep_Ud_Maintained_Code, pre_land_sales_connect_rep.Sc_Rep_Activity_Code, pre_land_sales_connect_rep.Rep_Member_Flag, pre_land_sales_connect_rep.Rep_Language_Id, pre_land_sales_connect_rep.Rep_Time_Zone_Id, pre_land_sales_connect_rep.Rep_Title, pre_land_sales_connect_rep.Rep_Nickname, pre_land_sales_connect_rep.External_Rep_Identifier, pre_land_sales_connect_rep.Rep_Office_Id, pre_land_sales_connect_rep.Rep_Firm_Id, pre_land_sales_connect_rep.Rep_Status_Code, pre_land_sales_connect_rep.Rep_Channel_Code, pre_land_sales_connect_rep.Rep_Sub_Channel_Code, pre_land_sales_connect_rep.First_Trade_Date_Rep, pre_land_sales_connect_rep.Last_Trade_Date_Rep, pre_land_sales_connect_rep.Last_Timer_Trade_Date_Rep, pre_land_sales_connect_rep.Rep_Channel_Locked_Code, pre_land_sales_connect_rep.Rep_Sub_Channel_Locked_Code, pre_land_sales_connect_rep.Work_Address_Line_1, pre_land_sales_connect_rep.Work_Address_Line_2, pre_land_sales_connect_rep.Work_Address_Line_3, pre_land_sales_connect_rep.Work_Address_Line_4, pre_land_sales_connect_rep.Work_City, pre_land_sales_connect_rep.Work_State_Or_Province, pre_land_sales_connect_rep.Work_Postal_Code_1, pre_land_sales_connect_rep.Work_Postal_Code_2, pre_land_sales_connect_rep.Work_Country_Code, pre_land_sales_connect_rep.Work_Address_Locked_Code, pre_land_sales_connect_rep.Home_Address_Line_1, pre_land_sales_connect_rep.Home_Address_Line_2, pre_land_sales_connect_rep.Home_Address_Line_3, pre_land_sales_connect_rep.Home_Address_Line_4, pre_land_sales_connect_rep.Home_City, pre_land_sales_connect_rep.Home_State_Or_Province, pre_land_sales_connect_rep.Home_Postal_Code_1, pre_land_sales_connect_rep.Home_Postal_Code_2, pre_land_sales_connect_rep.Home_Country_Code, pre_land_sales_connect_rep.Rep_Business_Phone_Number, pre_land_sales_connect_rep.Rep_Business_Phone_Extension, pre_land_sales_connect_rep.Rep_Home_Phone_Number, pre_land_sales_connect_rep.Rep_Fax_Number_1, pre_land_sales_connect_rep.Rep_Fax_Number_2, pre_land_sales_connect_rep.Rep_Mobile_Phone_Number, pre_land_sales_connect_rep.Rep_Wireless_Carrier_Id, pre_land_sales_connect_rep.Rep_Assistant_Name, pre_land_sales_connect_rep.Rep_Assistant_Phone_Number, pre_land_sales_connect_rep.Rep_Type, pre_land_sales_connect_rep.Rep_Email_Address, pre_land_sales_connect_rep.Rep_Email_Address_Continuation, pre_land_sales_connect_rep.Territory_For_Category_1, pre_land_sales_connect_rep.Territory_For_Category_2, pre_land_sales_connect_rep.Territory_For_Category_3, pre_land_sales_connect_rep.Territory_For_Category_4, pre_land_sales_connect_rep.Territory_For_Category_5, pre_land_sales_connect_rep.Territory_For_Category_6, pre_land_sales_connect_rep.Territory_For_Category_7, pre_land_sales_connect_rep.Territory_For_Category_8, pre_land_sales_connect_rep.Territory_For_Category_9, pre_land_sales_connect_rep.Territory_For_Category_10, pre_land_sales_connect_rep.Territory_For_Category_11, pre_land_sales_connect_rep.Territory_For_Category_12, pre_land_sales_connect_rep.Territory_For_Category_13, pre_land_sales_connect_rep.Territory_For_Category_14, pre_land_sales_connect_rep.Territory_For_Category_15, pre_land_sales_connect_rep.Rep_Unique_Id_For_First_Partnership_Member, pre_land_sales_connect_rep.Percentage_Allocated_To_First_Member, pre_land_sales_connect_rep.Rep_Unique_Id_For_Second_Partnership_Member, pre_land_sales_connect_rep.Percentage_Allocated_To_Second_Member, pre_land_sales_connect_rep.Rep_Unique_Id_For_Third_Partnership_Member, pre_land_sales_connect_rep.Percentage_Allocated_To_Third_Member, pre_land_sales_connect_rep.Rep_Unique_Id_For_Fourth_Partnership_Member, pre_land_sales_connect_rep.Percentage_Allocated_To_Fourth_Member, pre_land_sales_connect_rep.Rep_Unique_Id_For_Fifth_Partnership_Member, pre_land_sales_connect_rep.Percentage_Allocated_To_Fifth_Member, pre_land_sales_connect_rep.Rep_Unique_Id_For_Sixth_Partnership_Member, pre_land_sales_connect_rep.Percentage_Allocated_To_Sixth_Member, pre_land_sales_connect_rep.Rep_Unique_Id_For_Seventh_Partnership_Member, pre_land_sales_connect_rep.Percentage_Allocated_To_Seventh_Member, pre_land_sales_connect_rep.Rep_Entity_Date_Time_Update, pre_land_sales_connect_rep.Office_Type, pre_land_sales_connect_rep.Rep_Primary_Firm_Trading_Id, pre_land_sales_connect_rep.Rep_Primary_Office_Trading_Id, pre_land_sales_connect_rep.Rep_Primary_Rep_Trading_Id, pre_land_sales_connect_rep.Transfer_Agent_For_Primary_Trading_Id, pre_land_sales_connect_rep.Client_Defined_Field_1, pre_land_sales_connect_rep.Client_Defined_Field_2, pre_land_sales_connect_rep.Client_Defined_Field_3, pre_land_sales_connect_rep.Client_Defined_Field_4, pre_land_sales_connect_rep.Client_Defined_Field_5, pre_land_sales_connect_rep.Territory_For_Category_1_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_2_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_3_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_4_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_5_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_6_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_7_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_8_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_9_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_10_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_11_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_12_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_13_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_14_Is_Locked, pre_land_sales_connect_rep.Territory_For_Category_15_Is_Locked, pre_land_sales_connect_rep.Winning_Firm_Id, pre_land_sales_connect_rep.Winning_Office_Id, pre_land_sales_connect_rep.Winning_Contact_Id, pre_land_sales_connect_rep.Secondary_Firm_Id, pre_land_sales_connect_rep.Secondary_Office_Id, pre_land_sales_connect_rep.Tertiary_Firm_Id, pre_land_sales_connect_rep.Tertiary_Office_Id, pre_land_sales_connect_rep.Website_Url, pre_land_sales_connect_rep.Producing_Rep_Flag, pre_land_sales_connect_rep.Record_Type, pre_land_sales_connect_rep.Default_Role, pre_land_sales_connect_rep.Group_Name, pre_land_sales_connect_rep.Rep_Second_Title 
    FROM
    pre_land_sales_connect_rep , PRE_LAND_SALES_CONNECT_FIRM 
    where pre_land_sales_connect_rep.Rep_Firm_Id=PRE_LAND_SALES_CONNECT_FIRM.Firm_Id and  pre_land_sales_connect_rep.REP_PARTNERSHIP_INDICATOR = 'N' 
    and UPPER(PRE_LAND_SALES_CONNECT_FIRM.Channel_Code) IN ('RIA', 'TRUST')
    and UPPER(pre_land_sales_connect_rep.REP_STATUS_CODE) IN ('ACTIVE', 'INACTIVE')
    and UPPER(pre_land_sales_connect_rep.REP_TYPE) <> 'HOUSE' 
    and UPPER(pre_land_sales_connect_rep.REP_TYPE) <> 'DEFAULT REP'
    AND UPPER(pre_land_sales_connect_rep.REP_TYPE)<> 'PARTNERSHIP'"""

    #SQ_pre_land_sales_connect_rep_bd = spark.read.format("jdbc").options(url=jdbc_url_source, driver="com.microsoft.sqlserver.jdbc.SQLServerDriver", query=query).load().cache()
    SQ_pre_land_sales_connect_rep_bd = SQ_pre_land_sales_connect_rep
    print("Source Count For Pre_land_sfdc_org_office_role_bd : ",SQ_pre_land_sales_connect_rep_bd.count())

    # Reading Data From Lookup Source
    query=f"""SELECT LTRIM(RTRIM(std_lkup_id)) as std_lkup_id
    ,LTRIM(RTRIM(src_sys_nm)) as src_sys_nm
    ,LTRIM(RTRIM(src_val)) as src_val
    ,LTRIM(RTRIM(attrib_nm)) as attrib_nm 
    FROM lkup_transformation_map where src_sys_nm in ('SC')"""

    lkup_transformation_map = spark.read.format("jdbc").options(url=jdbc_url_lkp, driver="com.microsoft.sqlserver.jdbc.SQLServerDriver", query=query).load().cache()

    lkup_transformation_map_lkpin=lkup_transformation_map.groupBy("src_val","attrib_nm").agg(first("std_lkup_id").alias("std_lkup_id")).cache()

    # Expression Transformation - exp_data_prep_bd

    exp_data_prep_bd = SQ_pre_land_sales_connect_rep_bd.select(col("Rep_Assistant_Name"),col("Rep_Assistant_Phone_Number"),col("Rep_Type"),col("Rep_Email_Address"),col("Rep_Email_Address_Continuation"),col("Territory_For_Category_1"),col("Last_Timer_Trade_Date_Rep"),col("Rep_Channel_Locked_Code"),col("Territory_For_Category_10_Is_Locked"),col("Rep_Sub_Channel_Code"),col("First_Trade_Date_Rep"),col("Contact_Id"),col("Client_Defined_Field_1"),col("Territory_For_Category_4"),col("Territory_For_Category_6"),col("Territory_For_Category_7"),col("Territory_For_Category_8"),col("Territory_For_Category_9"),col("Client_Defined_Field_2"),col("Rep_Suffix"),col("Territory_For_Category_10"),col("Territory_For_Category_11"),col("Territory_For_Category_12"),col("Territory_For_Category_13"),col("Rep_Partnership_Indicator"),col("Rep_Crd_Number"),col("Territory_For_Category_11_Is_Locked"),col("Territory_For_Category_12_Is_Locked"),col("Territory_For_Category_13_Is_Locked"),col("Client_Defined_Field_3"),col("Client_Defined_Field_4"),col("Client_Defined_Field_5"),col("Rep_Sub_Channel_Locked_Code"),col("Work_Address_Line_1"),col("Work_Address_Line_2"),col("Work_Address_Line_3"),col("Rep_Language_Id"),col("Rep_Time_Zone_Id"),col("Rep_Title"),col("Rep_Nickname"),col("External_Rep_Identifier"),col("Rep_Office_Id"),col("Rep_Firm_Id"),col("Rep_Status_Code"),col("Rep_Unique_Id_For_Third_Partnership_Member"),col("Percentage_Allocated_To_Third_Member"),col("Rep_Unique_Id_For_Fourth_Partnership_Member"),col("Percentage_Allocated_To_Fourth_Member"),col("Rep_Unique_Id_For_Fifth_Partnership_Member"),col("Percentage_Allocated_To_Fifth_Member"),col("Rep_Unique_Id_For_Sixth_Partnership_Member"),col("Percentage_Allocated_To_Sixth_Member"),col("Rep_Unique_Id_For_Seventh_Partnership_Member"),col("Percentage_Allocated_To_Seventh_Member"),col("Rep_Entity_Date_Time_Update"),col("Office_Type"),col("Rep_Primary_Firm_Trading_Id"),col("Rep_Primary_Office_Trading_Id"),col("Rep_Primary_Rep_Trading_Id"),col("Transfer_Agent_For_Primary_Trading_Id"),col("Rep_Channel_Code"),col("Work_Address_Line_4"),col("Work_City"),col("Work_State_Or_Province"),col("Work_Postal_Code_1"),col("Work_Postal_Code_2"),col("Work_Country_Code"),col("Work_Address_Locked_Code"),col("Home_Address_Line_1"),col("Home_Address_Line_2"),col("Home_Address_Line_3"),col("Home_Address_Line_4"),col("Territory_For_Category_1_Is_Locked"),col("Territory_For_Category_2_Is_Locked"),col("Territory_For_Category_3_Is_Locked"),col("Territory_For_Category_4_Is_Locked"),col("Territory_For_Category_5_Is_Locked"),col("Territory_For_Category_6_Is_Locked"),col("Territory_For_Category_7_Is_Locked"),col("Territory_For_Category_14_Is_Locked"),col("Territory_For_Category_15_Is_Locked"),col("Winning_Firm_Id"),col("Winning_Office_Id"),col("Winning_Contact_Id"),col("Secondary_Firm_Id"),col("Secondary_Office_Id"),col("Tertiary_Firm_Id"),col("Tertiary_Office_Id"),col("Website_Url"),col("Home_City"),col("Producing_Rep_Flag"),col("Record_Type"),col("Default_Role"),col("Territory_For_Category_9_Is_Locked"),col("Group_Name"),col("Rep_Second_Title"),col("Territory_For_Category_8_Is_Locked"),col("Rep_First_Name"),col("Rep_Middle_Name"),col("Rep_Last_Name"),col("Rep_Prefix"),col("Territory_For_Category_5"),col("Territory_For_Category_2"),col("Territory_For_Category_3"),col("Territory_For_Category_14"),col("Territory_For_Category_15"),col("Rep_Unique_Id_For_First_Partnership_Member"),col("Percentage_Allocated_To_First_Member"),col("Rep_Unique_Id_For_Second_Partnership_Member"),col("Percentage_Allocated_To_Second_Member"),col("Sc_Rep_Action_Code"),col("Rep_Market_Timer_Indicator"),col("Rep_Ud_Maintained_Code"),col("Sc_Rep_Activity_Code"),col("Rep_Member_Flag"),col("Last_Trade_Date_Rep"),col("Home_Country_Code"),col("Home_State_Or_Province"),col("Home_Postal_Code_1"),col("Home_Postal_Code_2"),col("Rep_Business_Phone_Number"),col("Rep_Business_Phone_Extension"),col("Rep_Home_Phone_Number"),col("Rep_Fax_Number_1"),col("Rep_Fax_Number_2"),col("Rep_Mobile_Phone_Number"),col("Rep_Wireless_Carrier_Id"))

    exp_data_prep_bd=exp_data_prep_bd.withColumn("SOURCE_PARTY_ID", col("Contact_Id"))

    exp_data_prep_bd=exp_data_prep_bd.withColumn("src_val_in",lit("Person"))\
    .withColumn("attrib_nm_in",lit("PARTY_TYPE_ID"))

    exp_data_prep_bd = exp_data_prep_bd.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == exp_data_prep_bd['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == exp_data_prep_bd['attrib_nm_in']),how='left').select(exp_data_prep_bd["*"],lkup_transformation_map_lkpin["std_lkup_id"].alias("V_PARTY_TYPE_ID"))

    exp_data_prep_bd=exp_data_prep_bd.withColumn("PARTY_TYPE_ID",when(col("V_PARTY_TYPE_ID").isNotNull(),col("V_PARTY_TYPE_ID")).otherwise(lit('9999')))\
    .withColumn("V_SOURCE_SYSTEM",lit("SC"))\
    .withColumn("SOURCE_SYSTEM",col("V_SOURCE_SYSTEM"))\
    .withColumn("V_ORGANIZATION_STATUS_NAME",when(col("V_SOURCE_SYSTEM")=="SC",ltrim(rtrim(col("Rep_Status_Code")))))

    exp_data_prep_bd=exp_data_prep_bd.withColumn("src_val_in",col("V_ORGANIZATION_STATUS_NAME"))\
    .withColumn("attrib_nm_in",lit("PARTY_STATUS_ID"))

    exp_data_prep_bd = exp_data_prep_bd.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == exp_data_prep_bd['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == exp_data_prep_bd['attrib_nm_in']),how='left').select(exp_data_prep_bd["*"],lkup_transformation_map_lkpin["std_lkup_id"].alias("V_PARTY_STATUS_ID"))

    exp_data_prep_bd=exp_data_prep_bd.withColumn("PARTY_STATUS_ID",when(col("V_PARTY_STATUS_ID").isNotNull(),col("V_PARTY_STATUS_ID"))\
    .when(((col("V_PARTY_STATUS_ID").isNull()) & (col("V_ORGANIZATION_STATUS_NAME").isNull())),lit(None)).otherwise(lit('9999')))\
    .withColumn("PARTY_INACTIVATION_DATE",lit(None).cast("Timestamp"))\
    .withColumn("PARTY_INCTVTN_RSN_TYPE_ID",lit(None).cast("bigint"))\
    .withColumn("PERSON_FIRST_NAME",ltrim(rtrim(col("Rep_First_Name"))))\
    .withColumn("PERSON_MIDDLE_NAME",ltrim(rtrim(col("Rep_Middle_Name"))))\
    .withColumn("PERSON_LAST_NAME",ltrim(rtrim(col("Rep_Last_Name"))))

    exp_data_prep_bd=exp_data_prep_bd.withColumn("src_val_in",lit("Mr."))\
    .withColumn("attrib_nm_in",lit("PERSON_HONORIFIC_ID"))
    

    exp_data_prep_bd = exp_data_prep_bd.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == exp_data_prep_bd['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == exp_data_prep_bd['attrib_nm_in']),how='left').select(exp_data_prep_bd["*"],lkup_transformation_map_lkpin["std_lkup_id"].alias("V_PERSON_HONORIFIC_ID1"))

    exp_data_prep_bd=exp_data_prep_bd.withColumn("src_val_in",lit("Ms."))\
    .withColumn("attrib_nm_in",lit("PERSON_HONORIFIC_ID"))

    exp_data_prep_bd = exp_data_prep_bd.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == exp_data_prep_bd['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == exp_data_prep_bd['attrib_nm_in']),how='left').select(exp_data_prep_bd["*"],lkup_transformation_map_lkpin["std_lkup_id"].alias("V_PERSON_HONORIFIC_ID2"))
    
    exp_data_prep_bd=exp_data_prep_bd.withColumn("PERSON_HONORIFIC_ID",when(col("Rep_Prefix").isNull(),lit(None)).when(((upper(ltrim(rtrim(col("Rep_Prefix"))))==lit('MR.')) | (upper(ltrim(rtrim(col("Rep_Prefix"))))==lit('MR'))),col("V_PERSON_HONORIFIC_ID1")).when(((upper(ltrim(rtrim(col("Rep_Prefix"))))==lit('MS')) | (upper(ltrim(rtrim(col("Rep_Prefix"))))==lit('MS.')) | (upper(ltrim(rtrim(col("Rep_Prefix"))))==lit('MRS.')) | (upper(ltrim(rtrim(col("Rep_Prefix"))))==lit('MRS'))),col("V_PERSON_HONORIFIC_ID2")).otherwise(lit(None)))
    
    exp_data_prep_bd=exp_data_prep_bd.withColumn("PERSON_NAME_SUFFIX_RAW",when(col("Rep_Suffix").isNull(),lit(None)).when(upper(ltrim(rtrim(col("Rep_Suffix"))))=='JR',lit('Jr.')).when(upper(ltrim(rtrim(col("Rep_Suffix"))))=='SR',lit('Sr.')).otherwise(ltrim(rtrim(col("Rep_Suffix")))))
    
    exp_data_prep_bd=exp_data_prep_bd.withColumn("PERSON_NICKNAME",ltrim(rtrim(col("Rep_Nickname"))))\
    .withColumn("CREATED_DATE",col("Rep_Entity_Date_Time_Update"))\
    .withColumn("CREATED_BY",lit("DST-SALES-CONNECT"))\
    .withColumn("LAST_UPDATED_DATE",col("Rep_Entity_Date_Time_Update"))\
    .withColumn("LAST_UPDATED_BY",lit("DST-SALES-CONNECT"))\
    .withColumn("DELETED_INDICATOR",lit(None).cast("string"))\
    .withColumn("DEFERRED_OWNERSHIP_IND",lit("N"))\
    .withColumn("MAPPING_NAME",lit(PMMappingName))

    
    exp_data_prep_bd = exp_data_prep_bd.withColumn("tmp_Rep_Middle_Name", ltrim(rtrim(col("Rep_Middle_Name"))))
    
    exp_data_prep_bd=exp_data_prep_bd.withColumn("PERSON_MIDDLE_INITIAL_v",when( ( (ltrim(rtrim(col("Rep_Middle_Name")))=='') | (is_spaces_udf(col("tmp_Rep_Middle_Name"))) | (ltrim(rtrim(col("Rep_Middle_Name"))).isNull()) ),lit(None)).otherwise(substring(ltrim(rtrim(col("Rep_Middle_Name"))),1,1)))
    
    exp_data_prep_bd=exp_data_prep_bd.withColumn("PERSON_MIDDLE_INITIAL",col("PERSON_MIDDLE_INITIAL_v"))\
    .withColumn("Exclusion_flag",when((upper(ltrim(rtrim(col("Rep_First_Name")))).rlike('.*HOUSE.*')) | (ltrim(rtrim(col("Rep_First_Name"))).rlike('.*/.*')),lit('Y')).otherwise(lit("N")))

    exp_data_prep_bd=exp_data_prep_bd.withColumn("src_val_in",lit("Fully-Qualified"))\
    .withColumn("attrib_nm_in",lit("PARTY_QUALIFICATION_LEVEL_ID"))

    exp_data_prep_bd = exp_data_prep_bd.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == exp_data_prep_bd['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == exp_data_prep_bd['attrib_nm_in']),how='left').select(exp_data_prep_bd["*"],lkup_transformation_map_lkpin["std_lkup_id"].alias("V_PARTY_QUALIFICATION_LEVEL_ID"))

    exp_data_prep_bd=exp_data_prep_bd.withColumn("O_PARTY_QUALIFICATION_LEVEL_ID",col("V_PARTY_QUALIFICATION_LEVEL_ID"))

    # Router Transformation  - rtr_exclusion_rpt_BD
    rtr_exclusion_rpt_bd_in = exp_data_prep_bd.select(col("MAPPING_NAME"),col("PERSON_MIDDLE_INITIAL"),col("Exclusion_flag"),col("O_PARTY_QUALIFICATION_LEVEL_ID").alias("PARTY_QUALIFICATION_LEVEL_ID"),col("SOURCE_PARTY_ID"),col("PARTY_TYPE_ID"),col("SOURCE_SYSTEM"),col("PARTY_STATUS_ID"),col("PARTY_INACTIVATION_DATE"),col("PARTY_INCTVTN_RSN_TYPE_ID"),col("PERSON_FIRST_NAME"),col("PERSON_MIDDLE_NAME"),col("PERSON_LAST_NAME"),col("PERSON_HONORIFIC_ID"),col("PERSON_NAME_SUFFIX_RAW"),col("PERSON_NICKNAME"),col("CREATED_DATE"),col("CREATED_BY"),col("LAST_UPDATED_DATE"),col("LAST_UPDATED_BY"),col("DELETED_INDICATOR"),col("DEFERRED_OWNERSHIP_IND"))

    true_records_bd = rtr_exclusion_rpt_bd_in.filter(col("Exclusion_flag")==lit('N'))
    true_records_bd = true_records_bd.select(col("SOURCE_PARTY_ID").alias("SOURCE_PARTY_ID1"),col("PARTY_TYPE_ID").alias("PARTY_TYPE_ID1"),col("SOURCE_SYSTEM").alias("SOURCE_SYSTEM1"),col("PARTY_STATUS_ID").alias("PARTY_STATUS_ID1"),col("PARTY_INACTIVATION_DATE").alias("PARTY_INACTIVATION_DATE1"),col("PARTY_INCTVTN_RSN_TYPE_ID").alias("PARTY_INCTVTN_RSN_TYPE_ID1"),col("PERSON_FIRST_NAME").alias("PERSON_FIRST_NAME1"),col("PERSON_MIDDLE_NAME").alias("PERSON_MIDDLE_NAME1"),col("PERSON_LAST_NAME").alias("PERSON_LAST_NAME1"),col("PERSON_HONORIFIC_ID").alias("PERSON_HONORIFIC_ID1"),col("PERSON_NAME_SUFFIX_RAW").alias("PERSON_NAME_SUFFIX_RAW1"),col("PERSON_NICKNAME").alias("PERSON_NICKNAME1"),col("CREATED_DATE").alias("CREATED_DATE1"),col("CREATED_BY").alias("CREATED_BY1"),col("LAST_UPDATED_DATE").alias("LAST_UPDATED_DATE1"),col("LAST_UPDATED_BY").alias("LAST_UPDATED_BY1"),col("DELETED_INDICATOR").alias("DELETED_INDICATOR1"),col("DEFERRED_OWNERSHIP_IND").alias("DEFERRED_OWNERSHIP_IND1"),col("MAPPING_NAME").alias("MAPPING_NAME1"),col("PERSON_MIDDLE_INITIAL").alias("PERSON_MIDDLE_INITIAL1"),col("Exclusion_flag").alias("Exclusion_flag1"),col("PARTY_QUALIFICATION_LEVEL_ID").alias("PARTY_QUALIFICATION_LEVEL_ID1"))

    excluded_records_bd = rtr_exclusion_rpt_bd_in.filter(col("Exclusion_flag")==lit('Y'))
    excluded_records_bd = excluded_records_bd.select(col("SOURCE_PARTY_ID").alias("SOURCE_PARTY_ID3"),col("PARTY_TYPE_ID").alias("PARTY_TYPE_ID3"),col("SOURCE_SYSTEM").alias("SOURCE_SYSTEM3"),col("PARTY_STATUS_ID").alias("PARTY_STATUS_ID3"),col("PARTY_INACTIVATION_DATE").alias("PARTY_INACTIVATION_DATE3"),col("PARTY_INCTVTN_RSN_TYPE_ID").alias("PARTY_INCTVTN_RSN_TYPE_ID3"),col("PERSON_FIRST_NAME").alias("PERSON_FIRST_NAME3"),col("PERSON_MIDDLE_NAME").alias("PERSON_MIDDLE_NAME3"),col("PERSON_LAST_NAME").alias("PERSON_LAST_NAME3"),col("PERSON_HONORIFIC_ID").alias("PERSON_HONORIFIC_ID3"),col("PERSON_NAME_SUFFIX_RAW").alias("PERSON_NAME_SUFFIX_RAW3"),col("PERSON_NICKNAME").alias("PERSON_NICKNAME3"),col("CREATED_DATE").alias("CREATED_DATE3"),col("CREATED_BY").alias("CREATED_BY3"),col("LAST_UPDATED_DATE").alias("LAST_UPDATED_DATE3"),col("LAST_UPDATED_BY").alias("LAST_UPDATED_BY3"),col("DELETED_INDICATOR").alias("DELETED_INDICATOR3"),col("DEFERRED_OWNERSHIP_IND").alias("DEFERRED_OWNERSHIP_IND3"),col("MAPPING_NAME").alias("MAPPING_NAME3"),col("PERSON_MIDDLE_INITIAL").alias("PERSON_MIDDLE_INITIAL3"),col("Exclusion_flag").alias("Exclusion_flag3"),col("PARTY_QUALIFICATION_LEVEL_ID").alias("PARTY_QUALIFICATION_LEVEL_ID3"))


    # Flow 2
    # Expression Transformation - exp_data_prep
    exp_data_prep = SQ_pre_land_sales_connect_rep.select(col("Rep_Assistant_Name"),col("Rep_Assistant_Phone_Number"),col("Rep_Type"),col("Rep_Email_Address"),col("Rep_Email_Address_Continuation"),col("Territory_For_Category_1"),col("Last_Timer_Trade_Date_Rep"),col("Rep_Channel_Locked_Code"),col("Territory_For_Category_10_Is_Locked"),col("Rep_Sub_Channel_Code"),col("First_Trade_Date_Rep"),col("Contact_Id"),col("Client_Defined_Field_1"),col("Territory_For_Category_4"),col("Territory_For_Category_6"),col("Territory_For_Category_7"),col("Territory_For_Category_8"),col("Territory_For_Category_9"),col("Client_Defined_Field_2"),col("Rep_Suffix"),col("Territory_For_Category_10"),col("Territory_For_Category_11"),col("Territory_For_Category_12"),col("Territory_For_Category_13"),col("Rep_Partnership_Indicator"),col("Rep_Crd_Number"),col("Territory_For_Category_11_Is_Locked"),col("Territory_For_Category_12_Is_Locked"),col("Territory_For_Category_13_Is_Locked"),col("Client_Defined_Field_3"),col("Client_Defined_Field_4"),col("Client_Defined_Field_5"),col("Rep_Sub_Channel_Locked_Code"),col("Work_Address_Line_1"),col("Work_Address_Line_2"),col("Work_Address_Line_3"),col("Rep_Language_Id"),col("Rep_Time_Zone_Id"),col("Rep_Title"),col("Rep_Nickname"),col("External_Rep_Identifier"),col("Rep_Office_Id"),col("Rep_Firm_Id"),col("Rep_Status_Code"),col("Rep_Unique_Id_For_Third_Partnership_Member"),col("Percentage_Allocated_To_Third_Member"),col("Rep_Unique_Id_For_Fourth_Partnership_Member"),col("Percentage_Allocated_To_Fourth_Member"),col("Rep_Unique_Id_For_Fifth_Partnership_Member"),col("Percentage_Allocated_To_Fifth_Member"),col("Rep_Unique_Id_For_Sixth_Partnership_Member"),col("Percentage_Allocated_To_Sixth_Member"),col("Rep_Unique_Id_For_Seventh_Partnership_Member"),col("Percentage_Allocated_To_Seventh_Member"),col("Rep_Entity_Date_Time_Update"),col("Office_Type"),col("Rep_Primary_Firm_Trading_Id"),col("Rep_Primary_Office_Trading_Id"),col("Rep_Primary_Rep_Trading_Id"),col("Transfer_Agent_For_Primary_Trading_Id"),col("Rep_Channel_Code"),col("Work_Address_Line_4"),col("Work_City"),col("Work_State_Or_Province"),col("Work_Postal_Code_1"),col("Work_Postal_Code_2"),col("Work_Country_Code"),col("Work_Address_Locked_Code"),col("Home_Address_Line_1"),col("Home_Address_Line_2"),col("Home_Address_Line_3"),col("Home_Address_Line_4"),col("Territory_For_Category_1_Is_Locked"),col("Territory_For_Category_2_Is_Locked"),col("Territory_For_Category_3_Is_Locked"),col("Territory_For_Category_4_Is_Locked"),col("Territory_For_Category_5_Is_Locked"),col("Territory_For_Category_6_Is_Locked"),col("Territory_For_Category_7_Is_Locked"),col("Territory_For_Category_14_Is_Locked"),col("Territory_For_Category_15_Is_Locked"),col("Winning_Firm_Id"),col("Winning_Office_Id"),col("Winning_Contact_Id"),col("Secondary_Firm_Id"),col("Secondary_Office_Id"),col("Tertiary_Firm_Id"),col("Tertiary_Office_Id"),col("Website_Url"),col("Home_City"),col("Producing_Rep_Flag"),col("Record_Type"),col("Default_Role"),col("Territory_For_Category_9_Is_Locked"),col("Group_Name"),col("Rep_Second_Title"),col("Territory_For_Category_8_Is_Locked"),col("Rep_First_Name"),col("Rep_Middle_Name"),col("Rep_Last_Name"),col("Rep_Prefix"),col("Territory_For_Category_5"),col("Territory_For_Category_2"),col("Territory_For_Category_3"),col("Territory_For_Category_14"),col("Territory_For_Category_15"),col("Rep_Unique_Id_For_First_Partnership_Member"),col("Percentage_Allocated_To_First_Member"),col("Rep_Unique_Id_For_Second_Partnership_Member"),col("Percentage_Allocated_To_Second_Member"),col("Sc_Rep_Action_Code"),col("Rep_Market_Timer_Indicator"),col("Rep_Ud_Maintained_Code"),col("Sc_Rep_Activity_Code"),col("Rep_Member_Flag"),col("Last_Trade_Date_Rep"),col("Home_Country_Code"),col("Home_State_Or_Province"),col("Home_Postal_Code_1"),col("Home_Postal_Code_2"),col("Rep_Business_Phone_Number"),col("Rep_Business_Phone_Extension"),col("Rep_Home_Phone_Number"),col("Rep_Fax_Number_1"),col("Rep_Fax_Number_2"),col("Rep_Mobile_Phone_Number"),col("Rep_Wireless_Carrier_Id"))

    exp_data_prep=exp_data_prep.withColumn("SOURCE_PARTY_ID", col("Contact_Id"))

    exp_data_prep=exp_data_prep.withColumn("src_val_in",lit("Person"))\
    .withColumn("attrib_nm_in",lit("PARTY_TYPE_ID"))

    exp_data_prep = exp_data_prep.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == exp_data_prep['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == exp_data_prep['attrib_nm_in']),how='left').select(exp_data_prep["*"],lkup_transformation_map_lkpin["std_lkup_id"].alias("V_PARTY_TYPE_ID"))

    exp_data_prep=exp_data_prep.withColumn("PARTY_TYPE_ID",when(col("V_PARTY_TYPE_ID").isNotNull(),col("V_PARTY_TYPE_ID")).otherwise(lit('9999')))\
    .withColumn("V_SOURCE_SYSTEM",lit("SC"))\
    .withColumn("SOURCE_SYSTEM",col("V_SOURCE_SYSTEM"))\
    .withColumn("V_ORGANIZATION_STATUS_NAME",when(col("V_SOURCE_SYSTEM")=="SC",ltrim(rtrim(col("Rep_Status_Code")))))

    exp_data_prep=exp_data_prep.withColumn("src_val_in",col("V_ORGANIZATION_STATUS_NAME"))\
    .withColumn("attrib_nm_in",lit("PARTY_STATUS_ID"))

    exp_data_prep = exp_data_prep.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == exp_data_prep['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == exp_data_prep['attrib_nm_in']),how='left').select(exp_data_prep["*"],lkup_transformation_map_lkpin["std_lkup_id"].alias("V_PARTY_STATUS_ID"))

    exp_data_prep=exp_data_prep.withColumn("PARTY_STATUS_ID",when(col("V_PARTY_STATUS_ID").isNotNull(),col("V_PARTY_STATUS_ID"))\
    .when(((col("V_PARTY_STATUS_ID").isNull()) & (col("V_ORGANIZATION_STATUS_NAME").isNull())),lit(None)).otherwise(lit('9999')))\
    .withColumn("PARTY_INACTIVATION_DATE",lit(None).cast("Timestamp"))\
    .withColumn("PARTY_INCTVTN_RSN_TYPE_ID",lit(None).cast("bigint"))\
    .withColumn("PERSON_FIRST_NAME",ltrim(rtrim(col("Rep_First_Name"))))\
    .withColumn("PERSON_MIDDLE_NAME",ltrim(rtrim(col("Rep_Middle_Name"))))\
    .withColumn("PERSON_LAST_NAME",ltrim(rtrim(col("Rep_Last_Name"))))

    exp_data_prep=exp_data_prep.withColumn("src_val_in",lit("Mr."))\
    .withColumn("attrib_nm_in",lit("PERSON_HONORIFIC_ID"))

    exp_data_prep = exp_data_prep.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == exp_data_prep['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == exp_data_prep['attrib_nm_in']),how='left').select(exp_data_prep["*"],lkup_transformation_map_lkpin["std_lkup_id"].alias("V_PERSON_HONORIFIC_ID1"))

    exp_data_prep=exp_data_prep.withColumn("src_val_in",lit("Ms."))\
    .withColumn("attrib_nm_in",lit("PERSON_HONORIFIC_ID"))

    exp_data_prep = exp_data_prep.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == exp_data_prep['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == exp_data_prep['attrib_nm_in']),how='left').select(exp_data_prep["*"],lkup_transformation_map_lkpin["std_lkup_id"].alias("V_PERSON_HONORIFIC_ID2"))

    exp_data_prep=exp_data_prep.withColumn("PERSON_HONORIFIC_ID",when(col("Rep_Prefix").isNull(),lit(None)).when(((upper(ltrim(rtrim(col("Rep_Prefix"))))==lit('MR.')) | (upper(ltrim(rtrim(col("Rep_Prefix"))))==lit('MR'))),col("V_PERSON_HONORIFIC_ID1"))\
    .when(((upper(ltrim(rtrim(col("Rep_Prefix"))))=='MS') | (upper(ltrim(rtrim(col("Rep_Prefix"))))=='MS.') | (upper(ltrim(rtrim(col("Rep_Prefix"))))=='MRS.') | (upper(ltrim(rtrim(col("Rep_Prefix"))))=='MRS')),col("V_PERSON_HONORIFIC_ID2")).otherwise(lit(None)))\
    .withColumn("PERSON_NAME_SUFFIX_RAW",when(col("Rep_Suffix").isNull(),lit(None))\
    .when(upper(ltrim(rtrim(col("Rep_Suffix"))))=='JR',lit('Jr.'))\
    .when(upper(ltrim(rtrim(col("Rep_Suffix"))))=='SR',lit('Sr.')).otherwise(ltrim(rtrim(col("Rep_Suffix")))))
    

    exp_data_prep=exp_data_prep.withColumn("PERSON_NICKNAME",ltrim(rtrim(col("Rep_Nickname"))))\
    .withColumn("CREATED_DATE",col("Rep_Entity_Date_Time_Update"))\
    .withColumn("CREATED_BY",lit("DST-SALES-CONNECT"))\
    .withColumn("LAST_UPDATED_DATE",col("Rep_Entity_Date_Time_Update"))\
    .withColumn("LAST_UPDATED_BY",lit("DST-SALES-CONNECT"))\
    .withColumn("DELETED_INDICATOR",lit(None).cast("string"))\
    .withColumn("DEFERRED_OWNERSHIP_IND",lit("N"))\
    .withColumn("MAPPING_NAME",lit(PMMappingName))\
    .withColumn("PERSON_MIDDLE_INITIAL_v",when( ( (ltrim(rtrim(col("Rep_Middle_Name")))=='') | (is_spaces_udf(ltrim(rtrim(col("Rep_Middle_Name"))))) | (ltrim(rtrim(col("Rep_Middle_Name"))).isNull())),lit(None)).otherwise(substring(ltrim(rtrim(col("Rep_Middle_Name"))),1,1)))\
    .withColumn("PERSON_MIDDLE_INITIAL",col("PERSON_MIDDLE_INITIAL_v"))\
    .withColumn("Exclusion_flag",when((upper(ltrim(rtrim(col("Rep_First_Name")))).rlike('.*HOUSE.*')) | (ltrim(rtrim(col("Rep_First_Name"))).rlike('.*/.*')),lit('Y')).otherwise(lit("N")))

    exp_data_prep=exp_data_prep.withColumn("src_val_in",lit("Fully-Qualified"))\
    .withColumn("attrib_nm_in",lit("PARTY_QUALIFICATION_LEVEL_ID"))

    exp_data_prep = exp_data_prep.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == exp_data_prep['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == exp_data_prep['attrib_nm_in']),how='left').select(exp_data_prep["*"],lkup_transformation_map_lkpin["std_lkup_id"].alias("V_PARTY_QUALIFICATION_LEVEL_ID"))

    exp_data_prep=exp_data_prep.withColumn("O_PARTY_QUALIFICATION_LEVEL_ID",col("V_PARTY_QUALIFICATION_LEVEL_ID"))
    
    # Router Transformation  - rtr_exclusion_rpt

    rtr_exclusion_rpt_in = exp_data_prep.select(col("MAPPING_NAME"),col("PERSON_MIDDLE_INITIAL"),col("Exclusion_flag"),col("O_PARTY_QUALIFICATION_LEVEL_ID").alias("PARTY_QUALIFICATION_LEVEL_ID"),col("SOURCE_PARTY_ID"),col("PARTY_TYPE_ID"),col("SOURCE_SYSTEM"),col("PARTY_STATUS_ID"),col("PARTY_INACTIVATION_DATE"),col("PARTY_INCTVTN_RSN_TYPE_ID"),col("PERSON_FIRST_NAME"),col("PERSON_MIDDLE_NAME"),col("PERSON_LAST_NAME"),col("PERSON_HONORIFIC_ID"),col("PERSON_NAME_SUFFIX_RAW"),col("PERSON_NICKNAME"),col("CREATED_DATE"),col("CREATED_BY"),col("LAST_UPDATED_DATE"),col("LAST_UPDATED_BY"),col("DELETED_INDICATOR"),col("DEFERRED_OWNERSHIP_IND")).cache()

    true_records = rtr_exclusion_rpt_in.filter(col("Exclusion_flag")==lit('N'))
    true_records = true_records.select(col("SOURCE_PARTY_ID").alias("SOURCE_PARTY_ID1"),col("PARTY_TYPE_ID").alias("PARTY_TYPE_ID1"),col("SOURCE_SYSTEM").alias("SOURCE_SYSTEM1"),col("PARTY_STATUS_ID").alias("PARTY_STATUS_ID1"),col("PARTY_INACTIVATION_DATE").alias("PARTY_INACTIVATION_DATE1"),col("PARTY_INCTVTN_RSN_TYPE_ID").alias("PARTY_INCTVTN_RSN_TYPE_ID1"),col("PERSON_FIRST_NAME").alias("PERSON_FIRST_NAME1"),col("PERSON_MIDDLE_NAME").alias("PERSON_MIDDLE_NAME1"),col("PERSON_LAST_NAME").alias("PERSON_LAST_NAME1"),col("PERSON_HONORIFIC_ID").alias("PERSON_HONORIFIC_ID1"),col("PERSON_NAME_SUFFIX_RAW").alias("PERSON_NAME_SUFFIX_RAW1"),col("PERSON_NICKNAME").alias("PERSON_NICKNAME1"),col("CREATED_DATE").alias("CREATED_DATE1"),col("CREATED_BY").alias("CREATED_BY1"),col("LAST_UPDATED_DATE").alias("LAST_UPDATED_DATE1"),col("LAST_UPDATED_BY").alias("LAST_UPDATED_BY1"),col("DELETED_INDICATOR").alias("DELETED_INDICATOR1"),col("DEFERRED_OWNERSHIP_IND").alias("DEFERRED_OWNERSHIP_IND1"),col("MAPPING_NAME").alias("MAPPING_NAME1"),col("PERSON_MIDDLE_INITIAL").alias("PERSON_MIDDLE_INITIAL1"),col("Exclusion_flag").alias("Exclusion_flag1"),col("PARTY_QUALIFICATION_LEVEL_ID").alias("PARTY_QUALIFICATION_LEVEL_ID1"))

    excluded_records = rtr_exclusion_rpt_in.filter(col("Exclusion_flag")==lit('Y'))
    excluded_records = excluded_records.select(col("SOURCE_PARTY_ID").alias("SOURCE_PARTY_ID3"),col("PARTY_TYPE_ID").alias("PARTY_TYPE_ID3"),col("SOURCE_SYSTEM").alias("SOURCE_SYSTEM3"),col("PARTY_STATUS_ID").alias("PARTY_STATUS_ID3"),col("PARTY_INACTIVATION_DATE").alias("PARTY_INACTIVATION_DATE3"),col("PARTY_INCTVTN_RSN_TYPE_ID").alias("PARTY_INCTVTN_RSN_TYPE_ID3"),col("PERSON_FIRST_NAME").alias("PERSON_FIRST_NAME3"),col("PERSON_MIDDLE_NAME").alias("PERSON_MIDDLE_NAME3"),col("PERSON_LAST_NAME").alias("PERSON_LAST_NAME3"),col("PERSON_HONORIFIC_ID").alias("PERSON_HONORIFIC_ID3"),col("PERSON_NAME_SUFFIX_RAW").alias("PERSON_NAME_SUFFIX_RAW3"),col("PERSON_NICKNAME").alias("PERSON_NICKNAME3"),col("CREATED_DATE").alias("CREATED_DATE3"),col("CREATED_BY").alias("CREATED_BY3"),col("LAST_UPDATED_DATE").alias("LAST_UPDATED_DATE3"),col("LAST_UPDATED_BY").alias("LAST_UPDATED_BY3"),col("DELETED_INDICATOR").alias("DELETED_INDICATOR3"),col("DEFERRED_OWNERSHIP_IND").alias("DEFERRED_OWNERSHIP_IND3"),col("MAPPING_NAME").alias("MAPPING_NAME3"),col("PERSON_MIDDLE_INITIAL").alias("PERSON_MIDDLE_INITIAL3"),col("Exclusion_flag").alias("Exclusion_flag3"),col("PARTY_QUALIFICATION_LEVEL_ID").alias("PARTY_QUALIFICATION_LEVEL_ID3"))
    
    # Target Pre SQL
    query = f"""delete from TODAY_PARTY_XFORM  where MAPPING_NAME='{PMMappingName}'"""
    stmt.executeUpdate(query)
    
    # Column selection for target loading - today_party_xform
    today_party_xform_in = true_records.select(col('PERSON_NAME_SUFFIX_RAW1').alias('PERSON_NAME_SUFFIX_RAW'),col('CREATED_DATE1').alias('created_date'),col('CREATED_BY1').alias('created_by'),col('LAST_UPDATED_DATE1').alias('last_updated_date'),col('LAST_UPDATED_BY1').alias('last_updated_by'),col('DELETED_INDICATOR1').alias('deleted_indicator'),col('DEFERRED_OWNERSHIP_IND1').alias('DEFERRED_OWNERSHIP_IND'),col('MAPPING_NAME1').alias('MAPPING_NAME'),col('PERSON_MIDDLE_INITIAL1').alias('person_middle_initial'),col('PERSON_HONORIFIC_ID1').alias('person_honorific_id'),col('PERSON_NICKNAME1').alias('person_nickname'),col('PARTY_QUALIFICATION_LEVEL_ID1').alias('PARTY_QUALIFICATION_LEVEL_ID'),col('SOURCE_PARTY_ID1').alias('source_party_id'),col('PARTY_TYPE_ID1').alias('party_type_id'),col('SOURCE_SYSTEM1').alias('source_system'),col('PARTY_STATUS_ID1').alias('party_status_id'),col('PARTY_INACTIVATION_DATE1').alias('party_inactivation_date'),col('PARTY_INCTVTN_RSN_TYPE_ID1').alias('party_inctvtn_rsn_type_id'),col('PERSON_FIRST_NAME1').alias('person_first_name'),col('PERSON_MIDDLE_NAME1').alias('person_middle_name'),col('PERSON_LAST_NAME1').alias('person_last_name'))

    # Target Loading - today_party_xform
    print("Target Count - today_party_xform: ",today_party_xform_in.count())
    
    # Use numeric partitioning instead of column-based partitioning
    partitioned_df = today_party_xform_in.repartition(100)  # Using 10 partitions

    # Write data with partitioning
    partitioned_df.repartition(20) \
    .write \
    .format('jdbc') \
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
    .option("url", jdbc_url_target) \
    .option("dbtable", "today_party_xform") \
    .option("user", db_user) \
    .option("password", db_password) \
    .option("batchsize", 10000) \
    .mode('append') \
    .save()
    
    # Column selection for target loading - Rej_records_report
    rej_records_report_in = excluded_records.select(col('SOURCE_SYSTEM3').alias('Source_System'),col('SOURCE_PARTY_ID3').alias('Source_party_id'),col('PERSON_FIRST_NAME3').alias('Prsn_First_Name'),col('PERSON_MIDDLE_NAME3').alias('Prsn_Middle_Name'),col('PERSON_LAST_NAME3').alias('Prsn_Last_Name'))
    
    print("Target Reject Count - rej_records_report: ",rej_records_report_in.count())
    
    # Target Loading - Rej_records_report
    path = "\cdm\Rej_records_report.xls"
    #rej_records_report_in.coalesce(1).write.format("csv").options(header="True", delimiter=",").mode("overwrite").save(path)

    # Column selection for target loading - today_party_xform_bd
    today_party_xform_bd_in = true_records_bd.select(col('PERSON_NAME_SUFFIX_RAW1').alias('PERSON_NAME_SUFFIX_RAW'),col('CREATED_DATE1').alias('created_date'),col('CREATED_BY1').alias('created_by'),col('LAST_UPDATED_DATE1').alias('last_updated_date'),col('LAST_UPDATED_BY1').alias('last_updated_by'),col('DELETED_INDICATOR1').alias('deleted_indicator'),col('DEFERRED_OWNERSHIP_IND1').alias('DEFERRED_OWNERSHIP_IND'),col('MAPPING_NAME1').alias('MAPPING_NAME'),col('PERSON_MIDDLE_INITIAL1').alias('person_middle_initial'),col('PERSON_HONORIFIC_ID1').alias('person_honorific_id'),col('PERSON_NICKNAME1').alias('person_nickname'),col('PARTY_QUALIFICATION_LEVEL_ID1').alias('PARTY_QUALIFICATION_LEVEL_ID'),col('SOURCE_PARTY_ID1').alias('source_party_id'),col('PARTY_TYPE_ID1').alias('party_type_id'),col('SOURCE_SYSTEM1').alias('source_system'),col('PARTY_STATUS_ID1').alias('party_status_id'),col('PARTY_INACTIVATION_DATE1').alias('party_inactivation_date'),col('PARTY_INCTVTN_RSN_TYPE_ID1').alias('party_inctvtn_rsn_type_id'),col('PERSON_FIRST_NAME1').alias('person_first_name'),col('PERSON_MIDDLE_NAME1').alias('person_middle_name'),col('PERSON_LAST_NAME1').alias('person_last_name'))
    
    print("Target Count - today_party_xform_bd: ",today_party_xform_bd_in.count())
    
    # Target Loading - today_party_xform_bd
    # Use numeric partitioning instead of column-based partitioning
    partitioned_df = today_party_xform_bd_in.repartition(100)  # Using 10 partitions

    # Write data with partitioning
    partitioned_df.repartition(20) \
    .write \
    .format('jdbc') \
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
    .option("url", jdbc_url_target) \
    .option("dbtable", "today_party_xform") \
    .option("user", db_user) \
    .option("password", db_password) \
    .option("batchsize", 10000) \
    .mode('append') \
    .save()

    # Column selection for target loading - Rej_records_report_BD
    rej_records_report_bd_in = excluded_records_bd.select(col('SOURCE_SYSTEM3').alias('Source_System'),col('SOURCE_PARTY_ID3').alias('Source_party_id'),col('PERSON_FIRST_NAME3').alias('Prsn_First_Name'),col('PERSON_MIDDLE_NAME3').alias('Prsn_Middle_Name'),col('PERSON_LAST_NAME3').alias('Prsn_Last_Name'))
    
    print("Target Reject Count - rej_records_report_bd: ",rej_records_report_bd_in.count())

    # Target Loading - rej_records_report_bd
    path = "\cdm\Rej_records_report.xls"
    #excluded_records.coalesce(1).write.format("csv").options(header="True", delimiter=",").mode("append").save(path)
    
    print("Executed")
except Exception as Error:
	print(Error)