"""
Error handling utilities for DataSwitch framework.

This module provides standardized error handling and reporting
mechanisms for DataSwitch jobs.
"""

import sys
import traceback
import logging
from typing import Dict, Any, Optional, Callable

logger = logging.getLogger(__name__)

class DataSwitchException(Exception):
    """Custom exception for DataSwitch framework errors."""
    
    def __init__(self, message: str, error_code: Optional[str] = None, 
                details: Optional[Dict[str, Any]] = None):
        """Initialize exception.
        
        Args:
            message: Error message
            error_code: Optional error code
            details: Optional additional details
        """
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        super().__init__(self.message)

class ErrorHandler:
    """Handles errors in DataSwitch jobs."""
    
    def __init__(self, job_name: str, execution_id: Optional[str] = None):
        """Initialize error handler.
        
        Args:
            job_name: Name of the job
            execution_id: Unique ID for this execution
        """
        self.job_name = job_name
        self.execution_id = execution_id
        self.error_count = 0
        self.errors = []
        self.fatal_error = None
    
    def handle_error(self, exception: Exception, stage: Optional[str] = None, 
                    fatal: bool = False) -> None:
        """Handle an error during job execution.
        
        Args:
            exception: The exception that occurred
            stage: Optional stage name where the error occurred
            fatal: Whether this is a fatal error that should stop job execution
        """
        self.error_count += 1
        
        # Get exception details
        error_type = type(exception).__name__
        error_message = str(exception)
        stack_trace = traceback.format_exc()
        
        # Create error record
        error = {
            'error_type': error_type,
            'message': error_message,
            'stack_trace': stack_trace,
            'stage': stage,
            'fatal': fatal
        }
        
        self.errors.append(error)
        
        # Log the error
        if fatal:
            logger.critical(
                f"Fatal error in job {self.job_name} "
                f"{'in stage ' + stage if stage else ''}: "
                f"{error_type}: {error_message}"
            )
            self.fatal_error = error
        else:
            logger.error(
                f"Error in job {self.job_name} "
                f"{'in stage ' + stage if stage else ''}: "
                f"{error_type}: {error_message}"
            )
        
        # Log stack trace at debug level
        logger.debug(f"Stack trace:\n{stack_trace}")
    
    def has_fatal_error(self) -> bool:
        """Check if a fatal error has occurred.
        
        Returns:
            True if a fatal error has occurred, False otherwise
        """
        return self.fatal_error is not None
    
    def get_error_report(self) -> Dict[str, Any]:
        """Get a report of all errors.
        
        Returns:
            Dictionary with error report
        """
        return {
            'job_name': self.job_name,
            'execution_id': self.execution_id,
            'error_count': self.error_count,
            'has_fatal_error': self.has_fatal_error(),
            'errors': self.errors
        }
    
    @staticmethod
    def with_error_handling(func: Callable) -> Callable:
        """Decorator to add error handling to a function.
        
        Args:
            func: Function to decorate
        
        Returns:
            Decorated function
        """
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                # Get the error handler from the first argument (self)
                if args and hasattr(args[0], 'error_handler'):
                    error_handler = args[0].error_handler
                    # Try to get current stage
                    stage = getattr(args[0], 'current_stage', None)
                    error_handler.handle_error(e, stage=stage, fatal=True)
                else:
                    # If there's no error handler, just log the error
                    logger.exception(f"Error in {func.__name__}: {str(e)}")
                
                # Re-raise to allow for proper job termination
                raise
        
        return wrapper

def try_catch(error_handler: ErrorHandler, stage: Optional[str] = None, 
             fatal: bool = False) -> Callable:
    """Decorator to add try-catch with specified error handling.
    
    Args:
        error_handler: Error handler instance
        stage: Optional stage name
        fatal: Whether errors should be treated as fatal
    
    Returns:
        Decorator function
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                error_handler.handle_error(e, stage=stage, fatal=fatal)
                if fatal:
                    raise
                return None
        return wrapper
    return decorator
