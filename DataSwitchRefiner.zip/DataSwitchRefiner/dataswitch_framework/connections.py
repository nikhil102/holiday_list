"""
Connection utilities for DataSwitch framework.

This module provides functionality for creating and managing database connections,
especially for JDBC connections used with PySpark.
"""

import os
import logging
from typing import Dict, Any, Optional
import jaydebeapi
from pyspark.sql import SparkSession

from dataswitch_framework.config import config_manager
from dataswitch_framework.error_handling import DataSwitchException

logger = logging.getLogger(__name__)

class ConnectionManager:
    """Manages database connections for DataSwitch jobs."""
    
    def __init__(self, spark: SparkSession):
        """Initialize connection manager.
        
        Args:
            spark: Active SparkSession
        """
        self.spark = spark
        self.connections = {}
        self.default_jdbc_driver = config_manager.get('jdbc.default_driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver')
        self.jdbc_driver_path = config_manager.get(
            'jdbc.driver_path', 
            os.environ.get('JDBC_DRIVER_PATH', 'C:/Drivers/mssql-jdbc-12.4.2.jre11.jar')
        )
        self.authentication_dll_path = config_manager.get(
            'jdbc.auth_dll_path',
            os.environ.get('JDBC_AUTH_DLL_PATH', 'C:/Drivers')
        )
    
    def get_jdbc_url(self, conn_config: Dict[str, Any]) -> str:
        """Build JDBC URL from connection configuration.
        
        Args:
            conn_config: Connection configuration dictionary
        
        Returns:
            JDBC URL string
        """
        db_type = conn_config.get('type', 'sqlserver')
        server = conn_config.get('server', conn_config.get('host', 'localhost'))
        database = conn_config.get('database', '')
        
        # Support for different database types
        if db_type.lower() == 'sqlserver':
            trust_server = conn_config.get('trust_server_certificate', 'true')
            encrypt = conn_config.get('encrypt', 'false')
            port = conn_config.get('port', '')
            
            # Handle different server name formats (with or without instance)
            if '\\' in server:
                jdbc_url = f"jdbc:sqlserver://{server.split('\\')[0]}"
                if port:
                    jdbc_url += f":{port}"
                jdbc_url += f"\\{server.split('\\')[1]};databaseName={database}"
            else:
                jdbc_url = f"jdbc:sqlserver://{server}"
                if port:
                    jdbc_url += f":{port}"
                jdbc_url += f";databaseName={database}"
            
            # Add authentication and encryption settings
            user = conn_config.get('user', '')
            password = conn_config.get('password', '')
            if user and password:
                jdbc_url += f";user={user};password={password}"
            
            jdbc_url += f";trustServerCertificate={trust_server};encrypt={encrypt}"
            
            return jdbc_url
        else:
            raise DataSwitchException(f"Unsupported database type: {db_type}")
    
    def create_jdbc_connection(self, conn_name: str) -> Dict[str, Any]:
        """Create JDBC connection for the specified connection name.
        
        Args:
            conn_name: Connection name as defined in configuration
        
        Returns:
            Dictionary with JDBC connection details
        """
        conn_config = config_manager.get_connection_config(conn_name)
        if not conn_config:
            raise DataSwitchException(f"Connection configuration not found for {conn_name}")
        
        jdbc_url = self.get_jdbc_url(conn_config)
        driver = conn_config.get('driver', self.default_jdbc_driver)
        user = conn_config.get('user', '')
        password = conn_config.get('password', '')
        
        logger.info(f"Creating JDBC connection for {conn_name}")
        
        try:
            # Create connection for direct JDBC operations
            jdbc_conn = jaydebeapi.connect(
                driver,
                jdbc_url,
                [user, password],
                jars=self.jdbc_driver_path
            )
            
            # Also create Java connection for Spark use
            java_conn = self.spark._sc._gateway.jvm.java.sql.DriverManager.getConnection(
                jdbc_url, user, password
            )
            
            connection = {
                'name': conn_name,
                'jdbc_url': jdbc_url,
                'driver': driver,
                'connection': jdbc_conn,
                'java_connection': java_conn,
                'cursor': jdbc_conn.cursor()
            }
            
            self.connections[conn_name] = connection
            return connection
            
        except Exception as e:
            error_msg = f"Failed to create JDBC connection for {conn_name}: {str(e)}"
            logger.error(error_msg)
            raise DataSwitchException(error_msg)
    
    def get_connection(self, conn_name: str) -> Dict[str, Any]:
        """Get or create connection for the specified name.
        
        Args:
            conn_name: Connection name
        
        Returns:
            Connection dictionary
        """
        if conn_name in self.connections:
            return self.connections[conn_name]
        
        return self.create_jdbc_connection(conn_name)
    
    def execute_query(self, conn_name: str, query: str, params: Optional[tuple] = None) -> None:
        """Execute query on the specified connection.
        
        Args:
            conn_name: Connection name
            query: SQL query to execute
            params: Optional parameters for the query
        """
        conn = self.get_connection(conn_name)
        cursor = conn['cursor']
        
        try:
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
        except Exception as e:
            error_msg = f"Failed to execute query on {conn_name}: {str(e)}"
            logger.error(error_msg)
            raise DataSwitchException(error_msg)
    
    def read_jdbc_table(self, conn_name: str, table: str, options: Optional[Dict[str, str]] = None) -> Any:
        """Read table via JDBC.
        
        Args:
            conn_name: Connection name
            table: Table name
            options: Additional JDBC options
        
        Returns:
            Spark DataFrame with table data
        """
        conn = self.get_connection(conn_name)
        jdbc_options = {
            "url": conn['jdbc_url'],
            "dbtable": table,
            "driver": conn['driver'],
        }
        
        if options:
            jdbc_options.update(options)
        
        return self.spark.read.format("jdbc").options(**jdbc_options).load()
    
    def read_jdbc_query(self, conn_name: str, query: str, options: Optional[Dict[str, str]] = None) -> Any:
        """Read results of SQL query via JDBC.
        
        Args:
            conn_name: Connection name
            query: SQL query
            options: Additional JDBC options
        
        Returns:
            Spark DataFrame with query results
        """
        conn = self.get_connection(conn_name)
        jdbc_options = {
            "url": conn['jdbc_url'],
            "query": query,
            "driver": conn['driver'],
        }
        
        if options:
            jdbc_options.update(options)
        
        return self.spark.read.format("jdbc").options(**jdbc_options).load()
    
    def close_all_connections(self) -> None:
        """Close all open connections."""
        for conn_name, conn in self.connections.items():
            try:
                if 'cursor' in conn:
                    conn['cursor'].close()
                if 'connection' in conn:
                    conn['connection'].close()
                logger.info(f"Closed connection: {conn_name}")
            except Exception as e:
                logger.warning(f"Error closing connection {conn_name}: {str(e)}")
