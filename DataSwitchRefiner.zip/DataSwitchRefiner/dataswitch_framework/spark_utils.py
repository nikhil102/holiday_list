"""
Spark utilities for DataSwitch framework.

This module provides functionality for creating and managing Spark sessions,
as well as common DataFrame operations.
"""

import os
import logging
from typing import Dict, Any, Optional, List, Union
from functools import reduce
from pyspark.sql import SparkSession, DataFrame
import pyspark.sql.functions as f
from pyspark.sql.types import *

from dataswitch_framework.config import config_manager

logger = logging.getLogger(__name__)

def create_spark_session(app_name: str, config_overrides: Optional[Dict[str, str]] = None) -> SparkSession:
    """Create a SparkSession with configured settings.
    
    Args:
        app_name: Name of the Spark application
        config_overrides: Optional overrides for Spark configuration
    
    Returns:
        Configured SparkSession
    """
    # Get Spark configuration from config manager
    spark_config = config_manager.get('spark', {})
    
    # Set up Spark builder with app name
    builder = SparkSession.builder.appName(app_name)
    
    # Apply configuration from config file
    for key, value in spark_config.items():
        builder = builder.config(key, value)
    
    # Apply configuration overrides
    if config_overrides:
        for key, value in config_overrides.items():
            builder = builder.config(key, value)
    
    # Always set these for JDBC connectivity
    jdbc_driver_path = config_manager.get(
        'jdbc.driver_path', 
        os.environ.get('JDBC_DRIVER_PATH', 'C:/Drivers/mssql-jdbc-12.4.2.jre11.jar')
    )
    
    authentication_dll_path = config_manager.get(
        'jdbc.auth_dll_path',
        os.environ.get('JDBC_AUTH_DLL_PATH', 'C:/Drivers')
    )
    
    builder = builder.config("spark.driver.extraClassPath", jdbc_driver_path)
    builder = builder.config("spark.executor.extraClassPath", jdbc_driver_path)
    builder = builder.config("spark.executor.extraJavaOptions", f"-Djava.library.path={authentication_dll_path}")
    
    # Create and return the session
    spark = builder.getOrCreate()
    
    # Set log level
    log_level = config_manager.get('spark.log_level', 'WARN')
    spark.sparkContext.setLogLevel(log_level)
    
    logger.info(f"Created Spark session for {app_name}")
    return spark

def optimize_spark_session(spark: SparkSession, memory_fraction: float = 0.8, 
                          storage_fraction: float = 0.3, shuffle_partitions: int = 50) -> None:
    """Optimize Spark session with improved memory settings.
    
    Args:
        spark: SparkSession to optimize
        memory_fraction: Fraction of JVM memory used for execution
        storage_fraction: Fraction of execution memory used for storage
        shuffle_partitions: Number of partitions for shuffle operations
    """
    spark.conf.set("spark.memory.fraction", memory_fraction)
    spark.conf.set("spark.memory.storageFraction", storage_fraction)
    spark.conf.set("spark.sql.shuffle.partitions", shuffle_partitions)
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "-1")
    spark.conf.set("spark.dynamicAllocation.enabled", "true")
    spark.conf.set("spark.shuffle.service.enabled", "true")
    
    logger.info("Spark session optimized with memory settings")

def add_execution_metadata(df: DataFrame, mapping_name: str) -> DataFrame:
    """Add standard execution metadata columns to DataFrame.
    
    Args:
        df: Input DataFrame
        mapping_name: Mapping name for tracking
    
    Returns:
        DataFrame with added metadata columns
    """
    return df.withColumn("MAPPING_NAME", f.lit(mapping_name))

def join_dataframes(dfs: List[DataFrame], join_cols: List[str], 
                   join_type: str = "inner") -> DataFrame:
    """Join multiple DataFrames on specified columns.
    
    Args:
        dfs: List of DataFrames to join
        join_cols: List of column names to join on
        join_type: Type of join (inner, left, right, full)
    
    Returns:
        Joined DataFrame
    """
    if not dfs:
        raise ValueError("No DataFrames provided for join")
    
    if len(dfs) == 1:
        return dfs[0]
    
    def join_two_dfs(df1, df2):
        return df1.join(df2, join_cols, join_type)
    
    return reduce(join_two_dfs, dfs)

def apply_transformations(df: DataFrame, transformations: List[Dict[str, Any]]) -> DataFrame:
    """Apply a series of transformations to a DataFrame.
    
    Args:
        df: Input DataFrame
        transformations: List of transformation specifications
    
    Returns:
        Transformed DataFrame
    """
    result_df = df
    
    for transform in transformations:
        transform_type = transform.get('type')
        
        if transform_type == 'select':
            columns = transform.get('columns', [])
            result_df = result_df.select(*columns)
        
        elif transform_type == 'filter':
            condition = transform.get('condition')
            result_df = result_df.filter(condition)
        
        elif transform_type == 'withColumn':
            name = transform.get('name')
            expression = transform.get('expression')
            result_df = result_df.withColumn(name, expression)
        
        elif transform_type == 'join':
            other_df = transform.get('dataframe')
            condition = transform.get('condition')
            join_type = transform.get('joinType', 'inner')
            result_df = result_df.join(other_df, condition, join_type)
        
        elif transform_type == 'groupBy':
            group_cols = transform.get('columns', [])
            agg_expressions = transform.get('aggregations', {})
            result_df = result_df.groupBy(*group_cols).agg(agg_expressions)
        
        elif transform_type == 'orderBy':
            columns = transform.get('columns', [])
            ascending = transform.get('ascending', True)
            result_df = result_df.orderBy(*columns, ascending=ascending)
        
        elif transform_type == 'custom':
            function = transform.get('function')
            if callable(function):
                result_df = function(result_df)
        
        else:
            logger.warning(f"Unknown transformation type: {transform_type}")
    
    return result_df

def safe_data_frame_conversion(df: DataFrame, retries: int = 3, cache: bool = True) -> DataFrame:
    """Safely convert DataFrame operations with retry logic.
    
    Args:
        df: Input DataFrame to convert/materialize
        retries: Number of retry attempts
        cache: Whether to cache the resulting DataFrame
    
    Returns:
        Processed DataFrame
    """
    attempts = 0
    last_error = None
    
    while attempts < retries:
        try:
            # Force DataFrame materialization with count
            df.count()
            
            # Cache if requested
            if cache:
                df = df.cache()
            
            return df
        
        except Exception as e:
            attempts += 1
            last_error = e
            logger.warning(f"DataFrame conversion failed (attempt {attempts}/{retries}): {str(e)}")
    
    # If we reached here, all retries failed
    logger.error(f"DataFrame conversion failed after {retries} attempts: {str(last_error)}")
    raise last_error

def show_dataframe_sample(df: DataFrame, n: int = 5, truncate: bool = True) -> None:
    """Show a sample of the DataFrame and log basic statistics.
    
    Args:
        df: DataFrame to sample
        n: Number of rows to show
        truncate: Whether to truncate long values
    """
    sample_data = df.limit(n).collect()
    columns = df.columns
    
    logger.info(f"DataFrame sample ({n} rows):")
    for row in sample_data:
        row_dict = {col: row[col] for col in columns}
        logger.info(str(row_dict))
    
    logger.info(f"DataFrame has {len(columns)} columns: {', '.join(columns)}")
    
    # Log count only if the DataFrame is small or already cached
    if df.storageLevel.useMemory or df.rdd.getNumPartitions() < 10:
        count = df.count()
        logger.info(f"DataFrame contains {count} rows")
