"""
Transformation utilities for DataSwitch framework.

This module provides common data transformation functions used across
DataSwitch jobs, specifically for ETL operations.
"""

import logging
from typing import Dict, Any, Optional, List, Union, Callable
from pyspark.sql import DataFrame
import pyspark.sql.functions as f
from pyspark.sql.types import *

logger = logging.getLogger(__name__)

def trim_string_columns(df: DataFrame, columns: Optional[List[str]] = None) -> DataFrame:
    """Trim whitespace from string columns.
    
    Args:
        df: Input DataFrame
        columns: List of columns to trim (if None, all string columns)
    
    Returns:
        DataFrame with trimmed columns
    """
    if columns is None:
        # Get all string columns
        string_cols = [field.name for field in df.schema.fields 
                      if isinstance(field.dataType, StringType)]
        columns = string_cols
    
    # Apply trim to all specified columns
    result_df = df
    for col_name in columns:
        result_df = result_df.withColumn(col_name, f.trim(f.col(col_name)))
    
    return result_df

def standardize_column_names(df: DataFrame, to_upper: bool = True) -> DataFrame:
    """Standardize column names (uppercase or lowercase).
    
    Args:
        df: Input DataFrame
        to_upper: If True, convert to uppercase; if False, to lowercase
    
    Returns:
        DataFrame with standardized column names
    """
    if to_upper:
        new_column_names = [col.upper() for col in df.columns]
    else:
        new_column_names = [col.lower() for col in df.columns]
    
    return df.toDF(*new_column_names)

def lookup_transform(source_df: DataFrame, lookup_df: DataFrame, 
                    source_cols: List[str], lookup_cols: List[str],
                    select_cols: List[str], join_type: str = "left") -> DataFrame:
    """Perform lookup transformation by joining with lookup table.
    
    Args:
        source_df: Source DataFrame
        lookup_df: Lookup DataFrame
        source_cols: Columns from source for join condition
        lookup_cols: Corresponding columns from lookup for join condition
        select_cols: Columns to select from lookup table
        join_type: Type of join (left, inner, etc.)
    
    Returns:
        DataFrame after lookup transformation
    """
    # Create join conditions
    conditions = []
    for s_col, l_col in zip(source_cols, lookup_cols):
        conditions.append(source_df[s_col] == lookup_df[l_col])
    
    join_condition = conditions[0]
    for condition in conditions[1:]:
        join_condition = join_condition & condition
    
    # Perform join
    result_df = source_df.join(lookup_df.select(*lookup_cols, *select_cols), 
                             join_condition, join_type)
    
    return result_df

def null_to_value(df: DataFrame, columns: Dict[str, Any]) -> DataFrame:
    """Replace NULL values in specified columns with default values.
    
    Args:
        df: Input DataFrame
        columns: Dictionary mapping column names to default values
    
    Returns:
        DataFrame with NULL values replaced
    """
    result_df = df
    for col_name, default_val in columns.items():
        result_df = result_df.withColumn(col_name, 
                                      f.when(f.col(col_name).isNull(), default_val)
                                      .otherwise(f.col(col_name)))
    
    return result_df

def add_audit_columns(df: DataFrame, mapping_name: str) -> DataFrame:
    """Add standard audit columns to DataFrame.
    
    Args:
        df: Input DataFrame
        mapping_name: Name of the mapping for tracking
    
    Returns:
        DataFrame with audit columns
    """
    return df.withColumn("CREATED_DATE", f.current_timestamp()) \
             .withColumn("CREATED_BY", f.lit("DataSwitch")) \
             .withColumn("LAST_UPDATED_DATE", f.current_timestamp()) \
             .withColumn("LAST_UPDATED_BY", f.lit("DataSwitch")) \
             .withColumn("MAPPING_NAME", f.lit(mapping_name))

def explode_column(df: DataFrame, column: str, output_col: Optional[str] = None) -> DataFrame:
    """Explode an array column into multiple rows.
    
    Args:
        df: Input DataFrame
        column: Column name to explode
        output_col: Output column name (if None, uses original column name)
    
    Returns:
        DataFrame with exploded column
    """
    if output_col:
        return df.withColumn(output_col, f.explode(f.col(column)))
    else:
        return df.withColumn(column, f.explode(f.col(column)))

def apply_case_statement(df: DataFrame, output_column: str, 
                        case_conditions: List[Dict[str, Any]], 
                        default_value: Any = None) -> DataFrame:
    """Apply a CASE statement to create or modify a column.
    
    Args:
        df: Input DataFrame
        output_column: Name of the column to create or modify
        case_conditions: List of dictionaries with condition and value keys
        default_value: Default value if no conditions match
    
    Returns:
        DataFrame with applied CASE statement
    """
    # Start with the default value
    case_expr = f.when(f.lit(True), default_value)
    
    # Apply conditions in reverse order (last one processed first)
    for condition_dict in reversed(case_conditions):
        condition = condition_dict['condition']
        value = condition_dict['value']
        case_expr = f.when(condition, value).otherwise(case_expr)
    
    return df.withColumn(output_column, case_expr)

def string_to_date(df: DataFrame, column: str, format: str = 'yyyy-MM-dd', 
                  output_column: Optional[str] = None) -> DataFrame:
    """Convert string column to date type.
    
    Args:
        df: Input DataFrame
        column: Column name to convert
        format: Date format string
        output_column: Output column name (if None, overwrites original column)
    
    Returns:
        DataFrame with converted date column
    """
    if output_column:
        return df.withColumn(output_column, f.to_date(f.col(column), format))
    else:
        return df.withColumn(column, f.to_date(f.col(column), format))

def chain_transformations(df: DataFrame, transformations: List[Callable]) -> DataFrame:
    """Chain multiple transformation functions together.
    
    Args:
        df: Input DataFrame
        transformations: List of transformation functions
    
    Returns:
        Transformed DataFrame
    """
    result_df = df
    for transform_fn in transformations:
        result_df = transform_fn(result_df)
    
    return result_df

def count_nulls_by_column(df: DataFrame) -> Dict[str, int]:
    """Count NULL values in each column of the DataFrame.
    
    Args:
        df: Input DataFrame
    
    Returns:
        Dictionary mapping column names to NULL counts
    """
    null_counts = {}
    for column in df.columns:
        null_count = df.filter(f.col(column).isNull()).count()
        null_counts[column] = null_count
    
    return null_counts

def is_spaces_function(text):
    """Check if text contains only whitespace characters.
    
    Args:
        text: Text to check
    
    Returns:
        True if text is all whitespace, False otherwise
    """
    if text is None:
        return False
    return text.isspace()

# Create UDF for is_spaces
is_spaces_udf = f.udf(is_spaces_function, BooleanType())
