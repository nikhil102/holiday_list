"""
Logging utilities for DataSwitch framework.

This module provides functionality for configuring and managing logging,
with support for CloudWatch and Splunk integration.
"""

import os
import sys
import logging
import logging.config
import yaml
import json
import datetime
import traceback
from typing import Dict, Any, Optional, List, Union

class CloudWatchFormatter(logging.Formatter):
    """Formatter for AWS CloudWatch Logs."""
    
    def format(self, record):
        """Format log record for CloudWatch.
        
        Args:
            record: Log record
        
        Returns:
            Formatted log string in JSON format
        """
        log_entry = {
            'timestamp': datetime.datetime.now().isoformat(),
            'level': record.levelname,
            'message': record.getMessage(),
            'logger': record.name,
            'function': record.funcName,
            'line': record.lineno,
        }
        
        if hasattr(record, 'job_name'):
            log_entry['job_name'] = record.job_name
        
        if hasattr(record, 'execution_id'):
            log_entry['execution_id'] = record.execution_id
        
        if record.exc_info:
            log_entry['exception'] = {
                'type': str(record.exc_info[0].__name__),
                'message': str(record.exc_info[1]),
                'traceback': traceback.format_exc()
            }
        
        # Add any additional custom fields
        for key, value in record.__dict__.items():
            if key.startswith('custom_') and isinstance(value, (str, int, float, bool, type(None))):
                log_entry[key[7:]] = value
        
        return json.dumps(log_entry)

class SplunkFormatter(logging.Formatter):
    """Formatter for Splunk."""
    
    def format(self, record):
        """Format log record for Splunk.
        
        Args:
            record: Log record
        
        Returns:
            Formatted log string in JSON format
        """
        log_entry = {
            'time': datetime.datetime.now().isoformat(),
            'level': record.levelname,
            'event': record.getMessage(),
            'logger': record.name,
            'function': record.funcName,
            'line': record.lineno,
            'host': os.environ.get('HOSTNAME', 'unknown'),
            'source': 'dataswitch',
        }
        
        if hasattr(record, 'job_name'):
            log_entry['job_name'] = record.job_name
        
        if hasattr(record, 'execution_id'):
            log_entry['execution_id'] = record.execution_id
        
        if record.exc_info:
            log_entry['exception'] = {
                'type': str(record.exc_info[0].__name__),
                'message': str(record.exc_info[1]),
                'traceback': traceback.format_exc()
            }
        
        # Add any additional custom fields
        for key, value in record.__dict__.items():
            if key.startswith('custom_') and isinstance(value, (str, int, float, bool, type(None))):
                log_entry[key[7:]] = value
        
        return json.dumps(log_entry)

class JobContextFilter(logging.Filter):
    """Filter to add job context to log records."""
    
    def __init__(self, job_name=None, execution_id=None):
        """Initialize with job context.
        
        Args:
            job_name: Name of the job
            execution_id: Unique ID for this execution
        """
        super().__init__()
        self.job_name = job_name
        self.execution_id = execution_id
    
    def filter(self, record):
        """Add job context to log record.
        
        Args:
            record: Log record
        
        Returns:
            True (always passes the filter)
        """
        if self.job_name:
            record.job_name = self.job_name
        
        if self.execution_id:
            record.execution_id = self.execution_id
        
        return True

def configure_logging(config_path: Optional[str] = None, job_name: Optional[str] = None, 
                     execution_id: Optional[str] = None) -> None:
    """Configure logging for the DataSwitch framework.
    
    Args:
        config_path: Path to logging configuration file
        job_name: Name of the job
        execution_id: Unique ID for this execution
    """
    # Default paths to check for logging config
    paths = [
        config_path,
        os.environ.get('DATASWITCH_LOGGING_CONFIG'),
        './config/logging_config.yaml',
        '/etc/dataswitch/logging_config.yaml'
    ]
    
    config_dict = None
    
    # Try to load from first available path
    for path in paths:
        if path and os.path.exists(path):
            try:
                with open(path, 'r') as config_file:
                    config_dict = yaml.safe_load(config_file)
                break
            except Exception as e:
                print(f"Warning: Failed to load logging config from {path}: {str(e)}")
    
    # If no config found, use basic configuration
    if not config_dict:
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.StreamHandler(sys.stdout)
            ]
        )
        root_logger = logging.getLogger()
    else:
        # Apply configuration
        logging.config.dictConfig(config_dict)
        root_logger = logging.getLogger()
    
    # Add job context filter to all handlers
    context_filter = JobContextFilter(job_name, execution_id)
    for handler in root_logger.handlers:
        handler.addFilter(context_filter)
    
    # For CloudWatch and Splunk, set appropriate formatters if not already set
    for handler in root_logger.handlers:
        handler_name = type(handler).__name__.lower()
        
        # Set CloudWatch formatter for CloudWatch handlers
        if 'cloudwatch' in handler_name and not isinstance(handler.formatter, CloudWatchFormatter):
            handler.setFormatter(CloudWatchFormatter())
        
        # Set Splunk formatter for Splunk handlers
        elif 'splunk' in handler_name and not isinstance(handler.formatter, SplunkFormatter):
            handler.setFormatter(SplunkFormatter())
    
    # Log configuration success
    logger = logging.getLogger(__name__)
    logger.info(f"Logging configured for job: {job_name}, execution: {execution_id}")

class JobLogger:
    """Logger specifically for DataSwitch jobs with metrics tracking."""
    
    def __init__(self, job_name: str, execution_id: Optional[str] = None):
        """Initialize job logger.
        
        Args:
            job_name: Name of the job
            execution_id: Unique ID for this execution
        """
        self.job_name = job_name
        self.execution_id = execution_id or datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.logger = logging.getLogger(f"job.{job_name}")
        self.metrics = {
            'start_time': datetime.datetime.now(),
            'end_time': None,
            'records_processed': 0,
            'records_succeeded': 0,
            'records_failed': 0,
            'stages': {},
            'current_stage': None
        }
        
        # Add context filter to ensure job name and execution ID are in logs
        self.logger.addFilter(JobContextFilter(job_name, execution_id))
    
    def start_job(self) -> None:
        """Log job start and initialize metrics."""
        self.metrics['start_time'] = datetime.datetime.now()
        self.logger.info(f"Started job {self.job_name} with execution ID {self.execution_id}")
    
    def end_job(self, status: str = "completed") -> Dict[str, Any]:
        """Log job end and finalize metrics.
        
        Args:
            status: Job status (completed, failed, etc.)
        
        Returns:
            Job metrics dictionary
        """
        self.metrics['end_time'] = datetime.datetime.now()
        duration = (self.metrics['end_time'] - self.metrics['start_time']).total_seconds()
        
        self.logger.info(
            f"Finished job {self.job_name} with status {status}. "
            f"Duration: {duration:.2f} seconds. "
            f"Records processed: {self.metrics['records_processed']}, "
            f"succeeded: {self.metrics['records_succeeded']}, "
            f"failed: {self.metrics['records_failed']}"
        )
        
        return self.metrics
    
    def start_stage(self, stage_name: str) -> None:
        """Log stage start and initialize stage metrics.
        
        Args:
            stage_name: Name of the stage
        """
        self.metrics['current_stage'] = stage_name
        self.metrics['stages'][stage_name] = {
            'start_time': datetime.datetime.now(),
            'end_time': None,
            'records_processed': 0,
            'records_succeeded': 0,
            'records_failed': 0
        }
        
        self.logger.info(f"Started stage: {stage_name}")
    
    def end_stage(self, status: str = "completed") -> None:
        """Log stage end and finalize stage metrics.
        
        Args:
            status: Stage status (completed, failed, etc.)
        """
        stage_name = self.metrics['current_stage']
        if not stage_name or stage_name not in self.metrics['stages']:
            self.logger.warning("Cannot end stage: no current stage")
            return
        
        stage = self.metrics['stages'][stage_name]
        stage['end_time'] = datetime.datetime.now()
        duration = (stage['end_time'] - stage['start_time']).total_seconds()
        
        self.logger.info(
            f"Finished stage: {stage_name} with status {status}. "
            f"Duration: {duration:.2f} seconds. "
            f"Records processed: {stage['records_processed']}, "
            f"succeeded: {stage['records_succeeded']}, "
            f"failed: {stage['records_failed']}"
        )
    
    def update_records(self, processed: int = 0, succeeded: int = 0, failed: int = 0) -> None:
        """Update record counts for current stage and overall job.
        
        Args:
            processed: Number of records processed
            succeeded: Number of records succeeded
            failed: Number of records failed
        """
        # Update job metrics
        self.metrics['records_processed'] += processed
        self.metrics['records_succeeded'] += succeeded
        self.metrics['records_failed'] += failed
        
        # Update stage metrics if there is a current stage
        stage_name = self.metrics['current_stage']
        if stage_name and stage_name in self.metrics['stages']:
            stage = self.metrics['stages'][stage_name]
            stage['records_processed'] += processed
            stage['records_succeeded'] += succeeded
            stage['records_failed'] += failed
    
    def log_dataframe_metrics(self, df, operation: str) -> None:
        """Log metrics for DataFrame operations.
        
        Args:
            df: Spark DataFrame
            operation: Description of the operation
        """
        try:
            count = df.count()
            self.logger.info(f"DataFrame after {operation}: {count} records")
            self.update_records(processed=count, succeeded=count)
        except Exception as e:
            self.logger.warning(f"Failed to log DataFrame metrics for {operation}: {str(e)}")
    
    def debug(self, msg: str, *args, **kwargs) -> None:
        """Log debug message.
        
        Args:
            msg: Message to log
            *args: Additional positional arguments
            **kwargs: Additional keyword arguments
        """
        self.logger.debug(msg, *args, **kwargs)
    
    def info(self, msg: str, *args, **kwargs) -> None:
        """Log info message.
        
        Args:
            msg: Message to log
            *args: Additional positional arguments
            **kwargs: Additional keyword arguments
        """
        self.logger.info(msg, *args, **kwargs)
    
    def warning(self, msg: str, *args, **kwargs) -> None:
        """Log warning message.
        
        Args:
            msg: Message to log
            *args: Additional positional arguments
            **kwargs: Additional keyword arguments
        """
        self.logger.warning(msg, *args, **kwargs)
    
    def error(self, msg: str, *args, **kwargs) -> None:
        """Log error message.
        
        Args:
            msg: Message to log
            *args: Additional positional arguments
            **kwargs: Additional keyword arguments
        """
        self.logger.error(msg, *args, **kwargs)
    
    def critical(self, msg: str, *args, **kwargs) -> None:
        """Log critical message.
        
        Args:
            msg: Message to log
            *args: Additional positional arguments
            **kwargs: Additional keyword arguments
        """
        self.logger.critical(msg, *args, **kwargs)
    
    def exception(self, msg: str, *args, **kwargs) -> None:
        """Log exception message.
        
        Args:
            msg: Message to log
            *args: Additional positional arguments
            **kwargs: Additional keyword arguments
        """
        self.logger.exception(msg, *args, **kwargs)
