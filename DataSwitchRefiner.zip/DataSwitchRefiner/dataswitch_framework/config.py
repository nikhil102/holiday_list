"""
Configuration utilities for DataSwitch framework.

This module provides functionality for loading and managing configuration settings
from YAML files, environment variables, and other sources.
"""

import os
import yaml
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)

class ConfigManager:
    """Manages configuration settings for DataSwitch jobs."""
    
    def __init__(self, config_path: Optional[str] = None):
        """Initialize configuration manager.
        
        Args:
            config_path: Path to configuration YAML file. If None, will look in default locations.
        """
        self.config = {}
        self._load_config(config_path)
    
    def _load_config(self, config_path: Optional[str] = None) -> None:
        """Load configuration from file.
        
        Args:
            config_path: Path to configuration file. If None, will look in default locations.
        """
        # Default config paths in order of precedence
        paths = [
            config_path,
            os.environ.get('DATASWITCH_CONFIG_PATH'),
            './config/job_config.yaml',
            '/etc/dataswitch/job_config.yaml'
        ]
        
        # Use first valid path
        for path in paths:
            if path and os.path.exists(path):
                try:
                    with open(path, 'r') as config_file:
                        self.config = yaml.safe_load(config_file)
                    logger.info(f"Loaded configuration from {path}")
                    return
                except Exception as e:
                    logger.warning(f"Failed to load config from {path}: {str(e)}")
        
        logger.warning("No configuration file found, using defaults")
        self.config = {}
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value.
        
        Args:
            key: Configuration key (supports dot notation for nested access)
            default: Default value if key not found
        
        Returns:
            Configuration value or default
        """
        # Support dot notation for nested access
        if '.' in key:
            parts = key.split('.')
            value = self.config
            for part in parts:
                if isinstance(value, dict) and part in value:
                    value = value[part]
                else:
                    return default
            return value
        
        return self.config.get(key, default)
    
    def get_connection_config(self, conn_name: str) -> Dict[str, Any]:
        """Get database connection configuration.
        
        Args:
            conn_name: Connection name as defined in config
        
        Returns:
            Connection configuration dictionary
        """
        connections = self.get('connections', {})
        conn_config = connections.get(conn_name, {})
        
        # Support environment variable override for sensitive info
        for key in ['user', 'password', 'host', 'port', 'database']:
            env_var = f"DATASWITCH_{conn_name.upper()}_{key.upper()}"
            if env_var in os.environ:
                conn_config[key] = os.environ[env_var]
        
        return conn_config
    
    def get_job_config(self, job_name: str) -> Dict[str, Any]:
        """Get configuration for a specific job.
        
        Args:
            job_name: Job name
        
        Returns:
            Job configuration dictionary
        """
        jobs = self.get('jobs', {})
        return jobs.get(job_name, {})


# Global config instance
config_manager = ConfigManager()
