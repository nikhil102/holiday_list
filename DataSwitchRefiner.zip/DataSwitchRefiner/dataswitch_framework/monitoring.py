"""
Monitoring utilities for DataSwitch framework.

This module provides functionality for collecting and reporting job metrics,
with support for integration with monitoring systems.
"""

import os
import time
import json
import datetime
import logging
from typing import Dict, Any, Optional, List, Union

logger = logging.getLogger(__name__)

class JobMetrics:
    """Track and report metrics for DataSwitch jobs."""
    
    def __init__(self, job_name: str, execution_id: Optional[str] = None):
        """Initialize metrics collector.
        
        Args:
            job_name: Name of the job
            execution_id: Unique ID for this execution
        """
        self.job_name = job_name
        self.execution_id = execution_id or datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.metrics = {
            'job_name': job_name,
            'execution_id': self.execution_id,
            'start_time': datetime.datetime.now().isoformat(),
            'end_time': None,
            'duration_seconds': 0,
            'status': 'running',
            'records': {
                'processed': 0,
                'succeeded': 0,
                'failed': 0
            },
            'stages': {},
            'performance': {
                'cpu_usage': [],
                'memory_usage': []
            }
        }
        self.current_stage = None
    
    def start_job(self) -> None:
        """Record job start time."""
        self.metrics['start_time'] = datetime.datetime.now().isoformat()
        self.metrics['status'] = 'running'
        logger.info(f"Job {self.job_name} started with execution ID {self.execution_id}")
    
    def end_job(self, status: str = 'completed') -> Dict[str, Any]:
        """Record job end time and calculate metrics.
        
        Args:
            status: Final job status
        
        Returns:
            Complete job metrics
        """
        end_time = datetime.datetime.now()
        self.metrics['end_time'] = end_time.isoformat()
        self.metrics['status'] = status
        
        # Calculate duration
        start_time = datetime.datetime.fromisoformat(self.metrics['start_time'])
        self.metrics['duration_seconds'] = (end_time - start_time).total_seconds()
        
        logger.info(
            f"Job {self.job_name} {status} in {self.metrics['duration_seconds']:.2f} seconds. "
            f"Records: processed={self.metrics['records']['processed']}, "
            f"succeeded={self.metrics['records']['succeeded']}, "
            f"failed={self.metrics['records']['failed']}"
        )
        
        return self.metrics
    
    def start_stage(self, stage_name: str) -> None:
        """Record stage start time.
        
        Args:
            stage_name: Name of the stage
        """
        self.current_stage = stage_name
        self.metrics['stages'][stage_name] = {
            'start_time': datetime.datetime.now().isoformat(),
            'end_time': None,
            'duration_seconds': 0,
            'status': 'running',
            'records': {
                'processed': 0,
                'succeeded': 0,
                'failed': 0
            }
        }
        
        logger.info(f"Stage {stage_name} started")
    
    def end_stage(self, status: str = 'completed') -> None:
        """Record stage end time and calculate metrics.
        
        Args:
            status: Final stage status
        """
        if not self.current_stage:
            logger.warning("Cannot end stage: no current stage")
            return
        
        stage = self.metrics['stages'][self.current_stage]
        end_time = datetime.datetime.now()
        stage['end_time'] = end_time.isoformat()
        stage['status'] = status
        
        # Calculate duration
        start_time = datetime.datetime.fromisoformat(stage['start_time'])
        stage['duration_seconds'] = (end_time - start_time).total_seconds()
        
        logger.info(
            f"Stage {self.current_stage} {status} in {stage['duration_seconds']:.2f} seconds. "
            f"Records: processed={stage['records']['processed']}, "
            f"succeeded={stage['records']['succeeded']}, "
            f"failed={stage['records']['failed']}"
        )
        
        self.current_stage = None
    
    def update_records(self, processed: int = 0, succeeded: int = 0, failed: int = 0) -> None:
        """Update record counts.
        
        Args:
            processed: Number of records processed
            succeeded: Number of records succeeded
            failed: Number of records failed
        """
        # Update job-level metrics
        self.metrics['records']['processed'] += processed
        self.metrics['records']['succeeded'] += succeeded
        self.metrics['records']['failed'] += failed
        
        # Update stage-level metrics if there is a current stage
        if self.current_stage and self.current_stage in self.metrics['stages']:
            stage = self.metrics['stages'][self.current_stage]
            stage['records']['processed'] += processed
            stage['records']['succeeded'] += succeeded
            stage['records']['failed'] += failed
    
    def update_performance(self) -> None:
        """Update performance metrics."""
        try:
            # CPU usage (simplified)
            cpu_pct = os.getloadavg()[0] * 100 if hasattr(os, 'getloadavg') else 0
            
            # Memory usage (simplified)
            memory_pct = 0
            try:
                with open('/proc/meminfo', 'r') as f:
                    lines = f.readlines()
                    mem_total = int(lines[0].split()[1])
                    mem_available = int(lines[2].split()[1])
                    memory_pct = (mem_total - mem_available) / mem_total * 100
            except:
                pass
            
            timestamp = datetime.datetime.now().isoformat()
            self.metrics['performance']['cpu_usage'].append({
                'timestamp': timestamp,
                'value': cpu_pct
            })
            self.metrics['performance']['memory_usage'].append({
                'timestamp': timestamp,
                'value': memory_pct
            })
        except Exception as e:
            logger.warning(f"Failed to update performance metrics: {str(e)}")
    
    def set_custom_metric(self, name: str, value: Any) -> None:
        """Set a custom metric.
        
        Args:
            name: Metric name
            value: Metric value
        """
        if 'custom' not in self.metrics:
            self.metrics['custom'] = {}
        
        self.metrics['custom'][name] = value
    
    def log_spark_metrics(self, spark) -> None:
        """Collect and log Spark metrics.
        
        Args:
            spark: SparkSession
        """
        try:
            spark_metrics = {}
            
            # Job metrics
            spark_metrics['activeJobs'] = len(spark.sparkContext.statusTracker().getActiveJobIds())
            spark_metrics['allJobs'] = len(spark.sparkContext.statusTracker().getJobIdsForGroup())
            
            # Executor metrics
            if hasattr(spark.sparkContext, '_jsc') and hasattr(spark.sparkContext._jsc, 'sc'):
                executor_metrics = spark.sparkContext._jsc.sc().getExecutorMemoryStatus()
                executor_count = executor_metrics.size()
                spark_metrics['executorCount'] = executor_count
            
            self.set_custom_metric('spark', spark_metrics)
            
        except Exception as e:
            logger.warning(f"Failed to log Spark metrics: {str(e)}")
    
    def save_metrics_file(self, directory: str = './metrics') -> str:
        """Save metrics to a JSON file.
        
        Args:
            directory: Directory to save metrics file
        
        Returns:
            Path to saved metrics file
        """
        try:
            os.makedirs(directory, exist_ok=True)
            
            # Create filename with job name and execution ID
            filename = f"{self.job_name}_{self.execution_id}_metrics.json"
            file_path = os.path.join(directory, filename)
            
            # Convert datetime objects to ISO strings for serialization
            metrics_json = json.dumps(self.metrics, default=str, indent=2)
            
            with open(file_path, 'w') as f:
                f.write(metrics_json)
            
            logger.info(f"Metrics saved to {file_path}")
            return file_path
            
        except Exception as e:
            logger.error(f"Failed to save metrics file: {str(e)}")
            return ""
    
    def publish_to_cloudwatch(self, namespace: str = 'DataSwitch') -> bool:
        """Publish metrics to CloudWatch.
        
        Args:
            namespace: CloudWatch namespace for metrics
        
        Returns:
            True if successful, False otherwise
        """
        try:
            # Import boto3 here to make it optional
            import boto3
            
            cloudwatch = boto3.client('cloudwatch')
            
            # Basic job metrics
            cloudwatch.put_metric_data(
                Namespace=namespace,
                MetricData=[
                    {
                        'MetricName': 'JobDuration',
                        'Dimensions': [
                            {'Name': 'JobName', 'Value': self.job_name},
                            {'Name': 'ExecutionId', 'Value': self.execution_id}
                        ],
                        'Value': self.metrics['duration_seconds'],
                        'Unit': 'Seconds'
                    },
                    {
                        'MetricName': 'RecordsProcessed',
                        'Dimensions': [
                            {'Name': 'JobName', 'Value': self.job_name},
                            {'Name': 'ExecutionId', 'Value': self.execution_id}
                        ],
                        'Value': self.metrics['records']['processed'],
                        'Unit': 'Count'
                    },
                    {
                        'MetricName': 'RecordsSucceeded',
                        'Dimensions': [
                            {'Name': 'JobName', 'Value': self.job_name},
                            {'Name': 'ExecutionId', 'Value': self.execution_id}
                        ],
                        'Value': self.metrics['records']['succeeded'],
                        'Unit': 'Count'
                    },
                    {
                        'MetricName': 'RecordsFailed',
                        'Dimensions': [
                            {'Name': 'JobName', 'Value': self.job_name},
                            {'Name': 'ExecutionId', 'Value': self.execution_id}
                        ],
                        'Value': self.metrics['records']['failed'],
                        'Unit': 'Count'
                    }
                ]
            )
            
            # Stage metrics
            for stage_name, stage in self.metrics['stages'].items():
                cloudwatch.put_metric_data(
                    Namespace=namespace,
                    MetricData=[
                        {
                            'MetricName': 'StageDuration',
                            'Dimensions': [
                                {'Name': 'JobName', 'Value': self.job_name},
                                {'Name': 'ExecutionId', 'Value': self.execution_id},
                                {'Name': 'StageName', 'Value': stage_name}
                            ],
                            'Value': stage['duration_seconds'],
                            'Unit': 'Seconds'
                        },
                        {
                            'MetricName': 'StageRecordsProcessed',
                            'Dimensions': [
                                {'Name': 'JobName', 'Value': self.job_name},
                                {'Name': 'ExecutionId', 'Value': self.execution_id},
                                {'Name': 'StageName', 'Value': stage_name}
                            ],
                            'Value': stage['records']['processed'],
                            'Unit': 'Count'
                        }
                    ]
                )
            
            logger.info(f"Metrics published to CloudWatch in namespace {namespace}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to publish metrics to CloudWatch: {str(e)}")
            return False

    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get a summary of metrics.
        
        Returns:
            Dictionary with metrics summary
        """
        summary = {
            'job_name': self.job_name,
            'execution_id': self.execution_id,
            'status': self.metrics['status'],
            'duration_seconds': self.metrics['duration_seconds'],
            'records_processed': self.metrics['records']['processed'],
            'records_succeeded': self.metrics['records']['succeeded'],
            'records_failed': self.metrics['records']['failed'],
            'stage_count': len(self.metrics['stages'])
        }
        
        return summary
