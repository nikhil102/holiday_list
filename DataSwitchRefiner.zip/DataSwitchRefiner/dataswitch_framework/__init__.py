"""
DataSwitch Framework
-------------------
A modular framework for enhancing, standardizing, and monitoring PySpark-based data integration jobs.

This package provides utilities for:
- Configuration management
- Connection handling
- Logging and monitoring
- Common transformations
- Error handling
- Spark session management
"""

__version__ = '1.0.0'
