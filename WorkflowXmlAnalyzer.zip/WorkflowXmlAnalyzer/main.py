#!/usr/bin/env python3
"""
Informatica Workflow XML Parser and Analyzer
Main entry point for the desktop application
"""

import sys
import os
import logging
from tkinter import messagebox
import tkinter as tk

# Add current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gui_main import InformaticaAnalyzerGUI
from database_manager import DatabaseManager
from config import APP_CONFIG

def setup_logging():
    """Setup application logging"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('informatica_analyzer.log'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    return logging.getLogger(__name__)

def check_database_connection():
    """Check if database connection can be established"""
    try:
        db_manager = DatabaseManager()
        db_manager.test_connection()
        return True
    except Exception as e:
        messagebox.showerror(
            "Database Connection Error",
            f"Failed to connect to database:\n{str(e)}\n\n"
            f"Please check your database configuration in config.py"
        )
        return False

def main():
    """Main application entry point"""
    logger = setup_logging()
    logger.info("Starting Informatica Workflow Analyzer")
    
    try:
        # Check database connection before starting GUI
        if not check_database_connection():
            logger.error("Database connection failed, exiting application")
            return
        
        # Create and run the main GUI application
        root = tk.Tk()
        app = InformaticaAnalyzerGUI(root)
        
        # Configure window close behavior
        def on_closing():
            logger.info("Application closing")
            root.destroy()
        
        root.protocol("WM_DELETE_WINDOW", on_closing)
        
        # Start the GUI event loop
        logger.info("Starting GUI application")
        root.mainloop()
        
    except Exception as e:
        logger.error(f"Application error: {str(e)}", exc_info=True)
        messagebox.showerror(
            "Application Error",
            f"An unexpected error occurred:\n{str(e)}"
        )
    finally:
        logger.info("Application shutdown complete")

if __name__ == "__main__":
    main()
