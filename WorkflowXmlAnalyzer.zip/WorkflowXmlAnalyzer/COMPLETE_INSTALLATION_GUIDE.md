# Informatica Workflow Analyzer - Complete Installation Guide

## Overview
This guide provides step-by-step instructions for installing and running the Informatica Workflow Analyzer on your company laptop with MS SQL Server integration.

## System Requirements

### Hardware Requirements
- Windows 10/11 (64-bit)
- Minimum 4GB RAM (8GB recommended)
- 2GB free disk space
- Network access to SQL Server

### Software Prerequisites
- Python 3.7 or higher
- Microsoft SQL Server access
- ODBC Driver 17 for SQL Server

## Pre-Installation Checklist

### 1. Verify Database Access
Ensure you can connect to:
- **Server:** w908925\CGSQL
- **Database:** msscdm_dev4
- **Username:** spark_user
- **Password:** spark@25091990

### 2. Test SQL Server Connection
Open Command Prompt and test connection:
```cmd
sqlcmd -S w908925\CGSQL -U spark_user -P spark@25091990 -d msscdm_dev4 -Q "SELECT 1"
```

If this fails, contact your IT administrator for database access.

## Installation Steps

### Step 1: Install Python
1. Download Python 3.7+ from https://www.python.org/downloads/
2. During installation, check "Add Python to PATH"
3. Verify installation:
   ```cmd
   python --version
   pip --version
   ```

### Step 2: Install ODBC Driver
1. Download "ODBC Driver 17 for SQL Server" from Microsoft
2. Install using administrator privileges
3. Verify in Windows: Control Panel → Administrative Tools → ODBC Data Sources

### Step 3: Extract Application Package
1. Extract the deployment package to: `C:\InformaticaAnalyzer\`
2. Navigate to the extracted folder

### Step 4: Install Python Dependencies
Open Command Prompt in the application folder and run:
```cmd
pip install -r requirements.txt
```

### Step 5: Setup Database Tables (Optional)
If tables don't exist, run the database setup script:
```cmd
sqlcmd -S w908925\CGSQL -U spark_user -P spark@25091990 -d msscdm_dev4 -i database_setup.sql
```

## Running the Application

### Method 1: Using Batch File (Recommended)
Double-click `start_analyzer.bat` to launch the application automatically.

### Method 2: Manual Start
Open Command Prompt in the application folder:
```cmd
python informatica_analyzer.py
```

## First Time Usage

### 1. Application Startup
- The application will test database connectivity on startup
- You should see "Connected to MS SQL Server" in the status bar
- If connection fails, verify network access and credentials

### 2. Processing XML Files
1. Go to "File Processing" tab
2. Click "Select Single File" or "Select Multiple Files"
3. Choose your Informatica XML workflow files
4. Click "Process Files" to extract metadata

### 3. Viewing Results
1. Switch to "Workflow Analysis" tab
2. View parsed workflows in the table
3. Use search functionality to filter results
4. Double-click any workflow for detailed view

### 4. Exporting Data
1. Go to "Export" tab
2. Select format (CSV or Excel)
3. Click "Export Data" and choose save location

## Configuration Details

The application is pre-configured with your company settings:

```python
DATABASE_CONFIG = {
    'server': 'w908925\\CGSQL',
    'database': 'msscdm_dev4',
    'username': 'spark_user',
    'password': 'spark@25091990'
}
```

## Troubleshooting

### Connection Issues
**Problem:** "Database connection failed"
**Solutions:**
1. Verify SQL Server is running
2. Check network connectivity: `ping w908925.cguser.capgroup.com`
3. Confirm ODBC driver installation
4. Test credentials with sqlcmd

### Permission Issues
**Problem:** "Access denied" or "Login failed"
**Solutions:**
1. Verify username and password
2. Check database permissions with DBA
3. Ensure spark_user has access to msscdm_dev4

### Python Dependency Issues
**Problem:** "Module not found" errors
**Solutions:**
1. Reinstall dependencies: `pip install --upgrade -r requirements.txt`
2. Check Python version: `python --version`
3. Use virtual environment if needed

### XML Parsing Issues
**Problem:** "Invalid XML format"
**Solutions:**
1. Verify XML files are valid Informatica exports
2. Check file permissions and accessibility
3. Try with sample XML files first

### Memory Issues
**Problem:** Application crashes with large XML files
**Solutions:**
1. Process files in smaller batches
2. Increase available RAM
3. Close other applications

## Advanced Configuration

### Custom Database Settings
If you need to connect to a different database, modify the configuration in `informatica_analyzer.py`:

```python
DATABASE_CONFIG = {
    'driver': '{ODBC Driver 17 for SQL Server}',
    'server': 'YOUR_SERVER\\INSTANCE',
    'database': 'YOUR_DATABASE',
    'username': 'YOUR_USERNAME',
    'password': 'YOUR_PASSWORD'
}
```

### Network Configuration
For VPN or proxy environments, ensure:
1. VPN connection is active
2. Firewall allows SQL Server port (1433)
3. Proxy settings don't block database traffic

## File Structure

```
C:\InformaticaAnalyzer\
├── informatica_analyzer.py          # Main application
├── requirements.txt                 # Python dependencies
├── database_setup.sql              # Database table creation
├── start_analyzer.bat              # Quick start script
├── INSTALLATION_INSTRUCTIONS.txt   # Basic instructions
├── informatica_analyzer.log        # Application log file
└── sample_xml_files\               # Test XML files
    ├── wf_landing_sfdc_to_cdm_contact_party.xml
    ├── wf_landing_sfdc_to_cdm_organization_party.xml
    └── wf_landing_sfdc_to_cdm_office_party.xml
```

## Database Tables Created

The application creates these tables in msscdm_dev4:

1. **informatica_workflows** - Main workflow metadata
2. **informatica_sources** - Source system information
3. **informatica_fields** - Field-level details

## Features Overview

### XML Analysis Capabilities
- Extracts workflow names and metadata
- Identifies sources, transformations, targets
- Parses field definitions and data types
- Analyzes workflow purposes and patterns

### Database Integration
- Automatic table creation
- Efficient data storage and indexing
- Support for large-scale analysis
- Data integrity and relationships

### User Interface
- Intuitive tab-based navigation
- Real-time progress tracking
- Search and filter capabilities
- Detailed workflow inspection

### Export Functions
- CSV format for data analysis
- Excel format with formatting
- Configurable export scope
- Export logging and tracking

## Performance Optimization

### For Large XML Files
1. Process files in batches of 10-20
2. Monitor memory usage during processing
3. Close application between large batch runs

### Database Performance
1. Regularly check table sizes and performance
2. Consider archiving old analysis data
3. Monitor log file growth

## Support and Maintenance

### Log Files
Application logs are written to `informatica_analyzer.log` for troubleshooting.

### Updates
To update the application:
1. Backup current installation
2. Extract new version to same location
3. Run with existing database (no data loss)

### Backup
Recommended backup strategy:
1. Database: Regular SQL Server backups
2. Application: Copy entire folder
3. XML files: Maintain source file backups

## Contact Information

For technical support or issues:
- Check log files first
- Document error messages
- Note system configuration details
- Contact development team with specific error details

## Security Notes

- Application uses SQL Server authentication
- Credentials are stored in application code
- Ensure proper file system permissions
- Follow company security policies for database access

This installation guide provides comprehensive coverage for deploying the Informatica Workflow Analyzer on your company laptop environment.