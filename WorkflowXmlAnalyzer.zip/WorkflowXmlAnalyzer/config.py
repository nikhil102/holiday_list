"""
Configuration settings for Informatica Workflow Analyzer
"""

import os

# Application Configuration
APP_CONFIG = {
    'app_name': 'Informatica Workflow Analyzer',
    'version': '1.0.0',
    'window_width': 1200,
    'window_height': 800,
    'min_width': 800,
    'min_height': 600
}

# Database Configuration - MS SQL Server with ODBC (Company Laptop Settings)
DATABASE_CONFIG = {
    'driver': '{ODBC Driver 17 for SQL Server}',
    'server': 'w908925\\CGSQL',
    'database': 'msscdm_dev4',
    'username': 'spark_user',
    'password': 'spark@25091990',
    'trusted_connection': 'no',
    'connection_timeout': 30,
    'command_timeout': 30
}

# XML Parsing Configuration
XML_CONFIG = {
    'supported_extensions': ['.xml'],
    'max_file_size_mb': 100,
    'batch_size': 10,
    'timeout_seconds': 300
}

# Export Configuration
EXPORT_CONFIG = {
    'supported_formats': ['xlsx', 'csv'],
    'max_rows_excel': 1000000,
    'default_export_path': os.path.expanduser('~/Downloads')
}

# Logging Configuration
LOG_CONFIG = {
    'log_file': 'informatica_analyzer.log',
    'max_log_size_mb': 10,
    'backup_count': 3,
    'log_level': 'INFO'
}

# Database Table Names
TABLE_NAMES = {
    'workflows': 'informatica_workflows',
    'sources': 'informatica_sources',
    'transformations': 'informatica_transformations',
    'targets': 'informatica_targets',
    'mappings': 'informatica_mappings',
    'fields': 'informatica_fields',
    'analysis_summary': 'informatica_analysis_summary'
}

# GUI Configuration
GUI_CONFIG = {
    'font_family': 'Segoe UI',
    'font_size': 9,
    'header_font_size': 11,
    'colors': {
        'primary': '#0078D4',
        'secondary': '#005A9E',
        'success': '#107C10',
        'warning': '#FF8C00',
        'error': '#D13438',
        'background': '#FFFFFF',
        'surface': '#F3F2F1',
        'text': '#323130'
    }
}
