"""
Utility functions for Informatica Workflow Analyzer
"""

import os
import pandas as pd
from typing import Dict, Any, List
import logging
from datetime import datetime

def format_file_size(size_bytes: int) -> str:
    """Format file size in human readable format"""
    if size_bytes == 0:
        return "0B"
    
    size_names = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    while size_bytes >= 1024 and i < len(size_names) - 1:
        size_bytes /= 1024.0
        i += 1
    
    return f"{size_bytes:.1f}{size_names[i]}"

def export_to_excel(df: pd.DataFrame, file_path: str, sheet_name: str = 'Data') -> bool:
    """Export DataFrame to Excel file"""
    try:
        with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            # Get the worksheet
            worksheet = writer.sheets[sheet_name]
            
            # Auto-adjust column widths
            for column in worksheet.columns:
                max_length = 0
                column_letter = column[0].column_letter
                
                for cell in column:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                    except:
                        pass
                
                adjusted_width = min(max_length + 2, 50)
                worksheet.column_dimensions[column_letter].width = adjusted_width
        
        return True
        
    except Exception as e:
        logging.getLogger(__name__).error(f"Error exporting to Excel: {str(e)}")
        raise

def export_to_csv(df: pd.DataFrame, file_path: str) -> bool:
    """Export DataFrame to CSV file"""
    try:
        df.to_csv(file_path, index=False, encoding='utf-8')
        return True
        
    except Exception as e:
        logging.getLogger(__name__).error(f"Error exporting to CSV: {str(e)}")
        raise

def validate_file_path(file_path: str) -> bool:
    """Validate if file path exists and is accessible"""
    try:
        return os.path.exists(file_path) and os.path.isfile(file_path)
    except:
        return False

def safe_get_dict_value(data: Dict[str, Any], key: str, default: Any = None) -> Any:
    """Safely get value from dictionary with default"""
    try:
        return data.get(key, default)
    except:
        return default

def clean_string(value: str) -> str:
    """Clean string value for database storage"""
    if value is None:
        return ""
    
    try:
        # Remove null characters and control characters
        cleaned = str(value).replace('\x00', '').strip()
        
        # Limit length to prevent database issues
        if len(cleaned) > 4000:
            cleaned = cleaned[:4000] + "..."
        
        return cleaned
        
    except:
        return ""

def parse_informatica_date(date_string: str) -> datetime:
    """Parse Informatica date format"""
    if not date_string:
        return None
    
    try:
        # Common Informatica date formats
        formats = [
            '%m/%d/%Y %H:%M:%S',
            '%Y-%m-%d %H:%M:%S',
            '%m/%d/%Y',
            '%Y-%m-%d'
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(date_string, fmt)
            except ValueError:
                continue
        
        return None
        
    except Exception:
        return None

def get_unique_filename(base_path: str) -> str:
    """Get unique filename by appending number if file exists"""
    if not os.path.exists(base_path):
        return base_path
    
    name, ext = os.path.splitext(base_path)
    counter = 1
    
    while True:
        new_path = f"{name}_{counter}{ext}"
        if not os.path.exists(new_path):
            return new_path
        counter += 1

def truncate_string(text: str, max_length: int = 100) -> str:
    """Truncate string to specified length with ellipsis"""
    if not text:
        return ""
    
    if len(text) <= max_length:
        return text
    
    return text[:max_length-3] + "..."

def format_duration(seconds: float) -> str:
    """Format duration in seconds to human readable format"""
    if seconds < 60:
        return f"{seconds:.1f} seconds"
    elif seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.1f} minutes"
    else:
        hours = seconds / 3600
        return f"{hours:.1f} hours"

def create_summary_stats(df: pd.DataFrame) -> Dict[str, Any]:
    """Create summary statistics from workflow DataFrame"""
    if df.empty:
        return {}
    
    try:
        stats = {
            'total_workflows': len(df),
            'total_sources': df['source_count'].sum() if 'source_count' in df.columns else 0,
            'total_fields': df['field_count'].sum() if 'field_count' in df.columns else 0,
            'repositories': df['repository_name'].nunique() if 'repository_name' in df.columns else 0,
            'folders': df['folder_name'].nunique() if 'folder_name' in df.columns else 0,
            'avg_sources_per_workflow': df['source_count'].mean() if 'source_count' in df.columns else 0,
            'avg_fields_per_workflow': df['field_count'].mean() if 'field_count' in df.columns else 0
        }
        
        # Most common repositories
        if 'repository_name' in df.columns:
            stats['top_repositories'] = df['repository_name'].value_counts().head(5).to_dict()
        
        # Most common folders
        if 'folder_name' in df.columns:
            stats['top_folders'] = df['folder_name'].value_counts().head(5).to_dict()
        
        return stats
        
    except Exception as e:
        logging.getLogger(__name__).error(f"Error creating summary stats: {str(e)}")
        return {}

def validate_xml_content(content: str) -> bool:
    """Basic validation of XML content"""
    try:
        # Check for basic XML structure
        if not content.strip().startswith('<?xml'):
            return False
        
        # Check for Informatica-specific elements
        required_elements = ['POWERMART', 'REPOSITORY', 'FOLDER']
        for element in required_elements:
            if element not in content:
                return False
        
        return True
        
    except Exception:
        return False

def extract_workflow_name_from_path(file_path: str) -> str:
    """Extract workflow name from file path"""
    try:
        filename = os.path.basename(file_path)
        name_without_ext = os.path.splitext(filename)[0]
        
        # Remove common prefixes
        prefixes_to_remove = ['wf_', 'workflow_', 'mapping_', 'm_']
        for prefix in prefixes_to_remove:
            if name_without_ext.lower().startswith(prefix):
                name_without_ext = name_without_ext[len(prefix):]
                break
        
        return name_without_ext
        
    except Exception:
        return "Unknown"

def batch_process_list(items: List[Any], batch_size: int = 100):
    """Generator to process list in batches"""
    for i in range(0, len(items), batch_size):
        yield items[i:i + batch_size]

def sanitize_column_name(name: str) -> str:
    """Sanitize column name for database"""
    if not name:
        return "unknown_column"
    
    # Replace special characters with underscores
    import re
    sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', name)
    
    # Ensure it starts with a letter
    if not sanitized[0].isalpha():
        sanitized = 'col_' + sanitized
    
    # Limit length
    if len(sanitized) > 64:
        sanitized = sanitized[:64]
    
    return sanitized.lower()

def log_performance(func):
    """Decorator to log function performance"""
    def wrapper(*args, **kwargs):
        logger = logging.getLogger(__name__)
        start_time = datetime.now()
        
        try:
            result = func(*args, **kwargs)
            duration = (datetime.now() - start_time).total_seconds()
            logger.info(f"{func.__name__} completed in {format_duration(duration)}")
            return result
            
        except Exception as e:
            duration = (datetime.now() - start_time).total_seconds()
            logger.error(f"{func.__name__} failed after {format_duration(duration)}: {str(e)}")
            raise
    
    return wrapper
