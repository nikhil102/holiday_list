"""
Main entry point for the ETL framework.
This script orchestrates the process of converting Informatica XML to PySpark,
executing the PySpark scripts, and validating the results.
"""

# Import app from app.py for compatibility with Gunicorn
from app import app

import os
import sys
import argparse
import json
from pathlib import Path
import logging

# Import custom modules
from config import Config
from utils.logging_utils import setup_logger, get_log_file_path
from executors.pyspark_executor import PySparkExecutor
from validators.data_validator import DataValidator

# Configure logging
logging.basicConfig(level=logging.DEBUG)


def parse_args():
    """
    Parse command-line arguments.
    
    Returns:
        Namespace: Parsed arguments.
    """
    parser = argparse.ArgumentParser(
        description='ETL framework for converting Informatica XML to PySpark'
    )
    
    # Add subparsers for different commands
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    # Convert command
    convert_parser = subparsers.add_parser('convert', help='Convert Informatica XML to PySpark')
    convert_parser.add_argument('xml_path', help='Path to the Informatica XML file')
    convert_parser.add_argument('--output-dir', default='generated', 
                             help='Directory for output PySpark scripts')
    convert_parser.add_argument('--config', help='Path to the configuration file')
    
    # Execute command
    execute_parser = subparsers.add_parser('execute', help='Execute a PySpark script')
    execute_parser.add_argument('script_path', help='Path to the PySpark script')
    execute_parser.add_argument('--config', help='Path to the configuration file')
    execute_parser.add_argument('--args', nargs='*', help='Arguments for the script')
    execute_parser.add_argument('--spark-submit', action='store_true', 
                              help='Use spark-submit instead of direct execution')
    
    # Validate command
    validate_parser = subparsers.add_parser('validate', help='Validate ETL results')
    validate_parser.add_argument('--tables', nargs='+', required=True, 
                               help='Tables to validate')
    validate_parser.add_argument('--config', help='Path to the configuration file')
    validate_parser.add_argument('--report-dir', default='validation_reports', 
                                help='Directory for validation reports')
    
    # Run command (execute + validate)
    run_parser = subparsers.add_parser('run', help='Execute and validate in one step')
    run_parser.add_argument('script_path', help='Path to the PySpark script')
    run_parser.add_argument('--tables', nargs='+', required=True, 
                          help='Tables to validate after execution')
    run_parser.add_argument('--config', help='Path to the configuration file')
    run_parser.add_argument('--args', nargs='*', help='Arguments for the script')
    run_parser.add_argument('--spark-submit', action='store_true', 
                          help='Use spark-submit instead of direct execution')
    run_parser.add_argument('--report-dir', default='validation_reports', 
                          help='Directory for validation reports')
    
    # List tables command
    tables_parser = subparsers.add_parser('tables', help='List tables in source or target database')
    tables_parser.add_argument('--database', choices=['source', 'target'], required=True,
                             help='Which database to list tables from')
    tables_parser.add_argument('--config', help='Path to the configuration file')
    tables_parser.add_argument('--output', help='Write table list to file')
    
    return parser.parse_args()


def convert_informatica_xml(args, logger):
    """
    Convert Informatica XML to PySpark script.
    
    Args:
        args (Namespace): Parsed arguments.
        logger (Logger): Logger to use.
    
    Returns:
        bool: True if conversion was successful, False otherwise.
    """
    from lxml import etree
    
    try:
        xml_path = args.xml_path
        output_dir = args.output_dir
        
        logger.info(f"Converting Informatica XML: {xml_path}")
        logger.info(f"Output directory: {output_dir}")
        
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Parse XML file
        tree = etree.parse(xml_path)
        root = tree.getroot()
        
        # Get workflow name
        workflow_name = Path(xml_path).stem
        
        # Extract mapping information
        logger.info("Extracting mapping information from XML")
        
        # Example extraction logic - should be expanded for real implementation
        mappings = []
        for mapping in root.xpath("//MAPPING"):
            mapping_name = mapping.get("NAME", "unknown")
            logger.info(f"Found mapping: {mapping_name}")
            
            # Extract source tables
            source_tables = []
            for source in mapping.xpath(".//SOURCE"):
                source_name = source.get("NAME", "unknown")
                source_tables.append(source_name)
            
            # Extract target tables
            target_tables = []
            for target in mapping.xpath(".//TARGET"):
                target_name = target.get("NAME", "unknown")
                target_tables.append(target_name)
            
            # Extract transformations
            transformations = []
            for transform in mapping.xpath(".//TRANSFORMATION"):
                transform_name = transform.get("NAME", "unknown")
                transform_type = transform.get("TYPE", "unknown")
                transformations.append({
                    "name": transform_name,
                    "type": transform_type
                })
            
            mappings.append({
                "name": mapping_name,
                "sources": source_tables,
                "targets": target_tables,
                "transformations": transformations
            })
        
        # Generate PySpark script
        logger.info("Generating PySpark script")
        
        script_path = os.path.join(output_dir, f"s_{workflow_name}.py")
        
        with open(script_path, 'w') as f:
            f.write('"""\n')
            f.write(f'PySpark script generated from Informatica XML workflow: {workflow_name}\n')
            f.write('"""\n\n')
            
            f.write('import sys\n')
            f.write('import argparse\n')
            f.write('from pyspark.sql import SparkSession\n')
            f.write('import pyspark.sql.functions as F\n\n')
            
            f.write('def parse_args():\n')
            f.write('    parser = argparse.ArgumentParser()\n')
            f.write('    parser.add_argument("--config", help="Path to configuration file")\n')
            f.write('    return parser.parse_args()\n\n')
            
            f.write('def main():\n')
            f.write('    args = parse_args()\n\n')
            
            f.write('    # Create Spark session\n')
            f.write('    spark = SparkSession.builder \\\n')
            f.write('        .appName("Informatica XML to PySpark - ' + workflow_name + '") \\\n')
            f.write('        .getOrCreate()\n\n')
            
            f.write('    # Load configuration\n')
            f.write('    from config import Config\n')
            f.write('    config = Config(args.config)\n\n')
            
            f.write('    # Set up JDBC properties\n')
            f.write('    source_jdbc_url = config.get_source_jdbc_url()\n')
            f.write('    target_jdbc_url = config.get_target_jdbc_url()\n')
            f.write('    jdbc_properties = {\n')
            f.write('        "user": config.get("jdbc.username"),\n')
            f.write('        "password": config.get("jdbc.password"),\n')
            f.write('        "driver": config.get("jdbc.driver")\n')
            f.write('    }\n\n')
            
            # Add source tables loading
            f.write('    # Load source tables\n')
            all_sources = set()
            for mapping in mappings:
                all_sources.update(mapping["sources"])
            
            for source in all_sources:
                df_name = f"df_{source.lower()}"
                f.write(f'    {df_name} = spark.read.jdbc(source_jdbc_url, "{source}", properties=jdbc_properties)\n')
                f.write(f'    {df_name}.createOrReplaceTempView("{source}")\n')
                f.write(f'    print(f"Loaded source table {source} with {{({df_name}.count())}} rows")\n\n')
            
            # Add transformations for each mapping
            for mapping in mappings:
                f.write(f'    # Mapping: {mapping["name"]}\n')
                
                # Add transformation logic based on mapping type
                for transform in mapping["transformations"]:
                    if transform["type"] == "Filter":
                        f.write(f'    # Filter: {transform["name"]}\n')
                        f.write(f'    # TODO: Implement filter logic\n\n')
                    elif transform["type"] == "Joiner":
                        f.write(f'    # Join: {transform["name"]}\n')
                        f.write(f'    # TODO: Implement join logic\n\n')
                    elif transform["type"] == "Aggregator":
                        f.write(f'    # Aggregation: {transform["name"]}\n')
                        f.write(f'    # TODO: Implement aggregation logic\n\n')
                    else:
                        f.write(f'    # {transform["type"]}: {transform["name"]}\n')
                        f.write(f'    # TODO: Implement transformation logic\n\n')
                
                # Add target table writing
                for target in mapping["targets"]:
                    df_name = f"df_{target.lower()}_target"
                    f.write(f'    # Write to target table: {target}\n')
                    f.write(f'    {df_name} = None  # This should be the result of your transformations\n')
                    f.write(f'    # For example:\n')
                    f.write(f'    # {df_name} = spark.sql("SELECT * FROM ...")\n\n')
                    f.write(f'    # Write to target\n')
                    f.write(f'    if {df_name} is not None:\n')
                    f.write(f'        {df_name}.write \\\n')
                    f.write(f'            .mode("overwrite") \\\n')
                    f.write(f'            .jdbc(target_jdbc_url, "{target}", properties=jdbc_properties)\n')
                    f.write(f'        print(f"Wrote {{({df_name}.count())}} rows to target table {target}")\n\n')
            
            f.write('    # Stop Spark session\n')
            f.write('    spark.stop()\n\n')
            
            f.write('if __name__ == "__main__":\n')
            f.write('    main()\n')
        
        logger.info(f"PySpark script generated: {script_path}")
        
        # Generate mapping report
        report_path = os.path.join(output_dir, f"{workflow_name}_mapping_report.json")
        with open(report_path, 'w') as f:
            json.dump({
                "workflow": workflow_name,
                "mappings": mappings
            }, f, indent=2)
        
        logger.info(f"Mapping report generated: {report_path}")
        
        return True
    
    except Exception as e:
        logger.error(f"Failed to convert Informatica XML: {str(e)}")
        return False


def execute_script(args, logger):
    """
    Execute a PySpark script.
    
    Args:
        args (Namespace): Parsed arguments.
        logger (Logger): Logger to use.
    
    Returns:
        bool: True if execution was successful, False otherwise.
    """
    logger.info(f"Executing script: {args.script_path}")
    
    # Create executor
    executor = PySparkExecutor(logger)
    
    try:
        # Execute script
        if args.spark_submit:
            return_code, stdout, stderr = executor.execute_pyspark_submit(
                args.script_path, args.args
            )
        else:
            return_code, stdout, stderr = executor.execute_script(
                args.script_path, args.args
            )
        
        success = return_code == 0
        
        # Log output
        if stdout:
            logger.debug(f"Script output:\n{stdout}")
        
        if stderr:
            if success:
                logger.debug(f"Script stderr:\n{stderr}")
            else:
                logger.error(f"Script stderr:\n{stderr}")
        
        if success:
            logger.info("Script execution completed successfully")
        else:
            logger.error(f"Script execution failed with return code {return_code}")
        
        return success
    
    except Exception as e:
        logger.error(f"Failed to execute script: {str(e)}")
        return False


def validate_tables_cli(args, logger):
    """
    Validate ETL results by comparing tables.
    
    Args:
        args (Namespace): Parsed arguments.
        logger (Logger): Logger to use.
    
    Returns:
        dict: Validation report.
    """
    logger.info(f"Validating tables: {', '.join(args.tables)}")
    
    # Load configuration
    config = Config(args.config)
    
    # Create validator
    validator = DataValidator(
        config.get_source_connection_string(),
        config.get_target_connection_string(),
        logger
    )
    
    try:
        # Generate validation report
        report = validator.generate_validation_report(
            args.tables,
            args.report_dir
        )
        
        # Log summary
        logger.info(f"Validation complete. {report['summary']['full_matches']} out of "
                   f"{report['tables_validated']} tables fully match.")
        
        return report
    
    except Exception as e:
        logger.error(f"Failed to validate tables: {str(e)}")
        return {'status': 'error', 'message': str(e)}


def run_workflow(args, logger):
    """
    Execute a PySpark script and validate the results.
    
    Args:
        args (Namespace): Parsed arguments.
        logger (Logger): Logger to use.
    
    Returns:
        tuple: (execution_success, validation_report)
    """
    # Execute script
    execution_success = execute_script(args, logger)
    
    if not execution_success:
        logger.error("Script execution failed. Skipping validation.")
        return execution_success, None
    
    # Validate tables
    validation_report = validate_tables_cli(args, logger)
    
    return execution_success, validation_report


def list_database_tables(args, logger):
    """
    List tables in a database.
    
    Args:
        args (Namespace): Parsed arguments.
        logger (Logger): Logger to use.
    
    Returns:
        list: Table names.
    """
    from utils.connection_utils import get_connection, list_tables
    
    # Load configuration
    config = Config(args.config)
    
    # Get connection string based on database type
    if args.database == 'source':
        conn_str = config.get_source_connection_string()
        db_type = 'source'
    else:
        conn_str = config.get_target_connection_string()
        db_type = 'target'
    
    logger.info(f"Listing tables in {db_type} database")
    
    try:
        # Connect to database
        conn = get_connection(conn_str)
        
        # List tables
        tables = list_tables(conn)
        
        # Close connection
        conn.close()
        
        # Print tables
        print(f"\nTables in {db_type} database:")
        for i, table in enumerate(tables, 1):
            print(f"{i}. {table}")
        print(f"\nTotal: {len(tables)} tables")
        
        # Write to file if requested
        if args.output:
            with open(args.output, 'w') as f:
                for table in tables:
                    f.write(f"{table}\n")
            logger.info(f"Table list written to {args.output}")
        
        return tables
    
    except Exception as e:
        logger.error(f"Failed to list tables: {str(e)}")
        return []


def main():
    """
    Main function.
    """
    # Parse command-line arguments
    args = parse_args()
    
    # Create logger
    if hasattr(args, 'script_path') and args.script_path:
        workflow_name = Path(args.script_path).stem
    elif hasattr(args, 'xml_path') and args.xml_path:
        workflow_name = Path(args.xml_path).stem
    else:
        workflow_name = 'etl_framework'
    
    log_file = get_log_file_path(workflow_name)
    logger = setup_logger(workflow_name, log_file)
    
    # Execute command based on arguments
    if args.command == 'convert':
        success = convert_informatica_xml(args, logger)
        return 0 if success else 1
    
    elif args.command == 'execute':
        success = execute_script(args, logger)
        return 0 if success else 1
    
    elif args.command == 'validate':
        report = validate_tables_cli(args, logger)
        
        if report and report.get('status') != 'error':
            summary = report.get('summary', {})
            tables_validated = report.get('tables_validated', 0)
            full_matches = summary.get('full_matches', 0)
            
            if full_matches == tables_validated:
                logger.info("All tables match successfully")
                return 0
            else:
                logger.warning("Not all tables match")
                return 1
        else:
            logger.error("Validation failed")
            return 2
    
    elif args.command == 'run':
        execution_success, validation_report = run_workflow(args, logger)
        
        # Print final status
        if execution_success and validation_report and validation_report.get('status') != 'error':
            summary = validation_report.get('summary', {})
            tables_validated = validation_report.get('tables_validated', 0)
            full_matches = summary.get('full_matches', 0)
            
            if full_matches == tables_validated:
                logger.info("Workflow completed successfully with all tables matching")
                return 0
            else:
                logger.warning("Workflow completed but not all tables match")
                return 1
        else:
            logger.error("Workflow failed")
            return 2
    
    elif args.command == 'tables':
        tables = list_database_tables(args, logger)
        return 0 if tables else 1
    
    else:
        print("\nETL Framework for Informatica XML to PySpark Conversion")
        print("-----------------------------------------------------")
        print("Please specify a command:")
        print("  convert   - Convert Informatica XML to PySpark")
        print("  execute   - Execute a PySpark script")
        print("  validate  - Validate ETL results")
        print("  run       - Execute and validate in one step")
        print("  tables    - List tables in source or target database")
        print("\nFor more information on a specific command, run:")
        print("  python main.py <command> --help")
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())