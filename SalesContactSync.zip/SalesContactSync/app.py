"""
Flask wrapper for the ETL framework.
This provides a minimal web interface to access the command-line functionality.
"""

import os
import sys
import json
from flask import Flask, jsonify, request, render_template, redirect, url_for
import subprocess
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "informatica-to-pyspark-secret")

@app.route('/')
def index():
    """Main page - shows information about the tool."""
    return jsonify({
        "name": "Informatica XML to PySpark Conversion Tool",
        "description": "A command-line tool for converting Informatica XML workflows to PySpark scripts",
        "usage": "Use 'python main.py --help' to see available commands",
        "commands": [
            "convert - Convert Informatica XML to PySpark",
            "execute - Execute a PySpark script",
            "validate - Validate ETL results",
            "run - Execute and validate in one step",
            "tables - List tables in source or target database"
        ]
    })

@app.route('/help')
def help_page():
    """Show help information."""
    try:
        result = subprocess.run(
            ["python", "main.py", "--help"],
            capture_output=True,
            text=True,
            check=True
        )
        return jsonify({
            "title": "Command-Line Help",
            "help_text": result.stdout
        })
    except subprocess.CalledProcessError as e:
        return jsonify({
            "error": "Failed to get help information",
            "details": e.stderr
        }), 500

@app.route('/api/run', methods=['POST'])
def api_run_command():
    """Run a command from the API."""
    data = request.json
    command = data.get('command', [])
    
    if not command:
        return jsonify({"error": "No command specified"}), 400
    
    try:
        # Construct command with 'python main.py' prefix
        full_command = ["python", "main.py"] + command
        
        # Run command
        result = subprocess.run(
            full_command,
            capture_output=True,
            text=True
        )
        
        # Return result
        return jsonify({
            "command": " ".join(full_command),
            "exit_code": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "success": result.returncode == 0
        })
    
    except Exception as e:
        return jsonify({
            "error": str(e)
        }), 500

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)