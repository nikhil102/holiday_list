"""
Module for validating data between source and target databases.
"""
import os
import sys
import pandas as pd
from pathlib import Path
import hashlib
import datetime

# Add parent directory to sys.path if running this module directly
if __name__ == "__main__":
    parent_dir = Path(__file__).parent.parent
    sys.path.append(str(parent_dir))

from utils.logging_utils import setup_logger
from utils.connection_utils import get_connection, execute_query, count_rows


class DataValidator:
    """Class for validating data between source and target databases."""
    
    def __init__(self, source_conn_str, target_conn_str, logger=None):
        """
        Initialize the data validator.
        
        Args:
            source_conn_str (str): Source database connection string.
            target_conn_str (str): Target database connection string.
            logger (Logger, optional): Logger to use.
        """
        self.source_conn_str = source_conn_str
        self.target_conn_str = target_conn_str
        self.logger = logger or setup_logger("data_validator")
        self.source_conn = None
        self.target_conn = None
    
    def connect(self):
        """
        Connect to the source and target databases.
        
        Returns:
            bool: True if connections are successful, False otherwise.
        """
        try:
            self.source_conn = get_connection(self.source_conn_str)
            self.logger.info("Connected to source database")
            
            self.target_conn = get_connection(self.target_conn_str)
            self.logger.info("Connected to target database")
            
            return True
        except Exception as e:
            self.logger.error(f"Failed to connect to databases: {str(e)}")
            return False
    
    def close(self):
        """
        Close database connections.
        """
        if self.source_conn:
            self.source_conn.close()
            self.source_conn = None
        
        if self.target_conn:
            self.target_conn.close()
            self.target_conn = None
    
    def validate_table_counts(self, tables):
        """
        Validate row counts between source and target tables.
        
        Args:
            tables (list): List of table names to compare.
        
        Returns:
            dict: Dictionary mapping table names to validation results.
        """
        if not self.source_conn or not self.target_conn:
            if not self.connect():
                return {}
        
        results = {}
        
        for table in tables:
            try:
                source_count = count_rows(self.source_conn, table)
                target_count = count_rows(self.target_conn, table)
                
                match = source_count == target_count
                
                results[table] = {
                    'source_count': source_count,
                    'target_count': target_count,
                    'match': match
                }
                
                status = "MATCH" if match else "MISMATCH"
                self.logger.info(f"Table {table}: {status} "
                                f"(Source: {source_count}, Target: {target_count})")
            
            except Exception as e:
                self.logger.error(f"Failed to validate counts for {table}: {str(e)}")
                results[table] = {'error': str(e)}
        
        return results
    
    def validate_table_schema(self, tables):
        """
        Validate schema between source and target tables.
        
        Args:
            tables (list): List of table names to compare.
        
        Returns:
            dict: Dictionary mapping table names to validation results.
        """
        if not self.source_conn or not self.target_conn:
            if not self.connect():
                return {}
        
        results = {}
        
        for table in tables:
            try:
                # Query to get table schema
                schema_query = f"""
                SELECT 
                    c.name as column_name,
                    t.name as data_type,
                    c.max_length,
                    c.precision,
                    c.scale,
                    c.is_nullable
                FROM 
                    sys.columns c
                JOIN 
                    sys.types t ON c.user_type_id = t.user_type_id
                WHERE 
                    c.object_id = OBJECT_ID('{table}')
                ORDER BY 
                    c.column_id
                """
                
                source_schema = execute_query(self.source_conn, schema_query)
                target_schema = execute_query(self.target_conn, schema_query)
                
                # Compare schemas
                schema_match = source_schema.equals(target_schema)
                
                if not schema_match:
                    # Find differences
                    if len(source_schema) != len(target_schema):
                        diff = {
                            'reason': 'Column count mismatch',
                            'source_columns': len(source_schema),
                            'target_columns': len(target_schema),
                            'source_only': list(set(source_schema['column_name']).difference(set(target_schema['column_name']))),
                            'target_only': list(set(target_schema['column_name']).difference(set(source_schema['column_name'])))
                        }
                    else:
                        # Compare column by column
                        diff = []
                        for i, (_, source_row) in enumerate(source_schema.iterrows()):
                            target_row = target_schema.iloc[i]
                            if not source_row.equals(target_row):
                                diff.append({
                                    'column': source_row['column_name'],
                                    'source': source_row.to_dict(),
                                    'target': target_row.to_dict()
                                })
                
                results[table] = {
                    'schema_match': schema_match,
                    'differences': diff if not schema_match else None
                }
                
                status = "MATCH" if schema_match else "MISMATCH"
                self.logger.info(f"Table {table} schema: {status}")
                
                if not schema_match:
                    self.logger.warning(f"Schema differences for {table}: {diff}")
            
            except Exception as e:
                self.logger.error(f"Failed to validate schema for {table}: {str(e)}")
                results[table] = {'error': str(e)}
        
        return results
    
    def validate_table_data(self, tables, limit=1000, sample_pct=None):
        """
        Validate data contents between source and target tables.
        
        Args:
            tables (list): List of table names to compare.
            limit (int, optional): Maximum number of rows to compare.
            sample_pct (float, optional): Percentage of rows to sample (0-100).
        
        Returns:
            dict: Dictionary mapping table names to validation results.
        """
        if not self.source_conn or not self.target_conn:
            if not self.connect():
                return {}
        
        results = {}
        
        for table in tables:
            try:
                # Determine query based on sampling method
                if sample_pct:
                    query = f"SELECT * FROM {table} TABLESAMPLE ({sample_pct} PERCENT)"
                else:
                    query = f"SELECT * FROM {table}"
                    if limit:
                        query += f" ORDER BY 1 OFFSET 0 ROWS FETCH NEXT {limit} ROWS ONLY"
                
                source_data = execute_query(self.source_conn, query)
                target_data = execute_query(self.target_conn, query)
                
                # Sort data to ensure consistent comparison
                if not source_data.empty and not target_data.empty:
                    try:
                        source_data = source_data.sort_values(by=list(source_data.columns))
                        target_data = target_data.sort_values(by=list(target_data.columns))
                    except Exception as e:
                        self.logger.warning(f"Failed to sort data for {table}: {str(e)}")
                
                # Compare row counts
                row_count_match = len(source_data) == len(target_data)
                
                # Compare column counts
                col_count_match = len(source_data.columns) == len(target_data.columns)
                
                # Compare column names
                col_names_match = list(source_data.columns) == list(target_data.columns)
                
                # Compare data content
                data_match = False
                if row_count_match and col_count_match and col_names_match:
                    try:
                        data_match = source_data.equals(target_data)
                    except Exception as e:
                        self.logger.warning(f"Failed to compare data for {table}: {str(e)}")
                
                # Calculate data hash for more efficient comparison
                source_hash = self._calculate_data_hash(source_data)
                target_hash = self._calculate_data_hash(target_data)
                hash_match = source_hash == target_hash
                
                results[table] = {
                    'row_count_match': row_count_match,
                    'col_count_match': col_count_match,
                    'col_names_match': col_names_match,
                    'data_match': data_match,
                    'hash_match': hash_match,
                    'source_rows': len(source_data),
                    'target_rows': len(target_data),
                    'overall_match': data_match and hash_match
                }
                
                status = "MATCH" if results[table]['overall_match'] else "MISMATCH"
                self.logger.info(f"Table {table} data: {status} "
                                f"(Rows: {row_count_match}, Columns: {col_count_match}, "
                                f"Names: {col_names_match}, Content: {data_match}, Hash: {hash_match})")
            
            except Exception as e:
                self.logger.error(f"Failed to validate data for {table}: {str(e)}")
                results[table] = {'error': str(e)}
        
        return results
    
    def _calculate_data_hash(self, df):
        """
        Calculate a hash of the DataFrame contents.
        
        Args:
            df (DataFrame): DataFrame to hash.
        
        Returns:
            str: Hash of the DataFrame.
        """
        if df.empty:
            return "empty"
        
        # Convert DataFrame to string representation
        df_string = df.to_csv(index=False)
        
        # Calculate hash
        return hashlib.md5(df_string.encode()).hexdigest()
    
    def generate_validation_report(self, tables, output_dir=None):
        """
        Generate a comprehensive validation report for the specified tables.
        
        Args:
            tables (list): List of table names to validate.
            output_dir (str, optional): Directory to write report to.
        
        Returns:
            dict: Validation report.
        """
        try:
            # Connect to databases if not already connected
            if not self.source_conn or not self.target_conn:
                if not self.connect():
                    return {'status': 'error', 'message': 'Failed to connect to databases'}
            
            # Run validations
            count_results = self.validate_table_counts(tables)
            schema_results = self.validate_table_schema(tables)
            data_results = self.validate_table_data(tables, limit=100)  # Sample first 100 rows
            
            # Generate report
            report = {
                'timestamp': datetime.datetime.now().isoformat(),
                'tables_validated': len(tables),
                'tables': {},
                'summary': {
                    'count_matches': 0,
                    'schema_matches': 0,
                    'data_matches': 0,
                    'full_matches': 0,
                    'tables_with_errors': 0
                }
            }
            
            for table in tables:
                table_report = {
                    'counts': count_results.get(table, {'error': 'Not validated'}),
                    'schema': schema_results.get(table, {'error': 'Not validated'}),
                    'data': data_results.get(table, {'error': 'Not validated'})
                }
                
                # Calculate overall match status
                has_errors = ('error' in table_report['counts'] or 
                             'error' in table_report['schema'] or 
                             'error' in table_report['data'])
                
                if has_errors:
                    report['summary']['tables_with_errors'] += 1
                    table_report['overall_match'] = False
                else:
                    count_match = table_report['counts'].get('match', False)
                    schema_match = table_report['schema'].get('schema_match', False)
                    data_match = table_report['data'].get('overall_match', False)
                    
                    if count_match:
                        report['summary']['count_matches'] += 1
                    if schema_match:
                        report['summary']['schema_matches'] += 1
                    if data_match:
                        report['summary']['data_matches'] += 1
                    
                    table_report['overall_match'] = count_match and schema_match and data_match
                    
                    if table_report['overall_match']:
                        report['summary']['full_matches'] += 1
                
                report['tables'][table] = table_report
            
            # Write report to file if output directory specified
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                report_file = os.path.join(output_dir, f"validation_report_{timestamp}.json")
                
                import json
                with open(report_file, 'w') as f:
                    json.dump(report, f, indent=2)
                
                self.logger.info(f"Validation report written to {report_file}")
            
            return report
        
        except Exception as e:
            self.logger.error(f"Failed to generate validation report: {str(e)}")
            return {'status': 'error', 'message': str(e)}
        
        finally:
            # Close connections
            self.close()


if __name__ == "__main__":
    # Test the data validator
    import argparse
    from config import Config
    
    parser = argparse.ArgumentParser(description='Test data validator')
    parser.add_argument('--tables', nargs='+', required=True, help='Tables to validate')
    parser.add_argument('--config', help='Path to connection properties file')
    parser.add_argument('--report-dir', help='Directory to write validation report')
    args = parser.parse_args()
    
    config = Config(args.config if args.config else None)
    
    validator = DataValidator(
        config.get_source_connection_string(),
        config.get_target_connection_string()
    )
    
    try:
        report = validator.generate_validation_report(
            args.tables,
            args.report_dir
        )
        
        import json
        print(json.dumps(report, indent=2))
        
        # Print summary
        print("\nSummary:")
        print(f"Tables validated: {report['tables_validated']}")
        print(f"Full matches: {report['summary']['full_matches']}")
        print(f"Count matches: {report['summary']['count_matches']}")
        print(f"Schema matches: {report['summary']['schema_matches']}")
        print(f"Data matches: {report['summary']['data_matches']}")
        print(f"Tables with errors: {report['summary']['tables_with_errors']}")
    
    except Exception as e:
        print(f"Error: {str(e)}")
