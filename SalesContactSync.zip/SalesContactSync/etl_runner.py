"""
Utility script for executing PySpark ETL scripts.
"""
import os
import sys
import argparse
import json
from pathlib import Path

# Import custom modules
from config import Config
from utils.logging_utils import setup_logger, get_log_file_path
from executors.pyspark_executor import PySparkExecutor


def parse_args():
    """
    Parse command-line arguments.
    
    Returns:
        Namespace: Parsed arguments.
    """
    parser = argparse.ArgumentParser(
        description='Execute PySpark ETL scripts generated from Informatica workflows'
    )
    
    parser.add_argument('script_path', help='Path to the PySpark script or directory containing scripts')
    parser.add_argument('--config', help='Path to the configuration file')
    parser.add_argument('--args', nargs='*', help='Arguments for the script')
    parser.add_argument('--spark-submit', action='store_true', 
                      help='Use spark-submit instead of direct execution')
    parser.add_argument('--recursive', action='store_true', 
                      help='Process scripts recursively if script_path is a directory')
    parser.add_argument('--output', help='Path to write execution results in JSON format')
    
    return parser.parse_args()


def execute_script(script_path, config_path=None, script_args=None, 
                 use_spark_submit=False, logger=None):
    """
    Execute a PySpark script.
    
    Args:
        script_path (str): Path to the PySpark script.
        config_path (str, optional): Path to the configuration file.
        script_args (list, optional): Arguments for the script.
        use_spark_submit (bool, optional): Whether to use spark-submit.
        logger (Logger, optional): Logger to use.
    
    Returns:
        dict: Execution results.
    """
    # Create logger if not provided
    if not logger:
        workflow_name = Path(script_path).stem
        log_file = get_log_file_path(workflow_name)
        logger = setup_logger(workflow_name, log_file)
    
    logger.info(f"Executing script: {script_path}")
    
    # Load configuration
    config = Config(config_path)
    
    # Create executor
    executor = PySparkExecutor(logger)
    
    # Add connection properties to script arguments if not already provided
    if script_args is None:
        script_args = []
    
    # Look for connection.properties in script's directory
    script_dir = os.path.dirname(script_path)
    properties_path = os.path.join(script_dir, 'connection.properties')
    
    if not any(arg.startswith('--config') for arg in script_args) and os.path.exists(properties_path):
        script_args.extend(['--config', properties_path])
        logger.info(f"Using connection properties from: {properties_path}")
    
    try:
        # Execute script
        start_time = None
        end_time = None
        
        import time
        start_time = time.time()
        
        if use_spark_submit:
            return_code, stdout, stderr = executor.execute_pyspark_submit(
                script_path, script_args
            )
        else:
            return_code, stdout, stderr = executor.execute_script(
                script_path, script_args
            )
        
        end_time = time.time()
        
        # Extract table names from stdout if possible
        import re
        tables_pattern = r'Table (\w+) has (\d+) rows'
        tables_info = re.findall(tables_pattern, stdout)
        
        tables = {table: int(count) for table, count in tables_info}
        
        # Create execution result
        result = {
            'script': script_path,
            'success': return_code == 0,
            'return_code': return_code,
            'execution_time': end_time - start_time if start_time and end_time else None,
            'tables': tables
        }
        
        if result['success']:
            logger.info(f"Script execution completed successfully in {result['execution_time']:.2f} seconds")
            if tables:
                for table, count in tables.items():
                    logger.info(f"Table {table}: {count} rows")
        else:
            logger.error(f"Script execution failed with return code {return_code}")
            if stderr:
                logger.error(f"Error: {stderr}")
        
        return result
    
    except Exception as e:
        logger.error(f"Failed to execute script: {str(e)}")
        return {
            'script': script_path,
            'success': False,
            'error': str(e)
        }


def find_pyspark_scripts(directory, recursive=False):
    """
    Find PySpark scripts in a directory.
    
    Args:
        directory (str): Directory to search.
        recursive (bool, optional): Whether to search recursively.
    
    Returns:
        list: Paths to PySpark scripts.
    """
    scripts = []
    
    # Convert to Path object for easier handling
    dir_path = Path(directory)
    
    # Pattern for main PySpark script (not Airflow DAG or utilities)
    pattern = 's_*.py'
    
    if recursive:
        # Find all scripts recursively
        scripts = [str(path) for path in dir_path.glob(f'**/{pattern}')]
    else:
        # Find scripts in the top-level directory only
        scripts = [str(path) for path in dir_path.glob(pattern)]
    
    return scripts


def main():
    """
    Main function.
    """
    # Parse command-line arguments
    args = parse_args()
    
    # Create logger
    workflow_name = Path(args.script_path).stem
    log_file = get_log_file_path(workflow_name)
    logger = setup_logger(workflow_name, log_file)
    
    # Determine scripts to execute
    script_path = args.script_path
    script_paths = []
    
    if os.path.isdir(script_path):
        logger.info(f"Searching for PySpark scripts in directory: {script_path}")
        script_paths = find_pyspark_scripts(script_path, args.recursive)
        logger.info(f"Found {len(script_paths)} PySpark scripts")
    else:
        script_paths = [script_path]
    
    # Execute scripts
    results = []
    
    for script in script_paths:
        result = execute_script(
            script,
            args.config,
            args.args,
            args.spark_submit,
            logger
        )
        results.append(result)
    
    # Summarize results
    success_count = sum(1 for result in results if result['success'])
    failure_count = len(results) - success_count
    
    logger.info(f"Execution summary: {success_count} succeeded, {failure_count} failed")
    
    # Write results to file if requested
    if args.output:
        try:
            with open(args.output, 'w') as f:
                json.dump({
                    'timestamp': import_datetime().datetime.now().isoformat(),
                    'success_count': success_count,
                    'failure_count': failure_count,
                    'results': results
                }, f, indent=2)
            
            logger.info(f"Execution results written to {args.output}")
        except Exception as e:
            logger.error(f"Failed to write execution results: {str(e)}")
    
    # Return status code
    return 0 if failure_count == 0 else 1


def import_datetime():
    """Import datetime module."""
    import datetime
    return datetime


if __name__ == "__main__":
    sys.exit(main())
