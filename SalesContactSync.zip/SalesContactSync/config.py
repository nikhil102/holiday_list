"""
Configuration module for the ETL framework.
Handles loading and parsing of configuration files.
"""
import os
import configparser
from pathlib import Path


class Config:
    """Configuration class for the ETL framework."""
    
    def __init__(self, config_file=None):
        """
        Initialize the configuration.
        
        Args:
            config_file (str, optional): Path to the configuration file.
                If None, looks for a file named connection.properties in the current directory.
        """
        self.config = configparser.ConfigParser()
        
        # Default configuration
        self.config['DEFAULT'] = {
            'source_db': 'msscdm_dev3',
            'target_db': 'msscdm_dev4',
            'server': 'w908925.cguser.capgroup.com\\CGSQL',
            'user': 'spark_user',
            'password': 'spark@25091990',
            'trust_server_certificate': 'true',
            'encrypt': 'false'
        }
        
        # If config_file is provided, load it
        if config_file:
            config_path = Path(config_file)
            if config_path.exists():
                self._load_properties_file(config_path)
            else:
                raise FileNotFoundError(f"Configuration file not found: {config_file}")
        else:
            # Look for a properties file in the current directory
            default_path = Path("connection.properties")
            if default_path.exists():
                self._load_properties_file(default_path)
    
    def _load_properties_file(self, file_path):
        """
        Load properties from a .properties file.
        
        Args:
            file_path (Path): Path to the properties file.
        """
        try:
            # Read the properties file
            with open(file_path, 'r') as f:
                lines = f.readlines()
            
            # Parse the properties into our configparser
            section = 'CONNECTION'
            self.config[section] = {}
            
            for line in lines:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                
                if '=' in line:
                    key, value = line.split('=', 1)
                    self.config[section][key.strip()] = value.strip()
        except Exception as e:
            raise ValueError(f"Failed to parse properties file: {str(e)}")
    
    def get_jdbc_url(self, db_name=None):
        """
        Get the JDBC URL for the specified database.
        
        Args:
            db_name (str, optional): Database name. If None, uses the target_db.
        
        Returns:
            str: JDBC URL for the database.
        """
        section = 'CONNECTION' if 'CONNECTION' in self.config else 'DEFAULT'
        
        if not db_name:
            db_name = self.config[section].get('target_db', 'msscdm_dev4')
        
        server = self.config[section].get('server', 'w908925.cguser.capgroup.com\\CGSQL')
        user = self.config[section].get('user', 'spark_user')
        password = self.config[section].get('password', 'spark@25091990')
        trust_cert = self.config[section].get('trust_server_certificate', 'true')
        encrypt = self.config[section].get('encrypt', 'false')
        
        return (f"jdbc:sqlserver://{server};databaseName={db_name};"
                f"user={user};password={password};"
                f"trustServerCertificate={trust_cert};encrypt={encrypt}")
    
    def get_source_jdbc_url(self):
        """Get the JDBC URL for the source database."""
        section = 'CONNECTION' if 'CONNECTION' in self.config else 'DEFAULT'
        source_db = self.config[section].get('source_db', 'msscdm_dev3')
        return self.get_jdbc_url(source_db)
    
    def get_target_jdbc_url(self):
        """Get the JDBC URL for the target database."""
        section = 'CONNECTION' if 'CONNECTION' in self.config else 'DEFAULT'
        target_db = self.config[section].get('target_db', 'msscdm_dev4')
        return self.get_jdbc_url(target_db)
    
    def get_pyodbc_connection_string(self, db_name=None):
        """
        Get the connection string for pyodbc.
        
        Args:
            db_name (str, optional): Database name. If None, uses the target_db.
        
        Returns:
            str: Connection string for pyodbc.
        """
        section = 'CONNECTION' if 'CONNECTION' in self.config else 'DEFAULT'
        
        if not db_name:
            db_name = self.config[section].get('target_db', 'msscdm_dev4')
        
        server = self.config[section].get('server', 'w908925.cguser.capgroup.com\\CGSQL')
        user = self.config[section].get('user', 'spark_user')
        password = self.config[section].get('password', 'spark@25091990')
        trust_cert = self.config[section].get('trust_server_certificate', 'true')
        encrypt = self.config[section].get('encrypt', 'false')
        
        return (f"DRIVER={{ODBC Driver 17 for SQL Server}};"
                f"SERVER={server};DATABASE={db_name};"
                f"UID={user};PWD={password};"
                f"TrustServerCertificate={trust_cert};Encrypt={encrypt}")
    
    def get_source_connection_string(self):
        """Get the connection string for the source database."""
        section = 'CONNECTION' if 'CONNECTION' in self.config else 'DEFAULT'
        source_db = self.config[section].get('source_db', 'msscdm_dev3')
        return self.get_pyodbc_connection_string(source_db)
    
    def get_target_connection_string(self):
        """Get the connection string for the target database."""
        section = 'CONNECTION' if 'CONNECTION' in self.config else 'DEFAULT'
        target_db = self.config[section].get('target_db', 'msscdm_dev4')
        return self.get_pyodbc_connection_string(target_db)
