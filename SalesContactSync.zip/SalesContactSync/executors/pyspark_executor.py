"""
Module for executing PySpark scripts.
"""
import os
import sys
import subprocess
import importlib.util
from pathlib import Path

# Add parent directory to sys.path if running this module directly
if __name__ == "__main__":
    parent_dir = Path(__file__).parent.parent
    sys.path.append(str(parent_dir))

from utils.logging_utils import setup_logger


class PySparkExecutor:
    """Class for executing PySpark scripts."""
    
    def __init__(self, logger=None):
        """
        Initialize the PySpark executor.
        
        Args:
            logger (Logger, optional): Logger to use.
        """
        self.logger = logger or setup_logger("pyspark_executor")
    
    def execute_script(self, script_path, args=None):
        """
        Execute a PySpark script using the subprocess module.
        
        Args:
            script_path (str): Path to the PySpark script.
            args (list, optional): Command-line arguments for the script.
        
        Returns:
            tuple: (return_code, stdout, stderr)
        
        Raises:
            FileNotFoundError: If the script doesn't exist.
            Exception: If script execution fails.
        """
        # Validate script path
        if not os.path.exists(script_path):
            raise FileNotFoundError(f"Script not found: {script_path}")
        
        # Prepare command
        cmd = [sys.executable, script_path]
        if args:
            cmd.extend(args)
        
        self.logger.info(f"Executing script: {' '.join(cmd)}")
        
        try:
            # Execute the script
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Capture output and error streams
            stdout, stderr = process.communicate()
            
            if process.returncode != 0:
                self.logger.error(f"Script execution failed with code {process.returncode}")
                self.logger.error(f"Error: {stderr}")
            else:
                self.logger.info("Script execution completed successfully")
            
            return process.returncode, stdout, stderr
        
        except Exception as e:
            self.logger.error(f"Failed to execute script: {str(e)}")
            raise
    
    def execute_script_in_process(self, script_path, args=None):
        """
        Execute a PySpark script by importing it.
        
        Args:
            script_path (str): Path to the PySpark script.
            args (list, optional): Command-line arguments for the script.
        
        Returns:
            bool: True if execution was successful, False otherwise.
        
        Raises:
            FileNotFoundError: If the script doesn't exist.
            Exception: If script execution fails.
        """
        # Validate script path
        if not os.path.exists(script_path):
            raise FileNotFoundError(f"Script not found: {script_path}")
        
        self.logger.info(f"Executing script in-process: {script_path}")
        
        try:
            # Save original sys.argv
            original_argv = sys.argv.copy()
            
            # Modify sys.argv to include script arguments
            if args:
                sys.argv = [script_path] + args
            else:
                sys.argv = [script_path]
            
            # Import the script as a module
            module_name = os.path.basename(script_path).replace('.py', '')
            spec = importlib.util.spec_from_file_location(module_name, script_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            # Restore original sys.argv
            sys.argv = original_argv
            
            self.logger.info("Script execution completed successfully")
            return True
        
        except Exception as e:
            self.logger.error(f"Failed to execute script: {str(e)}")
            # Restore original sys.argv
            sys.argv = original_argv if 'original_argv' in locals() else sys.argv
            raise
    
    def execute_pyspark_submit(self, script_path, args=None, spark_config=None):
        """
        Execute a PySpark script using spark-submit.
        
        Args:
            script_path (str): Path to the PySpark script.
            args (list, optional): Command-line arguments for the script.
            spark_config (dict, optional): Spark configuration parameters.
        
        Returns:
            tuple: (return_code, stdout, stderr)
        
        Raises:
            FileNotFoundError: If the script doesn't exist.
            Exception: If script execution fails.
        """
        # Validate script path
        if not os.path.exists(script_path):
            raise FileNotFoundError(f"Script not found: {script_path}")
        
        # Prepare command
        cmd = ["spark-submit"]
        
        # Add Spark configuration
        if spark_config:
            for key, value in spark_config.items():
                cmd.extend([f"--conf", f"{key}={value}"])
        
        cmd.append(script_path)
        
        if args:
            cmd.extend(args)
        
        self.logger.info(f"Executing spark-submit: {' '.join(cmd)}")
        
        try:
            # Execute the script
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Capture output and error streams
            stdout, stderr = process.communicate()
            
            if process.returncode != 0:
                self.logger.error(f"Spark submit failed with code {process.returncode}")
                self.logger.error(f"Error: {stderr}")
            else:
                self.logger.info("Spark submit completed successfully")
            
            return process.returncode, stdout, stderr
        
        except Exception as e:
            self.logger.error(f"Failed to execute spark-submit: {str(e)}")
            raise


if __name__ == "__main__":
    # Test the PySpark executor
    import argparse
    
    parser = argparse.ArgumentParser(description='Test PySpark executor')
    parser.add_argument('script_path', help='Path to the PySpark script')
    parser.add_argument('--args', nargs='*', help='Arguments for the script')
    parser.add_argument('--use-spark-submit', action='store_true', help='Use spark-submit')
    args = parser.parse_args()
    
    executor = PySparkExecutor()
    
    try:
        if args.use_spark_submit:
            return_code, stdout, stderr = executor.execute_pyspark_submit(args.script_path, args.args)
            print(f"Return code: {return_code}")
            print(f"Stdout: {stdout}")
            print(f"Stderr: {stderr}")
        else:
            return_code, stdout, stderr = executor.execute_script(args.script_path, args.args)
            print(f"Return code: {return_code}")
            print(f"Stdout: {stdout}")
            print(f"Stderr: {stderr}")
    except Exception as e:
        print(f"Error: {str(e)}")
