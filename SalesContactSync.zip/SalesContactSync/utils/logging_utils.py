"""
Utility functions for logging.
"""
import os
import logging
import datetime
from pathlib import Path


def setup_logger(name, log_file=None, level=logging.INFO):
    """
    Set up a logger with the specified name and log file.
    
    Args:
        name (str): Name of the logger.
        log_file (str, optional): Path to the log file.
        level (int, optional): Logging level. Default is INFO.
    
    Returns:
        Logger: Configured logger.
    """
    # Create a logger
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Remove existing handlers
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # Create a formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # Create a console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # Create a file handler if a log file is specified
    if log_file:
        # Create the log directory if it doesn't exist
        log_dir = os.path.dirname(log_file)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger


def log_table_counts(logger, connection, tables):
    """
    Log the row counts for the specified tables.
    
    Args:
        logger (Logger): Logger to use.
        connection (Connection): Database connection.
        tables (list): List of table names.
    """
    from utils.connection_utils import count_rows
    
    for table in tables:
        try:
            count = count_rows(connection, table)
            logger.info(f"Table {table} has {count} rows")
        except Exception as e:
            logger.error(f"Failed to count rows in {table}: {str(e)}")


def create_log_directory():
    """
    Create a log directory based on the current date.
    
    Returns:
        str: Path to the log directory.
    """
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    log_dir = Path(f"logs/{today}")
    log_dir.mkdir(parents=True, exist_ok=True)
    return str(log_dir)


def get_log_file_path(workflow_name):
    """
    Get the path to a log file for the specified workflow.
    
    Args:
        workflow_name (str): Name of the workflow.
    
    Returns:
        str: Path to the log file.
    """
    log_dir = create_log_directory()
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    return os.path.join(log_dir, f"{workflow_name}_{timestamp}.log")


if __name__ == "__main__":
    # Test the logging utilities
    log_file = get_log_file_path("test_workflow")
    logger = setup_logger("test_logger", log_file)
    
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")
    
    print(f"Log file created at: {log_file}")
