"""
Utility functions for database connections.
"""
import os
import sys
import pyodbc
import pandas as pd
from pathlib import Path

# Add parent directory to sys.path if running this module directly
if __name__ == "__main__":
    parent_dir = Path(__file__).parent.parent
    sys.path.append(str(parent_dir))

from config import Config


def get_connection(connection_string):
    """
    Create a connection to a database.
    
    Args:
        connection_string (str): Database connection string.
    
    Returns:
        Connection: Database connection object.
    
    Raises:
        Exception: If connection fails.
    """
    try:
        return pyodbc.connect(connection_string)
    except Exception as e:
        raise Exception(f"Failed to connect to database: {str(e)}")


def execute_query(connection, query, params=None):
    """
    Execute a SQL query.
    
    Args:
        connection (Connection): Database connection object.
        query (str): SQL query.
        params (tuple, optional): Query parameters.
    
    Returns:
        DataFrame: Query results as a pandas DataFrame.
    
    Raises:
        Exception: If query execution fails.
    """
    try:
        if params:
            return pd.read_sql(query, connection, params=params)
        return pd.read_sql(query, connection)
    except Exception as e:
        raise Exception(f"Failed to execute query: {str(e)}")


def count_rows(connection, table_name):
    """
    Count the number of rows in a table.
    
    Args:
        connection (Connection): Database connection object.
        table_name (str): Name of the table.
    
    Returns:
        int: Number of rows.
    
    Raises:
        Exception: If query execution fails.
    """
    try:
        query = f"SELECT COUNT(*) AS row_count FROM {table_name}"
        result = execute_query(connection, query)
        return result.iloc[0]['row_count']
    except Exception as e:
        raise Exception(f"Failed to count rows in {table_name}: {str(e)}")


def get_table_schema(connection, table_name):
    """
    Get the schema of a table.
    
    Args:
        connection (Connection): Database connection object.
        table_name (str): Name of the table.
    
    Returns:
        DataFrame: Table schema as a pandas DataFrame.
    
    Raises:
        Exception: If query execution fails.
    """
    try:
        query = f"""
        SELECT 
            c.name as column_name,
            t.name as data_type,
            c.max_length,
            c.precision,
            c.scale,
            c.is_nullable
        FROM 
            sys.columns c
        JOIN 
            sys.types t ON c.user_type_id = t.user_type_id
        WHERE 
            c.object_id = OBJECT_ID('{table_name}')
        ORDER BY 
            c.column_id
        """
        return execute_query(connection, query)
    except Exception as e:
        raise Exception(f"Failed to get schema for {table_name}: {str(e)}")


def list_tables(connection, schema=None):
    """
    List all tables in a database.
    
    Args:
        connection (Connection): Database connection object.
        schema (str, optional): Database schema.
    
    Returns:
        list: List of table names.
    
    Raises:
        Exception: If query execution fails.
    """
    try:
        if schema:
            query = f"""
            SELECT TABLE_NAME 
            FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_TYPE='BASE TABLE' AND TABLE_SCHEMA='{schema}'
            ORDER BY TABLE_NAME
            """
        else:
            query = """
            SELECT TABLE_NAME 
            FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_TYPE='BASE TABLE'
            ORDER BY TABLE_NAME
            """
        
        result = execute_query(connection, query)
        return result['TABLE_NAME'].tolist()
    except Exception as e:
        raise Exception(f"Failed to list tables: {str(e)}")


def get_config_from_properties(filepath):
    """
    Parse a connection.properties file and return a Config object.
    
    Args:
        filepath (str): Path to the properties file.
    
    Returns:
        Config: Configuration object.
    """
    return Config(filepath)


if __name__ == "__main__":
    # Test the connection utilities
    config = Config()
    conn_str = config.get_target_connection_string()
    
    try:
        conn = get_connection(conn_str)
        print("Connection successful")
        
        tables = list_tables(conn)
        print(f"Found {len(tables)} tables")
        
        if tables:
            first_table = tables[0]
            count = count_rows(conn, first_table)
            print(f"Table {first_table} has {count} rows")
            
            schema = get_table_schema(conn, first_table)
            print(f"Schema of {first_table}:")
            print(schema)
    except Exception as e:
        print(f"Error: {str(e)}")
