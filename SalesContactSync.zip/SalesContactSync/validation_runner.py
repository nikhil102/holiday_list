"""
Utility script for validating ETL results.
"""
import os
import sys
import argparse
import json
from pathlib import Path

# Import custom modules
from config import Config
from utils.logging_utils import setup_logger, get_log_file_path
from validators.data_validator import DataValidator


def parse_args():
    """
    Parse command-line arguments.
    
    Returns:
        Namespace: Parsed arguments.
    """
    parser = argparse.ArgumentParser(
        description='Validate ETL results by comparing tables between databases'
    )
    
    parser.add_argument('--tables', nargs='+', help='Tables to validate')
    parser.add_argument('--tables-file', help='File containing table names, one per line')
    parser.add_argument('--config', help='Path to the configuration file')
    parser.add_argument('--report-dir', default='validation_reports', 
                      help='Directory for validation reports')
    parser.add_argument('--output', help='Path to write validation results in JSON format')
    parser.add_argument('--verbose', action='store_true', help='Print detailed validation results')
    
    return parser.parse_args()


def load_tables_from_file(file_path):
    """
    Load table names from a file.
    
    Args:
        file_path (str): Path to the file.
    
    Returns:
        list: Table names.
    """
    try:
        with open(file_path, 'r') as f:
            return [line.strip() for line in f if line.strip()]
    except Exception as e:
        raise ValueError(f"Failed to load tables from file: {str(e)}")


def validate_tables(tables, config_path=None, report_dir=None, logger=None):
    """
    Validate ETL results by comparing tables.
    
    Args:
        tables (list): Tables to validate.
        config_path (str, optional): Path to the configuration file.
        report_dir (str, optional): Directory for validation reports.
        logger (Logger, optional): Logger to use.
    
    Returns:
        dict: Validation report.
    """
    # Create logger if not provided
    if not logger:
        log_file = get_log_file_path('validation')
        logger = setup_logger('validation', log_file)
    
    logger.info(f"Validating {len(tables)} tables")
    
    # Load configuration
    config = Config(config_path)
    
    # Create validator
    validator = DataValidator(
        config.get_source_connection_string(),
        config.get_target_connection_string(),
        logger
    )
    
    try:
        # Generate validation report
        report = validator.generate_validation_report(
            tables,
            report_dir
        )
        
        # Log summary
        logger.info(f"Validation complete. {report['summary']['full_matches']} out of "
                   f"{report['tables_validated']} tables fully match.")
        
        return report
    
    except Exception as e:
        logger.error(f"Failed to validate tables: {str(e)}")
        return {'status': 'error', 'message': str(e)}


def main():
    """
    Main function.
    """
    # Parse command-line arguments
    args = parse_args()
    
    # Create logger
    log_file = get_log_file_path('validation')
    logger = setup_logger('validation', log_file)
    
    # Load tables
    tables = []
    
    if args.tables:
        tables.extend(args.tables)
    
    if args.tables_file:
        try:
            tables.extend(load_tables_from_file(args.tables_file))
        except Exception as e:
            logger.error(str(e))
            return 1
    
    if not tables:
        logger.error("No tables specified. Use --tables or --tables-file.")
        return 1
    
    # Remove duplicates while preserving order
    tables = list(dict.fromkeys(tables))
    
    logger.info(f"Validating {len(tables)} tables")
    
    # Validate tables
    report = validate_tables(
        tables,
        args.config,
        args.report_dir,
        logger
    )
    
    # Print detailed results if requested
    if args.verbose and report and report.get('status') != 'error':
        json_str = json.dumps(report, indent=2)
        print(json_str)
    
    # Write results to file if requested
    if args.output and report:
        try:
            with open(args.output, 'w') as f:
                json.dump(report, f, indent=2)
            
            logger.info(f"Validation results written to {args.output}")
        except Exception as e:
            logger.error(f"Failed to write validation results: {str(e)}")
    
    # Return status code
    if report and report.get('status') != 'error':
        if report['summary']['full_matches'] == report['tables_validated']:
            logger.info("All tables match successfully")
            return 0
        else:
            logger.warning("Not all tables match")
            return 2
    else:
        logger.error("Validation failed")
        return 1


if __name__ == "__main__":
    sys.exit(main())
