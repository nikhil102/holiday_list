#!/usr/bin/env python3
"""
Informatica XML Parser - CLI Tool

A command-line tool for parsing and extracting information from Informatica XML mapping files.
"""

import os
import sys
import argparse
import json
import logging
from pathlib import Path

from parser import InformaticaXMLParser

def setup_logging(verbose):
    """Configure logging based on verbosity level."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

def ensure_output_dir(output_dir):
    """Ensure the output directory exists."""
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    return output_dir

def save_to_file(data, output_file, output_format):
    """Save parsed data to a file."""
    output_path = Path(output_file)
    
    if output_format == 'json':
        with open(output_path, 'w') as f:
            json.dump(data, f, indent=2)
    else:  # text format
        with open(output_path, 'w') as f:
            f.write(format_as_text(data))
            
    logging.info(f"Results saved to {output_path}")

def format_as_text(data, indent=0):
    """Format the parsed data as a text representation."""
    result = []
    indent_str = ' ' * indent
    
    if isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, (dict, list)):
                result.append(f"{indent_str}{key}:")
                result.append(format_as_text(value, indent + 2))
            else:
                result.append(f"{indent_str}{key}: {value}")
    elif isinstance(data, list):
        for item in data:
            if isinstance(item, (dict, list)):
                result.append(format_as_text(item, indent))
                result.append("")
            else:
                result.append(f"{indent_str}- {item}")
    else:
        result.append(f"{indent_str}{data}")
        
    return '\n'.join(result)

def display_results(data, element_type=None):
    """Display the parsed results."""
    if element_type and element_type in data:
        print(json.dumps(data[element_type], indent=2))
    else:
        print(json.dumps(data, indent=2))

def main():
    parser = argparse.ArgumentParser(
        description="Parse Informatica XML mapping files and extract structured information."
    )
    
    parser.add_argument(
        "xml_file", 
        help="Path to the Informatica XML mapping file"
    )
    
    parser.add_argument(
        "-e", "--element",
        choices=["sources", "targets", "transformations", "connectors", 
                 "instances", "table_attributes", "mapping", "workflow", "all"],
        default="all",
        help="Specific element type to extract (default: all)"
    )
    
    parser.add_argument(
        "-o", "--output",
        help="Output file path (default: print to console)"
    )
    
    parser.add_argument(
        "-f", "--format",
        choices=["json", "text"],
        default="json",
        help="Output format (default: json)"
    )
    
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose output"
    )
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(args.verbose)
    
    # Verify the XML file exists
    if not os.path.isfile(args.xml_file):
        logging.error(f"File not found: {args.xml_file}")
        sys.exit(1)
    
    try:
        # Parse the XML file
        logging.info(f"Parsing {args.xml_file}...")
        xml_parser = InformaticaXMLParser(args.xml_file)
        
        # Parse based on requested element type
        if args.element == "all":
            result = xml_parser.parse_all()
        elif args.element == "sources":
            result = {"sources": xml_parser.parse_sources()}
        elif args.element == "targets":
            result = {"targets": xml_parser.parse_targets()}
        elif args.element == "transformations":
            result = {"transformations": xml_parser.parse_transformations()}
        elif args.element == "connectors":
            result = {"connectors": xml_parser.parse_connectors()}
        elif args.element == "instances":
            result = {"instances": xml_parser.parse_instances()}
        elif args.element == "table_attributes":
            result = {"table_attributes": xml_parser.parse_table_attributes()}
        elif args.element == "mapping":
            result = {"mapping": xml_parser.parse_mapping()}
        elif args.element == "workflow":
            result = {"workflow": xml_parser.parse_workflow_session()}
        
        # Output results
        if args.output:
            output_dir = os.path.dirname(args.output)
            if output_dir:
                ensure_output_dir(output_dir)
            save_to_file(result, args.output, args.format)
        else:
            display_results(result)
            
        logging.info("Parsing completed successfully")
        
    except Exception as e:
        logging.error(f"Error parsing XML file: {str(e)}")
        if args.verbose:
            logging.exception("Detailed error information:")
        sys.exit(1)

if __name__ == "__main__":
    main()
