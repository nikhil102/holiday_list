"""
Informatica XML Parser Module

This module provides functionality to parse and extract information from
Informatica XML mapping files using XPath queries based on a comprehensive checklist.
"""

import logging
from lxml import etree

class InformaticaXMLParser:
    """Parser for Informatica XML mapping files."""
    
    def __init__(self, xml_file_path):
        """
        Initialize the parser with the XML file path.
        
        Args:
            xml_file_path (str): Path to the Informatica XML mapping file.
        """
        self.xml_file_path = xml_file_path
        self.tree = None
        self.root = None
        self.namespaces = {}
        self._load_xml()
    
    def _load_xml(self):
        """Load and parse the XML file, detect namespaces."""
        try:
            # Parse the XML file
            self.tree = etree.parse(self.xml_file_path)
            self.root = self.tree.getroot()
            
            # Extract namespaces
            self.namespaces = {k if k else 'default': v for k, v in self.root.nsmap.items()}
            
            logging.debug(f"Loaded XML file: {self.xml_file_path}")
            logging.debug(f"Detected namespaces: {self.namespaces}")
            
        except Exception as e:
            logging.error(f"Failed to load XML file: {str(e)}")
            raise
    
    def _xpath(self, xpath_query):
        """
        Execute an XPath query with namespace handling.
        
        Args:
            xpath_query (str): The XPath query to execute.
            
        Returns:
            list: Result of the XPath query.
        """
        try:
            # Try with namespaces first
            if self.namespaces:
                return self.root.xpath(xpath_query, namespaces=self.namespaces)
            else:
                return self.root.xpath(xpath_query)
        except Exception as e:
            logging.error(f"XPath query '{xpath_query}' failed: {str(e)}")
            return []
    
    def _get_element_attributes(self, element, attributes):
        """
        Extract specified attributes from an XML element.
        
        Args:
            element: The XML element to extract attributes from.
            attributes (list): List of attribute names to extract.
            
        Returns:
            dict: Dictionary of attribute names and values.
        """
        result = {}
        for attr in attributes:
            value = element.get(attr)
            if value is not None:
                result[attr.lower()] = value
        return result
    
    def _get_child_elements(self, element, child_tag, attributes):
        """
        Extract child elements and their attributes.
        
        Args:
            element: The parent XML element.
            child_tag (str): The tag name of child elements to extract.
            attributes (list): List of attribute names to extract from each child.
            
        Returns:
            list: List of dictionaries with child element attributes.
        """
        result = []
        for child in element.findall(child_tag):
            child_data = self._get_element_attributes(child, attributes)
            result.append(child_data)
        return result
    
    def parse_sources(self):
        """
        Parse source definition elements.
        
        Returns:
            list: Extracted source definitions.
        """
        logging.info("Parsing source definitions...")
        sources = []
        
        # Source attributes to extract
        source_attrs = ['NAME', 'DATABASETYPE', 'DBDNAME', 'OWNERNAME']
        # Source field attributes to extract
        field_attrs = ['NAME', 'DATATYPE', 'PRECISION', 'SCALE', 'PHYSICALLENGTH',
                      'PHYSICALOFFSET', 'NULLABLE', 'KEYTYPE', 'DESCRIPTION']
        
        for source_elem in self._xpath('//SOURCE'):
            source_data = self._get_element_attributes(source_elem, source_attrs)
            source_data['fields'] = self._get_child_elements(source_elem, 'SOURCEFIELD', field_attrs)
            sources.append(source_data)
        
        logging.debug(f"Found {len(sources)} source definitions")
        return sources
    
    def parse_targets(self):
        """
        Parse target definition elements.
        
        Returns:
            list: Extracted target definitions.
        """
        logging.info("Parsing target definitions...")
        targets = []
        
        # Target attributes to extract
        target_attrs = ['NAME', 'DATABASETYPE', 'DBDNAME', 'OWNERNAME']
        # Target field attributes to extract
        field_attrs = ['NAME', 'DATATYPE', 'PRECISION', 'SCALE', 'PHYSICALLENGTH',
                      'NULLABLE', 'KEYTYPE', 'DESCRIPTION']
        
        for target_elem in self._xpath('//TARGET'):
            target_data = self._get_element_attributes(target_elem, target_attrs)
            target_data['fields'] = self._get_child_elements(target_elem, 'TARGETFIELD', field_attrs)
            targets.append(target_data)
        
        logging.debug(f"Found {len(targets)} target definitions")
        return targets
    
    def parse_transformations(self):
        """
        Parse transformation elements.
        
        Returns:
            list: Extracted transformations.
        """
        logging.info("Parsing transformations...")
        transformations = []
        
        # Transformation attributes to extract
        transform_attrs = ['NAME', 'TYPE', 'REUSABLE', 'DESCRIPTION']
        # Transform field attributes to extract
        field_attrs = ['NAME', 'PORTTYPE', 'DATATYPE', 'PRECISION', 'SCALE',
                      'EXPRESSION', 'DEFAULTVALUE', 'DESCRIPTION']
        
        for transform_elem in self._xpath('//TRANSFORMATION'):
            transform_data = self._get_element_attributes(transform_elem, transform_attrs)
            transform_data['fields'] = self._get_child_elements(transform_elem, 'TRANSFORMFIELD', field_attrs)
            
            # Extract specific transformation details based on type
            transform_type = transform_data.get('type', '').upper()
            
            # Expression transformation specifics
            if transform_type == 'EXPRESSION':
                expressions = []
                for field in transform_data['fields']:
                    if 'expression' in field and field['expression']:
                        expressions.append({
                            'field': field['name'],
                            'expression': field['expression']
                        })
                if expressions:
                    transform_data['expressions'] = expressions
            
            # Aggregator transformation specifics
            elif transform_type == 'AGGREGATOR':
                group_by_fields = []
                agg_functions = []
                for field in transform_data['fields']:
                    port_type = field.get('porttype', '').upper()
                    if port_type == 'INPUT/OUTPUT' and field.get('expression'):
                        group_by_fields.append(field['name'])
                    elif port_type == 'OUTPUT' and field.get('expression'):
                        agg_functions.append({
                            'field': field['name'],
                            'function': field['expression']
                        })
                transform_data['group_by_fields'] = group_by_fields
                transform_data['aggregation_functions'] = agg_functions
            
            # Lookup transformation specifics
            elif transform_type == 'LOOKUP':
                lookup_attrs = transform_elem.findall('TABLEATTRIBUTE')
                lookup_config = {}
                for attr in lookup_attrs:
                    name = attr.get('NAME')
                    value = attr.get('VALUE')
                    if name and value:
                        lookup_config[name.lower()] = value
                if lookup_config:
                    transform_data['lookup_config'] = lookup_config
            
            # Router transformation specifics
            elif transform_type == 'ROUTER':
                groups = transform_elem.findall('GROUP')
                router_groups = []
                for group in groups:
                    group_data = self._get_element_attributes(group, ['NAME', 'DESCRIPTION', 'EXPRESSION'])
                    if group_data:
                        router_groups.append(group_data)
                if router_groups:
                    transform_data['groups'] = router_groups
            
            # Joiner transformation specifics
            elif transform_type == 'JOINER':
                join_attrs = transform_elem.findall('ATTRIBUTE')
                join_config = {}
                for attr in join_attrs:
                    name = attr.get('NAME')
                    value = attr.get('VALUE')
                    if name and value:
                        join_config[name.lower()] = value
                if join_config:
                    transform_data['join_config'] = join_config
            
            # Sorter transformation specifics
            elif transform_type == 'SORTER':
                sort_keys = []
                for field in transform_data['fields']:
                    sort_attr = transform_elem.find(f'SORTKEY[@NAME="{field.get("name")}"]')
                    if sort_attr is not None:
                        sort_keys.append({
                            'field': field['name'],
                            'direction': sort_attr.get('SORTDIRECTION', 'ASCENDING')
                        })
                if sort_keys:
                    transform_data['sort_keys'] = sort_keys
            
            transformations.append(transform_data)
        
        logging.debug(f"Found {len(transformations)} transformations")
        return transformations
    
    def parse_connectors(self):
        """
        Parse connector elements that define port-level connections.
        
        Returns:
            list: Extracted connectors.
        """
        logging.info("Parsing connectors...")
        connectors = []
        
        # Connector attributes to extract
        connector_attrs = ['FROMINSTANCE', 'FROMFIELD', 'TOINSTANCE', 'TOFIELD']
        
        for connector_elem in self._xpath('//CONNECTOR'):
            connector_data = self._get_element_attributes(connector_elem, connector_attrs)
            if connector_data:
                connectors.append(connector_data)
        
        logging.debug(f"Found {len(connectors)} connectors")
        return connectors
    
    def parse_instances(self):
        """
        Parse instance elements that represent transformations or tables 
        instantiated in the mapping.
        
        Returns:
            list: Extracted instances.
        """
        logging.info("Parsing instances...")
        instances = []
        
        # Instance attributes to extract
        instance_attrs = ['NAME', 'TRANSFORMATION_TYPE', 'TRANSFORMATION_NAME', 'DESCRIPTION']
        
        for instance_elem in self._xpath('//INSTANCE'):
            instance_data = self._get_element_attributes(instance_elem, instance_attrs)
            if instance_data:
                instances.append(instance_data)
        
        logging.debug(f"Found {len(instances)} instances")
        return instances
    
    def parse_table_attributes(self):
        """
        Parse table attribute elements that define additional properties
        of sources and targets.
        
        Returns:
            list: Extracted table attributes.
        """
        logging.info("Parsing table attributes...")
        table_attributes = []
        
        # Table attribute attributes to extract
        attr_attrs = ['NAME', 'VALUE']
        
        for attr_elem in self._xpath('//TABLEATTRIBUTE'):
            attr_data = self._get_element_attributes(attr_elem, attr_attrs)
            if attr_data:
                table_attributes.append(attr_data)
        
        logging.debug(f"Found {len(table_attributes)} table attributes")
        return table_attributes
    
    def parse_mapping(self):
        """
        Parse the overall mapping information.
        
        Returns:
            dict: Extracted mapping information.
        """
        logging.info("Parsing mapping information...")
        mapping_data = {}
        
        # Mapping attributes to extract
        mapping_attrs = ['NAME', 'DESCRIPTION', 'VERSIONNUMBER', 'ISVALID']
        
        mapping_elems = self._xpath('//MAPPING')
        if mapping_elems:
            mapping_data = self._get_element_attributes(mapping_elems[0], mapping_attrs)
        
        logging.debug(f"Found mapping information: {mapping_data}")
        return mapping_data
    
    def parse_workflow_session(self):
        """
        Parse workflow and session information if included in the XML.
        
        Returns:
            dict: Extracted workflow and session information.
        """
        logging.info("Parsing workflow and session information...")
        result = {
            'workflow': [],
            'session': []
        }
        
        # Workflow attributes to extract
        workflow_attrs = ['NAME', 'DESCRIPTION', 'SCHEDULERNAME']
        
        # Session attributes to extract
        session_attrs = ['NAME', 'MAPPINGNAME', 'ISVALID', 'DESCRIPTION']
        
        # Parse workflows
        for workflow_elem in self._xpath('//WORKFLOW'):
            workflow_data = self._get_element_attributes(workflow_elem, workflow_attrs)
            if workflow_data:
                result['workflow'].append(workflow_data)
        
        # Parse sessions
        for session_elem in self._xpath('//SESSION'):
            session_data = self._get_element_attributes(session_elem, session_attrs)
            if session_data:
                result['session'].append(session_data)
        
        logging.debug(f"Found {len(result['workflow'])} workflows and {len(result['session'])} sessions")
        return result
    
    def parse_folder_repository(self):
        """
        Parse folder and repository information if included in the XML.
        
        Returns:
            dict: Extracted folder and repository information.
        """
        logging.info("Parsing folder and repository information...")
        result = {
            'folder': [],
            'repository': []
        }
        
        # Folder and Repository attributes to extract
        attrs = ['NAME', 'GROUP', 'OWNER']
        
        # Parse folders
        for folder_elem in self._xpath('//FOLDER'):
            folder_data = self._get_element_attributes(folder_elem, attrs)
            if folder_data:
                result['folder'].append(folder_data)
        
        # Parse repositories
        for repo_elem in self._xpath('//REPOSITORY'):
            repo_data = self._get_element_attributes(repo_elem, attrs)
            if repo_data:
                result['repository'].append(repo_data)
        
        logging.debug(f"Found {len(result['folder'])} folders and {len(result['repository'])} repositories")
        return result
    
    def parse_all(self):
        """
        Parse all elements from the Informatica XML mapping file.
        
        Returns:
            dict: Complete extracted data.
        """
        logging.info("Parsing all elements from the XML file...")
        
        result = {
            'sources': self.parse_sources(),
            'targets': self.parse_targets(),
            'transformations': self.parse_transformations(),
            'connectors': self.parse_connectors(),
            'instances': self.parse_instances(),
            'table_attributes': self.parse_table_attributes(),
            'mapping': self.parse_mapping(),
            'workflow_session': self.parse_workflow_session(),
            'folder_repository': self.parse_folder_repository()
        }
        
        logging.info("Completed parsing all elements")
        return result
