#!/usr/bin/env python3
"""
Script to process multiple Informatica XML mapping files and extract elements to JSON files.
"""

import os
import json
import logging
from pathlib import Path
from parser import InformaticaXMLParser

def setup_logging():
    """Configure logging."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

def ensure_output_dir(output_dir):
    """Ensure the output directory exists."""
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    return output_dir

def process_file(xml_file_path, output_base_dir):
    """
    Process a single XML file and extract all elements to separate JSON files.
    
    Args:
        xml_file_path (str): Path to the XML file to process
        output_base_dir (str): Base directory to store output files
    """
    logging.info(f"Processing {xml_file_path}...")
    
    # Get base filename without extension
    base_name = os.path.basename(xml_file_path).rsplit('.', 1)[0]
    
    # Create output directory for this file
    file_output_dir = os.path.join(output_base_dir, base_name)
    ensure_output_dir(file_output_dir)
    
    try:
        # Parse the XML file
        parser = InformaticaXMLParser(xml_file_path)
        
        # Extract each element type to a separate JSON file
        extract_element(parser.parse_sources(), 'sources', file_output_dir, base_name)
        extract_element(parser.parse_targets(), 'targets', file_output_dir, base_name)
        extract_element(parser.parse_transformations(), 'transformations', file_output_dir, base_name)
        extract_element(parser.parse_connectors(), 'connectors', file_output_dir, base_name)
        extract_element(parser.parse_instances(), 'instances', file_output_dir, base_name)
        extract_element(parser.parse_table_attributes(), 'table_attributes', file_output_dir, base_name)
        extract_element(parser.parse_mapping(), 'mapping', file_output_dir, base_name)
        extract_element(parser.parse_workflow_session(), 'workflow_session', file_output_dir, base_name)
        extract_element(parser.parse_folder_repository(), 'folder_repository', file_output_dir, base_name)
        
        # Create a consolidated file with all elements
        all_data = parser.parse_all()
        with open(os.path.join(file_output_dir, f"{base_name}_all.json"), 'w') as f:
            json.dump(all_data, f, indent=2)
        
        logging.info(f"Extracted all elements from {xml_file_path} to {file_output_dir}")
        
    except Exception as e:
        logging.error(f"Error processing {xml_file_path}: {str(e)}")
        raise

def extract_element(data, element_type, output_dir, base_name):
    """
    Extract a specific element type to a JSON file.
    
    Args:
        data: The extracted element data
        element_type (str): Type of element (e.g., 'sources', 'targets')
        output_dir (str): Directory to store the output file
        base_name (str): Base name for the output file
    """
    output_file = os.path.join(output_dir, f"{base_name}_{element_type}.json")
    with open(output_file, 'w') as f:
        json.dump(data, f, indent=2)
    logging.info(f"Extracted {element_type} to {output_file}")

def main():
    setup_logging()
    
    # Input directory containing XML files
    input_dir = 'examples'
    
    # Output directory for JSON files
    output_dir = 'output/mappings'
    ensure_output_dir(output_dir)
    
    # Get all XML files in the input directory
    xml_files = [os.path.join(input_dir, f) for f in os.listdir(input_dir) if f.endswith('.xml')]
    
    if not xml_files:
        logging.warning(f"No XML files found in {input_dir}")
        return
    
    # Process each XML file
    for xml_file in xml_files:
        try:
            process_file(xml_file, output_dir)
        except Exception as e:
            logging.error(f"Failed to process {xml_file}: {str(e)}")
    
    logging.info(f"Processed {len(xml_files)} XML files")

if __name__ == "__main__":
    main()